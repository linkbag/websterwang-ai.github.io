import { CHOICE_RULES, promoteProjectVersion, validateProject } from "./model.js";
import { checkScope, kindSpec, pilotKind, readFields, runOperation } from "./pilot-commands.js";
import {verifyProtectedLanguages} from "./pilot-language.js";
export { pilotScopes, pilotInstructions } from "./pilot-commands.js";

export function checkPilotProject(project) {
  const result=validateProject(project);
  if(result.errors.length)throw new Error(result.errors.join("\n"));
  return result.warnings;
}
const directory=(project)=>(project.materials||[]).map(({id,name,kind})=>({id,name,kind}));
const masked=()=>({en:"[withheld]",zh:"［未分享］"});
function withoutProse(value){
  if(Array.isArray(value))return value.map(withoutProse);
  if(!value||typeof value!=="object")return value;
  if(Object.hasOwn(value,"en")||Object.hasOwn(value,"zh")){
    if(Array.isArray(value.en)||Array.isArray(value.zh))return {en:[],zh:[]};
    return masked();
  }
  return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,withoutProse(v)]));
}
/** A section carries its prose plus the names/identifiers and mechanics necessary to
 * validate destinations. Other prose, original material contents and credits stay local. */
export function pilotContext(project,scope=null){
  checkPilotProject(project);checkScope(project,scope);
  const spec=kindSpec(project),content=readFields(spec.schema,project),kind=pilotKind(project);
  const context={version:project.version,id:project.id,title:readFields("bilingual",project.title),...content};
  if(project.kind)context.kind=project.kind;
  if(project.materials)context.materials=directory(project);
  if(kind==="novel"){
    context.assets=project.assets.map(a=>({id:a.id,kind:a.kind,name:readFields("bilingual",a.name)}));
    if(project.inventory)context.inventory=project.inventory.map(o=>({id:o.id,name:readFields("bilingual",o.name),flag:o.flag,when:o.when,description:{}}));
    if(scope!==null)context.scenes=context.scenes.map(s=>s.id===scope?s:{id:s.id,title:s.title,background:"",audio:"",lines:[],choices:[],next:"",ending:true});
  }else if(scope!==null){
    const c=spec.container?context[spec.container]:context;
    c[spec.units]=c[spec.units].map(s=>s.id===scope?s:{...withoutProse(s),...(s.title?{title:s.title}:{name:s.name})});
    if(c.opening)c.opening=masked();
    if(c.items)c.items=c.items.map(s=>s.description?{...s,description:masked()}:s);
    if(c.room)c.room.intro=masked();
    if(c.endings)c.endings=c.endings.map(e=>({...e,text:masked()}));
    if(kind==="stage-drama"){
      c.cast=c.cast.map(member=>({...member,bio:masked()}));
      c.acts=c.acts.map(act=>({...act,role:masked(),place:masked()}));
      c.epilogues=c.epilogues.map(panel=>({...panel,body:masked()}));
    }
  }
  return context;
}

// Schema validators resolve attached IDs by type. These single-byte inert stand-ins
// exist only on the gateway, and are never sent upstream or applied to a real project.
const placeholder={image:"image/png",video:"video/mp4",audio:"audio/wav",text:"text/plain"};
export function fromPilotContext(context){
  if(!context||typeof context!=="object"||Array.isArray(context))throw new Error("Invalid pilot context. 工程信息无效。");
  const kind=pilotKind(context),spec=kindSpec(context);
  const metadata=entries=>Array.isArray(entries)&&entries.every(m=>m&&Object.keys(m).every(k=>["id","name","kind"].includes(k)));
  if((context.materials!==undefined&&!metadata(context.materials))||(kind==="novel"&&!metadata(context.assets)))throw new Error("The pilot accepts asset metadata only. 助手仅接受素材名称及类型。");
  const project={version:context.version,id:context.id,title:readFields("bilingual",context.title),...readFields(spec.schema,context)};
  if(context.kind)project.kind=context.kind;
  if(kind!=="novel"||context.materials!==undefined)project.materials=(context.materials||[]).map(({id,name,kind})=>{
    if(!Object.hasOwn(placeholder,kind))throw new Error("Invalid material type. 素材类型无效。");
    const mime=placeholder[kind];return {id,name,kind,mime,data:kind==="text"?"x":"data:"+mime+";base64,AA==",credit:"",license:""};
  });
  if(kind==="novel"){
    project.assets=context.assets.map(({id,name,kind})=>({id,name:readFields("bilingual",name),kind,credit:"",src:kind==="image"?"art/placeholder.webp":"sound/placeholder.wav"}));
    if(context.inventory)project.inventory=context.inventory.map(o=>({id:o.id,name:readFields("bilingual",o.name),flag:o.flag,when:o.when,description:{}}));
  }else project.credits={en:"",zh:""};
  checkPilotProject(project);return project;
}
function equalData(a,b){
  if(a===b)return true;
  if(!a||!b||typeof a!=="object"||typeof b!=="object"||Array.isArray(a)!==Array.isArray(b))return false;
  const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&equalData(a[k],b[k]));
}
/** Apply atomically only to a new candidate. The caller separately reviews and commits. */
function buildCandidate(original,proposal,scope,request){
  checkPilotProject(original);checkScope(original,scope);
  if(!proposal||Object.keys(proposal).some(k=>k!=="operations")||!Array.isArray(proposal.operations)||!proposal.operations.length||proposal.operations.length>100)
    throw new Error("Expected 1–100 proposed edits. 需要 1–100 条修改。");
  if(JSON.stringify(proposal).length>400000)throw new Error("Proposal exceeds 400,000 characters. 建议过长。");
  const candidate=structuredClone(original);
  for(const operation of proposal.operations)runOperation(candidate,operation,scope);
  if(pilotKind(candidate)==="novel"){
    const spellings=new Map(candidate.flags.map(f=>[f.normalize("NFC"),f]));
    for(const s of candidate.scenes)for(const c of s.choices)for(const key of CHOICE_RULES){
      const value=c[key];if(typeof value==="string"&&spellings.has(value.normalize("NFC")))c[key]=spellings.get(value.normalize("NFC"));
    }
  }
  const warnings=checkPilotProject(promoteProjectVersion(candidate));
  verifyProtectedLanguages(original,candidate,request);
  if(equalData(original,candidate))throw new Error("The proposal contains no changes. 建议没有带来任何更改。");
  return {candidate,warnings};
}
export function applyProposal(original,proposal,scope=null,options={}){
  try{return buildCandidate(original,proposal,scope,typeof options==="string"?options:options?.prompt);}
  catch(error){throw new Error(error.message+"\nTry one objective in one section. Use its existing IDs and request a new proposal. 可缩小到一个范围、一个目标，使用已有标识并重新生成。");}
}
