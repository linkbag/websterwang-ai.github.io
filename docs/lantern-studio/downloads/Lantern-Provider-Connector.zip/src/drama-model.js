import { rainRegister } from "./drama-sample.js";

export const dramaText = (en = "", zh = "") => ({ en, zh });
const t = dramaText;
export function dramaId(prefix = "drama") {
  const stem = typeof prefix === "string" && /^[A-Za-z0-9_][A-Za-z0-9_-]{0,46}$/.test(prefix) ? prefix : "drama";
  return stem + "_" + crypto.randomUUID().replaceAll("-", "");
}
const safeId = (id) => typeof id === "string" && /^[A-Za-z0-9_][A-Za-z0-9_-]{0,79}$/.test(id) && !["__proto__", "prototype", "constructor"].includes(id);
const record = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const list = (v, max) => Array.isArray(v) && v.length <= max;
const taskTypes = ["collect", "inspect", "order", "match", "hold"];
const local = (v, lang) => v[lang] || v[lang === "zh" ? "en" : "zh"] || "";

export function newDramaAct() {
  return { id: dramaId("act"), title: t("New act", "新一幕"), role: t(), place: t() };
}
export function newDramaBeat(actId) {
  return {
    id: dramaId("beat"), act: actId, title: t("New beat", "新一场"), speaker: "",
    body: t(), image: "", voice: "", task: null, choices: [], ending: false,
  };
}
export function newDramaTask(type = "collect") {
  if (!taskTypes.includes(type)) throw new RangeError("Unknown stage challenge type.");
  const prompts = {
    collect: t("Gather every object.", "收齐每件物品。"),
    inspect: t("Examine every clue.", "逐一查看线索。"),
    order: t("Put the cues in their correct order.", "按先后顺序排列提示。"),
    match: t("Match each item to its group.", "为每一项选出对应的分组。"),
    hold: t("Hold the cue or confirm it in two steps.", "按住提示，或分两步确认。"),
  };
  const targets = type === "match" ? [
    { id: dramaId("group"), label: t("First group", "第一组") },
    { id: dramaId("group"), label: t("Second group", "第二组") },
  ] : [];
  const items = type === "hold" ? [] : [t("First cue", "第一条提示"), t("Second cue", "第二条提示")].map((label, i) => ({
    id: dramaId("cue"), label, detail: t(), target: targets[i]?.id || "", voice: "",
  }));
  return { type, prompt: prompts[type], success: t("The cue is complete.", "这一环节已完成。"), items, targets, holdMs: 1000 };
}
export function createDrama({ blank = false, media = [] } = {}) {
  if (!blank) return rainRegister(media);
  const act = { ...newDramaAct(), id: "act_one", title: t("First act", "第一幕") };
  const opening = { ...newDramaBeat(act.id), id: "opening", title: t("In the wings", "候场"),
    body: t("The stage is yours. Someone in the front row looks up.", "轮到你上场了。第一排有人抬起头。"),
    choices: [{ id: "step_out", label: t("Take the stage", "走上舞台"), reply: t(), to: "curtain_call", needs: [], unless: [], grant: [], take: [] }] };
  const ending = { ...newDramaBeat(act.id), id: "curtain_call", title: t("Curtain call", "谢幕"), ending: true,
    body: t("The curtain falls. Who will you bring on stage next?", "幕布落下。下一次，你想让谁登场？") };
  return {
    version: 7, kind: "stage-drama", id: dramaId("drama"), title: t("Untitled stage drama", "未命名短剧"),
    credits: t(), start: opening.id, materials: [], acts: [act], cast: [], tokens: [], beats: [opening, ending], epilogues: [],
  };
}

export function validateDrama(p, lang = "en") {
  const msg = (en, zh) => lang === "zh" ? zh : en;
  const errors = [], warnings = [];
  function emit(lines, en, zh) {
    if (lines.length < 60) lines.push(msg(en, zh));
    else if (lines.length === 60) lines.push(msg("Additional issues omitted.", "还有其他问题未显示。"));
  }
  const fail = (en, zh) => emit(errors, en, zh);
  const warn = (en, zh) => emit(warnings, en, zh);
  let textSize = 0;
  function text(v, max, name, visible = false) {
    if (!record(v) || !["en", "zh"].every((k) => typeof v[k] === "string" && v[k].length <= max)) {
      fail(`${name} needs English and Chinese text fields of up to ${max} characters each.`, `${name} 需要中、英两个文本字段，每个最多 ${max} 字。`);
      return;
    }
    // A scoped provider context substitutes this exact fixed pair for unrelated prose,
    // including empty fields. It contains none of the author's manuscript.
    if (v.en !== "[withheld]" || v.zh !== "［未分享］") textSize += v.en.length + v.zh.length;
    const en = !!v.en.trim(), zh = !!v.zh.trim();
    if (visible && !en && !zh) warn("Add visible text to " + name + ".", "请填写可见文字：" + name + "。");
    else if (en !== zh) warn("Translation falls back to the other language: " + name, "此处将显示另一种语言：" + name);
  }
  function rows(value, max, name, min = 0) {
    if (!list(value, max) || value.length < min) {
      fail(`${name} must contain ${min}–${max} entries.`, `${name} 应有 ${min} 至 ${max} 项。`);
      return [];
    }
    const ids = new Set(), good = [];
    for (const row of value) {
      if (!record(row) || !safeId(row.id) || ids.has(row.id)) {
        fail("Invalid or duplicate ID in " + name + ".", name + " 中有无效或重复的标识。");
        continue;
      }
      ids.add(row.id);
      good.push(row);
    }
    return good;
  }
  if (!record(p) || p.kind !== "stage-drama" || p.version !== 7 || !safeId(p.id)) {
    fail("Invalid stage drama identity or version.", "短剧标识或版本无效。");
    return { errors, warnings };
  }
  text(p.title, 300, msg("Game title", "剧名"), true);
  text(p.credits, 30000, msg("Credits", "署名"));
  const acts = rows(p.acts, 32, msg("Acts", "幕"), 1);
  const cast = rows(p.cast, 64, msg("Cast", "角色"));
  const tokens = rows(p.tokens, 48, msg("Tokens", "信物"));
  const beats = rows(p.beats, 192, msg("Beats", "场"), 1);
  const epilogues = rows(p.epilogues, 96, msg("Epilogues", "尾声"));
  const materials = rows(p.materials, 256, msg("Materials", "素材"));
  const ids = (items) => new Set(items.map((i) => i.id));
  const actIds = ids(acts), castIds = ids(cast), tokenIds = ids(tokens), beatIds = ids(beats);
  const kinds = new Map(materials.map((m) => [m.id, m.kind]));
  for (const m of materials) if (!["image", "audio", "video", "text"].includes(m.kind))
    fail("Unknown material kind: " + m.id, "素材类型无效：" + m.id);
  function mediaRef(id, kind, name) {
    if (id !== "" && (!safeId(id) || kinds.get(id) !== kind))
      fail("Select an existing " + kind + " material for " + name + ".", "请为 " + name + " 选择已有的" + (kind === "image" ? "图片" : "音频") + "素材。");
  }
  function tokenList(v, name) {
    if (!list(v, 48) || !Array.from(v).every((id) => tokenIds.has(id)) || new Set(v).size !== v.length) {
      fail("Use distinct existing tokens in " + name + ".", name + " 只能引用已有信物，且不能重复。");
      return [];
    }
    return v;
  }
  function pair(a, b, name) {
    const first = tokenList(a, name), second = tokenList(b, name);
    if (first.some((id) => second.includes(id)))
      fail("Contradictory token rules in " + name + ".", name + " 的信物规则互相矛盾。");
  }
  function task(value, name) {
    if (value === null) return;
    if (!record(value) || !taskTypes.includes(value.type)) {
      fail("Choose a supported challenge in " + name + ".", "请为 " + name + " 选择支持的互动类型。");
      return;
    }
    text(value.prompt, 2000, name + " / " + msg("challenge prompt", "任务提示"), true);
    text(value.success, 2000, name + " / " + msg("completion", "完成反馈"));
    if (!Number.isInteger(value.holdMs) || value.holdMs < 250 || value.holdMs > 10000)
      fail("Set the hold duration to 250–10000 ms in " + name + ".", name + " 的按住时长应为 250 至 10000 毫秒。");
    const targets = rows(value.targets, 32, name + " / " + msg("groups", "分组"), value.type === "match" ? 1 : 0);
    const required = value.type === "order" ? 2 : value.type === "hold" ? 0 : 1;
    const items = rows(value.items, 32, name + " / " + msg("challenge items", "互动项目"), required);
    const groups = ids(targets);
    for (const target of targets) text(target.label, 300, name + " / " + target.id, true);
    for (const item of items) {
      const location = name + " / " + item.id;
      text(item.label, 300, location, true);
      text(item.detail, 8000, location + " / " + msg("transcript", "文字说明"));
      mediaRef(item.voice, "audio", location);
      if (typeof item.target !== "string" || (value.type === "match" ? !groups.has(item.target) : item.target !== "" && !safeId(item.target)))
        fail("Invalid challenge group for " + location + ".", location + " 的互动分组无效。");
    }
  }
  if (!beatIds.has(p.start)) fail("Choose an existing opening beat.", "请选择已有的开场。");
  for (const a of acts) {
    text(a.title, 300, a.id, true);
    text(a.role, 300, a.id + " / " + msg("role", "扮演身份"));
    text(a.place, 300, a.id + " / " + msg("setting", "地点"));
    if (!beats.some((b) => b.act === a.id)) warn("This act has no beats: " + a.id, "这幕还没有场：" + a.id);
  }
  for (const c of cast) {
    text(c.name, 300, c.id, true);
    text(c.bio, 30000, c.id + " / " + msg("biography", "小传"));
    mediaRef(c.portrait, "image", c.id);
  }
  for (const token of tokens) text(token.name, 300, token.id, true);
  for (const b of beats) {
    text(b.title, 300, b.id, true);
    text(b.body, 30000, b.id + " / " + msg("script", "正文"), true);
    if (!actIds.has(b.act) || (b.speaker !== "" && !castIds.has(b.speaker)) || typeof b.ending !== "boolean")
      fail("Check the act, speaker and ending setting on " + b.id + ".", "请检查 " + b.id + " 所属的幕、说话者与结局设置。");
    mediaRef(b.image, "image", b.id);
    mediaRef(b.voice, "audio", b.id);
    task(b.task, b.id);
    const choices = rows(b.choices, 24, b.id + " / " + msg("choices", "选项"));
    if (b.ending && choices.length) fail("An ending cannot contain choices: " + b.id, "结局场不能含有选项：" + b.id);
    if (!b.ending && !choices.length) warn("Unfinished beat with no continuation: " + b.id, "这场还没有后续选项：" + b.id);
    for (const c of choices) {
      const location = b.id + " / " + c.id;
      text(c.label, 300, location, true);
      text(c.reply, 8000, location + " / " + msg("reply", "回应"));
      if (!beatIds.has(c.to)) fail("Choose an existing destination for " + location + ".", "请为 " + location + " 选择已有目标场。");
      pair(c.needs, c.unless, location);
      pair(c.grant, c.take, location);
    }
  }
  for (const e of epilogues) {
    text(e.title, 300, e.id, true);
    text(e.body, 30000, e.id + " / " + msg("epilogue", "尾声"), true);
    pair(e.needs, e.unless, e.id);
  }
  if (textSize > 2000000) fail("The script exceeds 2,000,000 characters across both languages.", "双语剧本文字总量超过 2,000,000 字。");
  if (!beats.some((b) => b.ending)) warn("The play has no ending beat yet.", "剧中还没有结局场。");
  return { errors, warnings };
}

// Each state is a beat and the exact set of held tokens. Backward traversal also catches closed loops that have visible choices.
function routes(p, maxStates) {
  const index = new Map(p.tokens.map((v, i) => [v.id, 1n << BigInt(i)]));
  const mask = (values) => values.reduce((bits, id) => bits | index.get(id), 0n);
  const rules = (row) => ({ needs: mask(row.needs), unless: mask(row.unless) });
  const allowed = (rule, held) => (rule.needs & held) === rule.needs && (rule.unless & held) === 0n;
  const beats = new Map(p.beats.map((b) => [b.id, {
    ending: b.ending,
    choices: b.choices.map((c) => ({ ...rules(c), id: c.id, to: c.to, grant: mask(c.grant), take: mask(c.take) })),
  }]));
  const panels = p.epilogues.map((e) => ({ ...rules(e), id: e.id }));
  const queue = [], byKey = new Map(), parents = [];
  const reached = new Set(), taken = new Set(), endings = new Set(), shown = new Set(), dead = new Set(), trapped = new Set(), bare = new Set();
  const finishStates = [], finishes = new Set();
  let capped = false;
  function state(id, held) {
    const key = id + ":" + held;
    if (byKey.has(key)) return byKey.get(key);
    if (queue.length >= maxStates) { capped = true; return -1; }
    const i = queue.length;
    byKey.set(key, i); queue.push({ id, held }); parents.push([]);
    return i;
  }
  state(p.start, 0n);
  for (let i = 0; i < queue.length; i++) {
    const { id, held } = queue[i], beat = beats.get(id);
    reached.add(id);
    if (beat.ending) {
      endings.add(id); finishStates.push(i); finishes.add(i);
      const visible = panels.filter((e) => allowed(e, held));
      for (const e of visible) shown.add(e.id);
      if (panels.length && !visible.length) bare.add(id);
      continue;
    }
    let legal = false;
    for (const c of beat.choices) {
      if (!allowed(c, held)) continue;
      legal = true; taken.add(id + "/" + c.id);
      const next = state(c.to, (held & ~c.take) | c.grant);
      if (next >= 0) parents[next].push(i);
    }
    if (!legal) dead.add(id);
  }
  if (!capped) {
    for (let i = 0; i < finishStates.length; i++) {
      for (const parent of parents[finishStates[i]]) {
        if (finishes.has(parent)) continue;
        finishes.add(parent); finishStates.push(parent);
      }
    }
    queue.forEach((s, i) => { if (!finishes.has(i)) trapped.add(s.id); });
  }
  return { reached, taken, endings, shown, dead, trapped, bare, states: queue.length, capped };
}

export function inspectDrama(p, lang = "en", { maxStates = 4000 } = {}) {
  const validation = validateDrama(p, lang);
  if (validation.errors.length) return { ...validation, info: [], lines: validation.errors, stats: null };
  const t = (en, zh) => lang === "zh" ? zh : en;
  const budget = Number.isFinite(maxStates) ? Math.max(1, Math.min(8000, Math.floor(maxStates))) : 4000;
  const r = routes(p, budget);
  const name = (row) => local(row.title || row.label, lang) || row.id;
  const info = [t(
    `${r.reached.size}/${p.beats.length} beats reachable · ${r.endings.size} reachable ending${r.endings.size === 1 ? "" : "s"} · ${r.shown.size}/${p.epilogues.length} epilogue panels found.`,
    `可达场 ${r.reached.size}/${p.beats.length}，可达结局 ${r.endings.size} 个，已找到尾声 ${r.shown.size}/${p.epilogues.length} 篇。`,
  )];
  const warnings = [];
  const note = (message) => {
    if (warnings.length < 160) warnings.push(message);
    else if (warnings.length === 160) warnings.push(t("Additional diagnostics omitted.", "还有其他检查结果未显示。"));
  };
  if (r.capped) note(t("Search budget reached. Play unconfirmed routes manually.", "已达搜索上限。尚未确认的路线需要手动试玩。"));
  else if (!r.endings.size) note(t("No ending is reachable from the opening.", "从开场无法到达结局。"));
  for (const b of p.beats) {
    if (r.endings.has(b.id)) info.push(t("Reachable ending: ", "可达结局：") + name(b));
    if (r.dead.has(b.id)) note(t("No choice is available with one reachable token set: ", "某种可达信物组合下没有可用选项：") + name(b));
    else if (r.trapped.has(b.id)) note(t("A reachable route from this beat cannot finish: ", "从这场出发的某条可达路线无法结束：") + name(b));
    if (r.bare.has(b.id)) note(t("No epilogue panel appears with one ending token set: ", "某种结局信物组合下不显示任何尾声：") + name(b));
    if (r.capped) continue;
    if (!r.reached.has(b.id)) {
      note(t(b.ending ? "Unreachable ending: " : "Unreachable beat: ", b.ending ? "无法到达的结局：" : "无法到达的场：") + name(b));
    } else for (const c of b.choices) {
      if (!r.taken.has(b.id + "/" + c.id)) note(t("Blocked choice: ", "始终被条件阻挡的选项：") + name(b) + " / " + name(c));
    }
  }
  for (const e of p.epilogues) {
    if (r.shown.has(e.id)) info.push(t("Reachable epilogue: ", "可达尾声：") + name(e));
    else if (!r.capped) note(t("Unreachable epilogue: ", "无法到达的尾声：") + name(e));
  }
  for (const warning of validation.warnings) note(warning);
  const stats = { reachableBeats: r.reached.size, reachableEndings: r.endings.size, reachableEpilogues: r.shown.size, states: r.states, capped: r.capped };
  return { errors: [], warnings, info, lines: [info[0], ...warnings, ...info.slice(1)], stats };
}

export function checkDrama(p, lang = "en", options) {
  return inspectDrama(p, lang, options).lines;
}
