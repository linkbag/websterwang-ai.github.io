const MiB = 1024 * 1024;
export const CATALOG_LIMIT = 128 * MiB;
export const PROJECT_MEDIA_LIMIT = 64 * MiB;
export const mediaTypes = {
  image: {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/webp": "webp",
    "image/gif": "gif",
    "image/avif": "avif",
  },
  audio: {
    "audio/mpeg": "mp3",
    "audio/mp3": "mp3",
    "audio/wav": "wav",
    "audio/x-wav": "wav",
    "audio/wave": "wav",
    "audio/ogg": "ogg",
    "audio/webm": "webm",
    "audio/mp4": "m4a",
    "audio/aac": "aac",
    "audio/flac": "flac",
    "audio/x-m4a": "m4a",
  },
  video: { "video/mp4": "mp4", "video/webm": "webm", "video/ogg": "ogv" },
  text: { "text/plain": "txt", "text/markdown": "md" },
};
export const materialAccept = [
  ...Object.values(mediaTypes).flatMap((group) => Object.keys(group)),
  ".md",
  ".txt",
].join(",");
export function fileType(file) {
  const type = file.type?.split(";")[0].toLowerCase();
  for (const [kind, group] of Object.entries(mediaTypes))
    if (Object.hasOwn(group, type)) return { kind, mime: type };
  if (type && type !== "application/octet-stream") return null;
  const ext = file.name?.split(".").pop()?.toLowerCase();
  if (["jpeg", "jpe", "jfif"].includes(ext))
    return { kind: "image", mime: "image/jpeg" };
  if (ext === "markdown") return { kind: "text", mime: "text/markdown" };
  if (ext === "oga") return { kind: "audio", mime: "audio/ogg" };
  if (ext === "wave") return { kind: "audio", mime: "audio/wav" };
  for (const [kind, group] of Object.entries(mediaTypes)) {
    const found = Object.entries(group).find(
      ([, suffix]) => suffix === ext && suffix !== "webm",
    );
    if (found) return { kind, mime: found[0] };
  }
  if (ext === "webm") return { kind: "video", mime: "video/webm" };
  return null;
}
export const maxMaterialBytes = (kind) =>
  (kind === "video" ? 32 : kind === "text" ? 1 : 16) * MiB;
export function materialBytes(item) {
  if (
    !item ||
    !Object.hasOwn(mediaTypes, item.kind) ||
    !Object.hasOwn(mediaTypes[item.kind], item.mime) ||
    typeof item.data !== "string"
  )
    return -1;
  if (item.kind === "text")
    return item.data.length <= MiB
      ? new TextEncoder().encode(item.data).length
      : -1;
  const prefix = "data:" + item.mime + ";base64,";
  if (!item.data.startsWith(prefix)) return -1;
  const size = item.data.length - prefix.length;
  if (
    !size ||
    size % 4 ||
    size > 4 * Math.ceil(maxMaterialBytes(item.kind) / 3)
  )
    return -1;
  const encoded = item.data.slice(prefix.length);
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) return -1;
  return (
    (size / 4) * 3 -
    (encoded.endsWith("==") ? 2 : encoded.endsWith("=") ? 1 : 0)
  );
}
export function validateMaterial(item, lang = "en") {
  const t = (en, zh) => (lang === "zh" ? zh : en);
  if (
    !item ||
    typeof item.id !== "string" ||
    !/^[A-Za-z0-9_][A-Za-z0-9_-]{0,79}$/.test(item.id) ||
    ["__proto__", "constructor", "prototype"].includes(item.id)
  )
    return t("Invalid material ID.", "素材标识无效。");
  if (
    typeof item.name !== "string" ||
    !item.name.trim() ||
    item.name.length > 300
  )
    return t(
      "Give the material a name of up to 300 characters.",
      "请填写不超过 300 字的素材名称。",
    );
  const size = materialBytes(item);
  if (size <= 0 || size > maxMaterialBytes(item.kind))
    return t(
      "Unsupported or empty material. Use up to 16 MiB for images or audio, 32 MiB for video, or 1 MiB for text.",
      "素材格式不支持、内容为空或过大。图像和音频上限 16 MiB，视频 32 MiB，文本 1 MiB。",
    );
  const limits = { credit: 2000, license: 1000, source: 2000, prompt: 12000 };
  if (
    Object.entries(limits).some(
      ([key, max]) =>
        item[key] !== undefined &&
        (typeof item[key] !== "string" || item[key].length > max),
    )
  )
    return t(
      "Material metadata is too long or invalid.",
      "素材信息过长或格式无效。",
    );
  if (
    item.tags !== undefined &&
    (!Array.isArray(item.tags) ||
      item.tags.length > 30 ||
      item.tags.some((tag) => typeof tag !== "string" || tag.length > 80))
  )
    return t(
      "Use up to 30 tags of 80 characters each.",
      "最多可填 30 个标签，每个不超过 80 字。",
    );
  if (item.inGallery !== undefined && typeof item.inGallery !== "boolean")
    return t(
      "The player gallery setting must be on or off.",
      "玩家素材集的显示选项必须是布尔值。",
    );
  return "";
}
export function validateProjectMaterials(project, lang = "en") {
  const items = project?.materials;
  if (items === undefined) return [];
  const t = (en, zh) => (lang === "zh" ? zh : en);
  if (!Array.isArray(items) || items.length > 256)
    return [t("Use up to 256 project materials.", "工程素材不能超过 256 项。")];
  const ids = new Set();
  let size = 0;
  for (const item of items) {
    const problem = validateMaterial(item, lang);
    if (problem) return [problem];
    if (ids.has(item.id))
      return [
        t("Duplicate project material ID.", "工程中存在重复的素材标识。"),
      ];
    ids.add(item.id);
    size += materialBytes(item);
  }
  if (Array.isArray(project.assets))
    for (const asset of project.assets) {
      if (typeof asset?.src === "string" && asset.src.startsWith("data:"))
        size += Math.floor(
          (asset.src.length - asset.src.indexOf(",") - 1) * 0.75,
        );
    }
  return size > PROJECT_MEDIA_LIMIT
    ? [
        t(
          "Embedded project media exceeds 64 MiB. Use a shorter clip or fewer materials.",
          "工程内嵌素材超过 64 MiB，请缩短视频或减少素材。",
        ),
      ]
    : [];
}
export const newMaterialId = () =>
  "material_" + crypto.randomUUID().replaceAll("-", "");
export function portableMaterial(item) {
  return {
    id: item.id,
    name: item.name,
    kind: item.kind,
    mime: item.mime,
    data: item.data,
    credit: item.credit || "",
    source: item.source || "",
    license: item.license || "",
    prompt: item.prompt || "",
    tags: [...(item.tags || [])],
  };
}

// Check newly acquired files before they enter the collection. Existing projects
// and backup archives retain their original bytes, including legacy codecs.
export async function checkMaterialContent(item, lang = "en") {
  const t = (en, zh) => lang === "zh" ? zh : en;
  const bytes = materialBytes(item);
  if (bytes <= 0 || bytes > maxMaterialBytes(item.kind))
    throw Error(t("The material is empty, too large or has an unsupported type.", "素材为空、过大或格式不受支持。"));
  if (item.kind === "text") {
    if (item.data.includes("\0")) throw Error(t("This file contains binary data. Save the note as UTF-8 or UTF-16 text.", "文件含有二进制数据。请将笔记另存为 UTF-8 或 UTF-16 文本。"));
    return;
  }
  const start = item.data.indexOf(",") + 1;
  const head = atob(item.data.slice(start, start + 4096));
  const frame = (head.charCodeAt(0) === 255 && (head.charCodeAt(1) & 224) === 224);
  const wave = ["RIFF","RIFX","RF64"].includes(head.slice(0,4)) && head.slice(8,12) === "WAVE";
  const boxType = head.slice(4,8);
  const boxSize = head.length >= 8 ? [...head.slice(0,4)].reduce((size,ch) => size * 256 + ch.charCodeAt(0),0) : -1;
  // Older MOV/MP4 writers can place a media, movie, or padding box first.
  const isoMedia = ["ftyp","moov","mdat","free","skip","wide"].includes(boxType) &&
    (boxSize === 0 || (boxSize === 1 && bytes >= 16) || (boxSize >= 8 && boxSize <= bytes));
  const webm = head.startsWith("\x1a\x45\xdf\xa3"), ogg = head.startsWith("OggS");
  const signatures = {
    "image/png": head.startsWith("\x89PNG\r\n\x1a\n"),
    "image/jpeg": head.startsWith("\xff\xd8\xff"),
    "image/gif": head.startsWith("GIF87a") || head.startsWith("GIF89a"),
    "image/webp": head.startsWith("RIFF") && head.slice(8,12) === "WEBP",
    "image/avif": isoMedia && boxType === "ftyp" && /avif|avis/.test(head),
    "audio/mpeg": head.startsWith("ID3") || frame, "audio/mp3": head.startsWith("ID3") || frame,
    "audio/wav": wave, "audio/x-wav": wave, "audio/wave": wave,
    "audio/ogg": ogg, "video/ogg": ogg, "audio/webm": webm, "video/webm": webm,
    "audio/mp4": isoMedia, "audio/x-m4a": isoMedia, "video/mp4": isoMedia,
    "audio/aac": head.startsWith("ID3") || head.startsWith("ADIF") || frame,
    "audio/flac": head.startsWith("fLaC") || head.startsWith("ID3"),
  };
  if (!signatures[item.mime]) throw Error(t("The file contents do not match this media type. Check the original file or export it again.", "文件内容与素材类型不符。请检查原文件或重新导出。"));
  if (item.kind === "image") {
    const image = new Image();
    image.src = item.data;
    try { await image.decode(); if (!image.naturalWidth || !image.naturalHeight) throw Error(); }
    catch { throw Error(t("This browser could not read the image pixels. Open the original and export a PNG or JPEG.", "此浏览器无法读取图像像素。请打开原图并导出 PNG 或 JPEG。")); }
  }
}

async function readNote(file, lang) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const encoding = bytes[0] === 255 && bytes[1] === 254 ? "utf-16le" :
    bytes[0] === 254 && bytes[1] === 255 ? "utf-16be" : "utf-8";
  try { return new TextDecoder(encoding, { fatal:true }).decode(bytes); }
  catch { throw Error(lang === "zh" ? "无法读取文本编码。请另存为 UTF-8 或带字节序标记的 UTF-16。" : "Unable to read this text encoding. Save as UTF-8 or UTF-16 with a byte-order mark."); }
}
export async function materialFromFile(file, lang = "en") {
  const type = fileType(file);
  if (!type || !file.size || file.size > maxMaterialBytes(type.kind))
    throw new Error(
      lang === "zh"
        ? "请选择支持的媒体文件，图像/音频上限 16 MiB，视频 32 MiB，文本 1 MiB。"
        : "Choose a supported file up to 16 MiB for images/audio, 32 MiB for video or 1 MiB for text.",
    );
  const data =
    type.kind === "text"
      ? await readNote(file, lang)
      : "data:" +
        type.mime +
        ";base64," +
        (await new Promise((ok, no) => {
          const reader = new FileReader();
          reader.onload = () => ok(String(reader.result).split(",")[1]);
          reader.onerror = () => no(reader.error);
          reader.readAsDataURL(file);
        }));
  const item = portableMaterial({
    id: newMaterialId(),
    name: file.name,
    ...type,
    data,
  });
  await checkMaterialContent(item, lang);
  return item;
}
export function materialAssignments(project) {
  // Story assets have their own embedded bytes and ID namespace. Collection
  // copies, game IDs, narrative strings and flag names are not media bindings.
  return new Set([
    project.presentation?.playerSprite, project.presentation?.soundtrack,
    project.room?.background, project.room?.ambience,
    project.encounter?.image, project.encounter?.audio,
    project.rpg?.cover, project.rpg?.music,
    ...(project.segments || []).flatMap(s => [s.video,s.poster]),
    ...(project.passages || []).flatMap(p => [p.image,p.audio]),
    ...(project.kind === "stage-drama" ? project.cast.map(member => member.portrait) : []),
    ...(project.kind === "stage-drama" ? project.beats.flatMap(beat => [beat.image, beat.voice, ...(beat.task?.items || []).map(item => item.voice)]) : []),
    ...(project.hotspots || []).flatMap(h => h.actions.map(a => a.material)),
  ].filter(Boolean));
}
export function playableMaterialsProject(project) {
  if (!Array.isArray(project.materials)) return project;
  const { materials, ...body } = project;
  const references = materialAssignments(project);
  const used = materials
    .filter((m) => references.has(m.id))
    .map(({ id, name, kind, mime, data, credit, license, source }) => ({
      id,
      name,
      kind,
      mime,
      data,
      credit,
      license,
      source,
    }));
  return used.length ? { ...body, materials: used } : body;
}
