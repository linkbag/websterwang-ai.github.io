import { request as httpsRequest } from 'node:https';
import { Readable } from 'node:stream';

const glmChatUrls = new Set([
  'https://open.bigmodel.cn/api/paas/v4/chat/completions',
  'https://api.z.ai/api/paas/v4/chat/completions',
]);
const maximumBytes = 1024 * 1024;
const sizeError = () => new Error('The provider response exceeded its size limit. 模型回复过大。');

// The shared browser client supplies a URL, JSON string, credential headers and a deadline signal.
// Other destinations retain the platform fetch implementation, including account sign-in.
export function createNodeProviderFetch({ request = httpsRequest, fallback = globalThis.fetch } = {}) {
  return async function nodeFetch(input, init = {}) {
    const address = input instanceof URL ? input.href : input;
    if (!glmChatUrls.has(address) || init.method !== 'POST') return fallback(input, init);
    init.signal?.throwIfAborted();
    if (typeof init.body !== 'string') throw new TypeError('Expected a JSON request body.');
    const headers = Object.fromEntries(new Headers(init.headers));
    return new Promise((resolve, reject) => {
      const req = request(address, { method: 'POST', headers, signal: init.signal }, message => {
        const status = message.statusCode;
        if (status >= 300 && status < 400) {
          message.destroy();
          reject(new Error('The provider returned a redirect. 服务商返回了重定向。'));
          return;
        }
        if (Number(message.headers['content-length']) > maximumBytes) {
          message.destroy();
          reject(sizeError());
          return;
        }
        const headers = new Headers();
        for (let i = 0; i < message.rawHeaders.length; i += 2) {
          headers.append(message.rawHeaders[i], message.rawHeaders[i + 1]);
        }
        if (status === 204 || status === 205) {
          message.resume();
          resolve(new Response(null, { status, headers }));
          return;
        }
        let received = 0;
        const incoming = Readable.toWeb(message, { strategy: { highWaterMark: 64 * 1024, size: chunk => chunk.byteLength } });
        const body = incoming.pipeThrough(new TransformStream({
          transform(chunk, controller) {
            received += chunk.byteLength;
            if (received > maximumBytes) throw sizeError();
            controller.enqueue(chunk);
          },
        }));
        resolve(new Response(body, { status, headers }));
      });
      req.once('error', reject);
      req.end(init.body);
    });
  };
}

export const nodeProviderFetch = createNodeProviderFetch();
