import { createHash, randomBytes, randomUUID } from "node:crypto";
import {
  link,
  mkdir,
  readFile,
  readdir,
  unlink,
  writeFile,
} from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";
import {
  hasPlan,
  http,
  issuer,
  json,
  requireOk,
  resource,
  responseText,
  revokeUrl,
  scopes,
  tokenUrl,
  verifyIdentity,
} from "./pilot-chatgpt-protocol.mjs";

const opaque = () => randomBytes(32).toString("base64url");
const digest = (value) =>
  createHash("sha256").update(value).digest("base64url");
const validId = (v) =>
  typeof v === "string" &&
  /^[A-Za-z0-9_-]{1,256}$/.test(v) &&
  v !== "dynamic_agent_client";
const validModel = (v) =>
  typeof v === "string" && /^[A-Za-z0-9][A-Za-z0-9._:/@-]{0,199}$/.test(v);
const seconds = 1000;
const minute = 60 * seconds;

// Publish immutable registration metadata with an atomic create-only link. A second
// process racing a first sign-in must use the winning host ID and account mapping.
async function createOnce(file, text) {
  const temp = file + "." + randomUUID() + ".tmp";
  await writeFile(temp, text, { mode: 0o600, flag: "wx" });
  try {
    await link(temp, file);
  } catch (e) {
    if (e.code !== "EEXIST") throw e;
  } finally {
    await unlink(temp);
  }
  return readFile(file, "utf8");
}

export function chatgptConnector({
  port,
  fetchImpl = fetch,
  now = Date.now,
  directory = join(homedir(), ".lantern-studio", "chatgpt"),
}) {
  const callbackUri = "http://127.0.0.1:" + port + "/auth/callback";
  const flows = new Map();
  const profilesPath = join(directory, "registrations");
  const exchange = async (params) =>
    json(
      await requireOk(
        await http(fetchImpl, tokenUrl, {
          method: "POST",
          body: new URLSearchParams(params),
        }),
      ),
    );
  async function profiles() {
    let names;
    try {
      names = await readdir(profilesPath);
    } catch (e) {
      if (e.code === "ENOENT") return [];
      throw e;
    }
    const rows = await Promise.all(
      names
        .filter((name) => /^[\w-]{43}\.json$/.test(name))
        .map(async (name) => {
          const data = JSON.parse(
            await readFile(join(profilesPath, name), "utf8"),
          );
          if (
            !validId(data.id) ||
            digest(data.id) + ".json" !== name ||
            typeof data.sub !== "string"
          )
            throw Error(
              "Invalid Lantern registration file. Lantern 的注册记录无效。",
            );
          return data;
        }),
    );
    return rows.sort((a, b) => a.id.localeCompare(b.id));
  }
  const label = (p) =>
    (p.email || "ChatGPT") + " · " + digest(p.id).slice(0, 6);
  function prune() {
    for (const [key, f] of flows) if (f.until <= now()) flows.delete(key);
  }
  function session(key) {
    prune();
    const row = flows.get(key);
    if (!row)
      throw Error(
        "Connection expired. Continue with ChatGPT again. 连接已过期，请重新使用 ChatGPT 登录。",
      );
    return row;
  }
  async function start(profile, consent = false) {
    prune();
    if (flows.size >= 24)
      throw Error(
        "Close an earlier sign-in or try again later. 请先关闭之前的连接或稍后重试。",
      );
    const account = profile
      ? (await profiles()).find((p) => p.id === profile)
      : null;
    if (profile && !account)
      throw Error("Unknown saved account. 未找到此账户。");
    await mkdir(directory, { recursive: true, mode: 0o700 });
    let host;
    const path = join(directory, "host-id");
    try {
      host = await readFile(path, "utf8");
    } catch (e) {
      if (e.code !== "ENOENT") throw e;
      host = await createOnce(path, "urn:uuid:" + randomUUID());
    }
    if (
      !/^urn:uuid:[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(
        host,
      )
    )
      throw Error("Invalid Lantern host registration. Lantern 主机标识无效。");
    const handle = opaque(),
      state = opaque(),
      nonce = opaque(),
      verifier = opaque();
    const url = new URL(issuer + "/api/accounts/authorize");
    const params = {
      client_id: account?.id || "dynamic_agent_client",
      ext_agent_host_id: host,
      response_type: "code",
      redirect_uri: callbackUri,
      scope: scopes,
      resource,
      state,
      nonce,
      code_challenge_method: "S256",
      code_challenge: digest(verifier),
    };
    if (!account) params.agent_name_hint = "Lantern Studio";
    else if (account.email) params.login_hint = account.email;
    if (account && consent === true) params.prompt = "consent";
    url.search = new URLSearchParams(params);
    flows.set(handle, {
      state,
      nonce,
      verifier,
      account,
      status: "pending",
      until: now() + 8 * minute,
      lifetime: new AbortController(),
    });
    return { handle, url: url.href };
  }
  const tokenFields = (packet, previous) => {
    if (
      String(packet.token_type).toLowerCase() !== "bearer" ||
      typeof packet.access_token !== "string" ||
      !packet.access_token ||
      !Number.isFinite(packet.expires_in) ||
      packet.expires_in <= 0
    )
      throw Error("Invalid OpenAI token response. OpenAI 授权数据无效。");
    const granted =
      typeof packet.scope === "string"
        ? packet.scope.split(/\s+/)
        : previous?.scopes || [];
    const refresh = packet.refresh_token;
    if (
      granted.includes("offline_access") &&
      (typeof refresh !== "string" || !refresh)
    )
      throw Error(
        "OpenAI did not return the renewable token. 请重新登录以获取有效的续期凭据。",
      );
    return {
      access: packet.access_token,
      refresh,
      expires: now() + packet.expires_in * seconds,
      scopes: granted,
    };
  };
  async function callback(query) {
    prune();
    const get = (name) =>
      query.getAll(name).length === 1 ? query.get(name) : null;
    const state = get("state");
    const f =
      state &&
      [...flows.values()].find(
        (v) => v.state === state && v.status === "pending",
      );
    if (!f) throw Error("Unknown or expired sign-in. 此次登录已过期或无效。");
    f.status = "checking";
    delete f.state;
    let finished;
    f.checking = new Promise((resolve) => {
      finished = resolve;
    });
    try {
      if (query.has("error"))
        throw Error("ChatGPT sign-in was declined. ChatGPT 登录授权已取消。");
      const code = get("code"),
        id = query.has("client_id") ? get("client_id") : f.account?.id;
      if (
        !code ||
        code.length > 8192 ||
        !validId(id) ||
        (f.account && id !== f.account.id)
      )
        throw Error(
          "Invalid ChatGPT registration callback. ChatGPT 返回的注册信息无效。",
        );
      const packet = await exchange({
        grant_type: "authorization_code",
        client_id: id,
        code,
        code_verifier: f.verifier,
        redirect_uri: callbackUri,
        resource,
      });
      // A cancellation during verification still revokes this newly issued grant.
      f.issuedId = id;
      if (typeof packet.refresh_token === "string")
        f.pendingRefresh = packet.refresh_token;
      const identity = await verifyIdentity(packet.id_token, {
        clientId: id,
        nonce: f.nonce,
        now,
        fetcher: fetchImpl,
      });
      if (f.account && identity.sub !== f.account.sub)
        throw Error(
          "The selected account identity changed. 已选择的账户身份不一致。",
        );
      if (![...flows.values()].includes(f))
        throw Error("Connection closed. 连接已关闭。");
      await mkdir(profilesPath, { recursive: true, mode: 0o700 });
      const account = {
        id,
        sub: identity.sub,
        email:
          identity.email_verified === true && typeof identity.email === "string"
            ? identity.email.slice(0, 254)
            : "",
      };
      const saved = JSON.parse(
        await createOnce(
          join(profilesPath, digest(id) + ".json"),
          JSON.stringify(account),
        ),
      );
      if (saved.id !== id || saved.sub !== identity.sub)
        throw Error(
          "ChatGPT account registration mismatch. ChatGPT 账户注册信息不一致。",
        );
      if (![...flows.values()].includes(f))
        throw Error("Connection closed. 连接已关闭。");
      f.account = saved;
      f.until = now() + 24 * 60 * minute;
      if (
        !hasPlan(
          typeof packet.scope === "string" ? packet.scope.split(/\s+/) : [],
        )
      ) {
        f.needsPermission = true;
        f.tokens = {
          refresh:
            typeof packet.refresh_token === "string"
              ? packet.refresh_token
              : "",
        };
        throw Error(
          "Signed in. Permission to use your ChatGPT plan was not granted. Review plan permissions or choose another provider. 已登录，但未授予套餐额度权限。请重新审阅授权或切换服务商。",
        );
      }
      f.tokens = tokenFields(packet);
      delete f.pendingRefresh;
      const response = await http(fetchImpl, resource + "/models", {
        headers: { Authorization: "Bearer " + f.tokens.access },
      });
      const catalog = await json(await requireOk(response), 512_000);
      f.models = (Array.isArray(catalog.models) ? catalog.models : [])
        .filter((m) => m.visibility === "list" && validModel(m.slug))
        .map((m) => ({
          id: m.slug,
          label:
            typeof m.display_name === "string"
              ? m.display_name.slice(0, 200)
              : m.slug,
        }))
        .slice(0, 150);
      if (!f.models.length)
        throw Error(
          "OpenAI offered no available models for this account. OpenAI 未向此账户提供可用模型。",
        );
      f.status = "ready";
    } catch (e) {
      f.status = "failed";
      f.error = e.message;
      f.until = now() + 8 * minute;
      throw e;
    } finally {
      delete f.verifier;
      delete f.nonce;
      finished();
      delete f.checking;
    }
  }
  async function currentToken(f) {
    if (f.tokens.expires > now() + 20 * seconds) return f.tokens.access;
    if (!f.tokens.refresh)
      throw Error("Please sign in to ChatGPT again. 请重新登录 ChatGPT。");
    f.refreshing ||= exchange({
      grant_type: "refresh_token",
      client_id: f.account.id,
      refresh_token: f.tokens.refresh,
      resource,
    })
      .then((packet) => {
        const tokens = tokenFields(packet, f.tokens);
        if (!hasPlan(tokens.scopes))
          throw Error(
            "The ChatGPT plan grant changed. Please sign in again. 套餐权限已更改，请重新登录。",
          );
        f.tokens = tokens;
        return tokens.access;
      })
      .catch((err) => {
        if (
          [
            "invalid_grant",
            "invalid_refresh_token",
            "token_expired",
            "refresh_token_expired",
            "refresh_token_invalidated",
            "refresh_token_reused",
          ].includes(err.providerCode)
        )
          f.tokens.refresh = "";
        throw err;
      })
      .finally(() => {
        delete f.refreshing;
      });
    return f.refreshing;
  }
  async function logout(handle) {
    const f = flows.get(handle);
    flows.delete(handle);
    if (!f) return { revoked: true };
    f.lifetime.abort();
    if (f.checking) await f.checking;
    if (f.refreshing) await f.refreshing.catch(() => {});
    const refresh = f.tokens?.refresh || f.pendingRefresh;
    if (!refresh) return { revoked: true };
    const form = new URLSearchParams({
      token: refresh,
      token_type_hint: "refresh_token",
      client_id: f.account?.id || f.issuedId,
    });
    delete f.tokens;
    delete f.pendingRefresh;
    for (let attempt = 0; attempt < 2; attempt++) {
      if (attempt) await new Promise((resolve) => setTimeout(resolve, 350));
      try {
        const response = await http(fetchImpl, revokeUrl, {
          method: "POST",
          body: form,
          signal: AbortSignal.timeout(4500),
        });
        await response.body?.cancel();
        if (response.status === 200) return { revoked: true };
        if (response.status < 500) break;
      } catch {}
    }
    return { revoked: false };
  }
  return {
    start,
    callback,
    logout,
    async accounts() {
      return {
        chatgptConnector: 1,
        accounts: (await profiles()).map((p) => ({
          id: p.id,
          label: label(p),
        })),
      };
    },
    status(handle) {
      const f = session(handle);
      return {
        status: f.status,
        ...(f.status === "failed"
          ? { error: f.error, needsPermission: Boolean(f.needsPermission) }
          : {}),
        ...(f.status === "ready"
          ? { account: label(f.account), models: f.models }
          : {}),
      };
    },
    inference(handle, model) {
      const f = session(handle);
      if (f.status !== "ready" || !f.models.some((m) => m.id === model))
        throw Error(
          "Choose a model listed by this ChatGPT account. 请选择此 ChatGPT 账户可用的模型。",
        );
      return async (input) => {
        if (f.lifetime.signal.aborted)
          throw Error("Connection closed. 连接已关闭。");
        const token = await currentToken(f);
        if (flows.get(handle) !== f)
          throw Error("Connection closed. 连接已关闭。");
        const signal = input.signal
          ? AbortSignal.any([input.signal, f.lifetime.signal])
          : f.lifetime.signal;
        return responseText(fetchImpl, token, { ...input, signal });
      };
    },
  };
}
