import { constants } from 'node:fs';
import { copyFile, link, open, readFile, stat, unlink } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';
import { nodeProviderFetch } from './pilot-node-transport.mjs';
import { answerProject as answer, proposeProject as propose, providerAddress, findProvider, checkModel } from '../src/pilot-provider.js';
export { providerAddress };
export const answerProject = options => answer({ ...options, fetchImpl: options.fetchImpl ?? nodeProviderFetch });
export const proposeProject = options => propose({ ...options, fetchImpl: options.fetchImpl ?? nodeProviderFetch });

// Only Lantern's explicit relay configuration is read. The launcher never imports
// account files or adopts a credential set for another application.
export function providerOptions(env) {
  const selected = env.LANTERN_AI_PROVIDER;
  const bases = [env.LANTERN_AI_BASE, env.LANTERN_AI_BASE_URL].filter(Boolean);
  const provider = findProvider(selected || bases[0]);
  if (bases.some(base => findProvider(base).id !== provider.id)) {
    throw new Error('Conflicting provider settings. 服务商配置不一致。');
  }
  const apiKey = env.LANTERN_AI_API_KEY || env.LANTERN_AI_KEY;
  providerAddress(provider.base, apiKey);
  return { base: provider.base, provider, model: checkModel(env.LANTERN_AI_MODEL || provider.defaultModel), apiKey, jsonMode: jsonModeFromEnv(env) };
}
export function jsonModeFromEnv(env){
  const value=env.LANTERN_AI_JSON_MODE;
  if(value===undefined||value==='')return undefined;
  return ['1','schema'].includes(value)?'schema':value==='object'?'object':'off';
}
const usage = `Lantern Cloud Copilot · 云端创作助手
node scripts/pilot.mjs --in original.json --out candidate.json --prompt "Make the first choice harder."
node scripts/pilot.mjs --in 原稿.json --out 审阅稿.json --prompt "让两个选项更有悬念"
node scripts/pilot.mjs --in film.json --question "Which endings can I reach?" --lang en
Use --scope section_id to share and edit one existing section. Omit it for a whole project.
使用 --scope 指定已有场景、关卡或段落。省略即共享全工程。
Set LANTERN_AI_PROVIDER, LANTERN_AI_MODEL and LANTERN_AI_KEY in your environment.
Choose openrouter, glm-cn, glm-global, deepseek, gemini or openai.
The configured provider receives the manuscript and request. A new file contains its validated proposal.
指定的模型服务会收到剧本及要求。助手将经过校验的建议保存到一个新文件中，供你审阅。`;

export async function runPilot(args, env = process.env, { fetchImpl = nodeProviderFetch } = {}) {
  const { values } = parseArgs({ args, options: {
    in: { type: 'string' }, out: { type: 'string' }, prompt: { type: 'string' }, question:{type:'string'},scope:{type:'string'},lang:{type:'string'},help: { type: 'boolean' },
  } });
  if (values.help) return usage;
  if (!values.in || (!values.question && (!values.out || !values.prompt)) || (values.question && (values.out || values.prompt))) throw new Error(usage);
  if ((await stat(values.in)).size > 110 * 1024 * 1024) throw new Error('The input project exceeds 110 MiB. 输入项目超过 110 MiB。');
  const project = JSON.parse((await readFile(values.in, 'utf8')).replace(/^\uFEFF/, ''));
  const options={project,...providerOptions(env),scope:values.scope??null,lang:values.lang,fetchImpl};
  if(values.question)return (await answerProject({...options,prompt:values.question})).answer;
  if (resolve(values.in) === resolve(values.out)) throw new Error('Choose a new output filename. 请使用新的输出文件名。');
  let exists = true;
  try { await stat(values.out); } catch (error) { if (error.code !== 'ENOENT') throw error; exists = false; }
  if (exists) throw new Error('Output already exists. Choose a new filename. 输出文件已存在，请另取文件名。');
  const { candidate, warnings } = await proposeProject({...options,prompt:values.prompt});
  const staged = resolve(dirname(values.out), '.lantern-proposal-' + randomUUID() + '.tmp');
  const output = await open(staged, 'wx', 0o600);
  try {
    try { await output.writeFile(JSON.stringify(candidate, null, 2) + '\n', 'utf8'); await output.sync(); }
    finally { await output.close(); }
    try { await link(staged, values.out); }
    catch (error) {
      if (!['ENOTSUP', 'EOPNOTSUPP', 'EPERM'].includes(error.code)) throw error;
      await copyFile(staged, values.out, constants.COPYFILE_EXCL);
    }
  } finally { await unlink(staged).catch(error => { if (error.code !== 'ENOENT') throw error; }); }
  return [`Review the candidate before importing. 请审阅后再导入。 ${values.out}`, ...warnings].join('\n');
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  runPilot(process.argv.slice(2)).then(result => console.log(result)).catch(error => {
    console.error(error.message);
    process.exitCode = 1;
  });
}
