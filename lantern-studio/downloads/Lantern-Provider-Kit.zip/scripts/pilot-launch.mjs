import { createServer } from "node:http";
import { stat, readFile, open } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createInterface } from "node:readline/promises";
import { Writable } from "node:stream";
import { spawn } from "node:child_process";
import { parseArgs } from "node:util";
import { pilotMiddleware } from "./pilot-studio.mjs";
import { nodeProviderFetch } from "./pilot-node-transport.mjs";
import { providerOptions } from "./pilot.mjs";
import { providerCatalog, findProvider } from "../src/pilot-provider.js";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const askWith = (input, output) => {
  let hidden = false;
  const display = new Writable({
    write(chunk, encoding, done) {
      if (hidden) done();
      else output.write(chunk, encoding, done);
    },
  });
  display.columns = output.columns || 80;
  const rl = createInterface({
    input,
    output: display,
    terminal: Boolean(input.isTTY),
    historySize: 0,
  });
  return {
    async ask(label, secret = false) {
      if (secret && !input.isTTY)
        throw new Error(
          "Enter a key in a local interactive terminal. 请在本机交互终端输入密钥。",
        );
      if (secret) output.write(label);
      hidden = secret;
      try {
        return (await rl.question(secret ? "" : label)).trim();
      } finally {
        hidden = false;
        if (secret) output.write("\n");
      }
    },
    close: () => rl.close(),
  };
};
async function htmlPath(named) {
  for (const f of named
    ? [resolve(named)]
    : [
        resolve(root, "Lantern Studio.html"),
        resolve(root, "../release/Lantern Studio.html"),
      ]) {
    try {
      if (!(await stat(f)).isFile() || !/\.html?$/i.test(f)) continue;
      const contents = await readFile(f, "utf8");
      if (
        contents.includes('id="app"') &&
        contents.includes('id="third-party-notices"') &&
        contents.includes("globalThis.__lanternEmbeddedFiles=")
      )
        return f;
    } catch {}
  }
  return null;
}
export async function servePilotFile({
  file,
  port = 4175,
  env = {},
  providerFetch = nodeProviderFetch,
}) {
  let gateway, origin;
  const s = createServer(async (req, res) => {
    if (
      req.headers.host !== new URL(origin).host ||
      (req.headers.origin && req.headers.origin !== origin)
    ) {
      res.writeHead(403);
      res.end();
      return;
    }
    const next = async () => {
      if (req.url === "/favicon.ico") {
        res.writeHead(204);
        res.end();
        return;
      }
      const path = req.url?.split("?", 1)[0];
      if (
        !["GET", "HEAD"].includes(req.method) ||
        !["/", "/index.html", "/lantern-connect.html"].includes(path)
      ) {
        res.writeHead(404);
        res.end();
        return;
      }
      const page = path === "/lantern-connect.html" ? resolve(root, "public/lantern-connect.html") : file;
      const handle = await open(page, "r");
      try {
        const bytes = (await handle.stat()).size;
        res.writeHead(200, {
          "Content-Type": "text/html; charset=utf-8",
          "Cache-Control": "no-store",
          "Content-Length": bytes,
          "X-Content-Type-Options": "nosniff",
          "Referrer-Policy": "no-referrer",
        });
        if (req.method === "HEAD") {
          await handle.close();
          res.end();
          return;
        }
        const stream = handle.createReadStream();
        stream.on("error", () => res.destroy());
        res.on("close", () => stream.destroy());
        stream.pipe(res);
      } catch (error) { await handle.close(); throw error; }
    };
    try {
      await gateway(req, res, next);
    } catch {
      if (!res.headersSent) res.writeHead(500);
      res.end();
    }
  });
  await new Promise((ok, fail) => {
    s.once("error", fail);
    s.listen(port, "127.0.0.1", () => {
      s.removeListener("error", fail);
      ok();
    });
  });
  const actual = s.address().port;
  origin = "http://127.0.0.1:" + actual;
  gateway = pilotMiddleware({ port: actual, env, fetchImpl: providerFetch });
  return {
    server: s,
    origin,
    close: () =>
      new Promise((resolve) => {
        s.close(resolve);
        s.closeIdleConnections();
      }),
  };
}
async function sourceServer() {
  try {
    const pkg = JSON.parse(
      await readFile(resolve(root, "package.json"), "utf8"),
    );
    if (pkg.name !== "lantern-vn-studio") return null;
    const { createServer } = await import("vite");
    return async ({ port, env }) => {
      let gateway;
      const vite = await createServer({
        root,
        server: { host: "127.0.0.1", port, strictPort: true, cors: false },
        plugins: [
          {
            name: "lantern-copilot-launcher",
            configureServer(v) {
              v.middlewares.use((req, res, next) => {
                gateway ||= pilotMiddleware({
                  port: v.httpServer.address().port,
                  env,
                });
                return gateway(req, res, next);
              });
            },
          },
        ],
      });
      try {
        await vite.listen();
      } catch (e) {
        await vite.close();
        if (/in use|EADDRINUSE/i.test(e.message)) e.code = "EADDRINUSE";
        throw e;
      }
      return {
        server: vite.httpServer,
        origin: "http://127.0.0.1:" + vite.httpServer.address().port,
        close: () => vite.close(),
      };
    };
  } catch {
    return null;
  }
}
function openBrowser(origin) {
  const windows = process.platform === "win32",
    mac = process.platform === "darwin";
  const proc = spawn(
    windows ? "rundll32.exe" : mac ? "open" : "xdg-open",
    windows ? ["url.dll,FileProtocolHandler", origin] : [origin],
    { detached: true, stdio: "ignore", windowsHide: true },
  );
  proc.on("error", () => {});
  proc.unref();
}
export async function launchPilot(
  args = process.argv.slice(2),
  environment = process.env,
) {
  const { values: a } = parseArgs({
    args,
    options: {
      studio: { type: "string" },
      mode: { type: "string" },
      port: { type: "string" },
      provider: { type: "string" },
      model: { type: "string" },
      "key-file": { type: "string" },
      "no-open": { type: "boolean" },
      help: { type: "boolean" },
    },
  });
  if (a.help) {
    console.log(
      "node scripts/pilot-launch.mjs [--studio 'Lantern Studio.html'] [--mode guide|provider|env] [--provider " + providerCatalog.map(p => p.id).join("|") + "] [--model MODEL] [--key-file PATH] [--port 4175] [--no-open]",
    );
    return;
  }
  if (Number(process.versions.node.split(".")[0]) < 24)
    throw new Error(
      "Install Node.js 24 or later. 请安装 Node.js 24 或更高版本。",
    );
  const interactive = Boolean(process.stdin.isTTY),
    terminal = interactive ? askWith(process.stdin, process.stdout) : null;
  try {
    let file = await htmlPath(a.studio);
    const fromSource = !file && !a.studio ? await sourceServer() : null,
      serve = fromSource || servePilotFile;
    if (!file && !fromSource && terminal)
      file = await htmlPath(
        (
          await terminal.ask(
            "Path to your trusted portable Lantern Studio.html / 请输入可信的便携版工作室 HTML 路径： ",
          )
        ).replace(/^["']|["']$/g, ""),
      );
    if (!file && !fromSource)
      throw new Error(
        "Choose the portable Lantern Studio.html included in the release. Put it beside the launcher or use --studio PATH. 请选择发布包中的便携版工作室 HTML，放在启动器旁或用 --studio 指定路径。",
      );
    let mode = a.mode || (a.provider ? "provider" : "");
    if (!mode && terminal) {
      console.log("1 · Open Studio / 打开工作室\n2 · Cloud API with a terminal-only key / 用终端密钥连接云服务\n3 · Existing Lantern environment settings / 使用 Lantern 环境变量");
      const choice = (await terminal.ask("Choose / 请选择 [1] ")) || "1";
      mode = { 1: "guide", 2: "provider", 3: "env" }[choice] || "invalid";
    }
    mode ||= "guide";
    if (a["key-file"] !== undefined && (mode !== "provider" || !a.provider))
      throw new Error("--key-file requires an explicit --provider. 读取密钥文件时请明确指定 --provider。");
    if (!["provider", "env", "guide"].includes(mode)) {
      throw new Error("Choose guide, provider or env. 请选择工作室、云服务商或环境变量模式。");
    }
    let env = {};
    if (mode !== "guide") {
      // Never inspect generic provider credentials or other applications' settings.
      const scoped = Object.fromEntries(["LANTERN_AI_PROVIDER", "LANTERN_AI_MODEL", "LANTERN_AI_KEY",
        "LANTERN_AI_API_KEY", "LANTERN_AI_BASE", "LANTERN_AI_BASE_URL", "LANTERN_AI_JSON_MODE"]
        .filter(name => environment[name] !== undefined).map(name => [name, environment[name]]));
      if (mode === "provider") {
        let choice = a.provider;
        if (!choice && terminal) {
          console.log(providerCatalog.map((p,i) => (i+1) + " · " + p.label).join("\n"));
          const index = Number(await terminal.ask("Provider number / 服务商编号： "));
          choice = providerCatalog[index-1]?.id;
        }
        if (!choice) throw new Error("Choose --provider ID, or --mode guide. 请选择服务商或工作室模式。");
        const provider = findProvider(choice);
        const prior = [scoped.LANTERN_AI_PROVIDER, scoped.LANTERN_AI_BASE, scoped.LANTERN_AI_BASE_URL].filter(Boolean);
        // A key designated for one lab must never be silently sent to another.
        const same = prior.every(value => findProvider(value).id === provider.id);
        const suggested = provider.defaultModel;
        const model = a.model || (same && scoped.LANTERN_AI_MODEL) ||
          (terminal && await terminal.ask("Model ID / 模型 ID" + (suggested ? " [" + suggested + "]" : "") + "： ")) || suggested;
        let key;
        if (a["key-file"] !== undefined) {
          const path = resolve(a["key-file"]);
          const info = await stat(path).catch(() => null);
          if (!info?.isFile() || info.size > 8196)
            throw new Error("Choose a readable text file containing one API key. 请选择只含一个密钥的文本文件。");
          key = (await readFile(path, "utf8")).trim();
        } else {
          key = (same && (scoped.LANTERN_AI_API_KEY || scoped.LANTERN_AI_KEY)) ||
            (terminal && await terminal.ask("API key (hidden for this run) / API 密钥（隐藏，仅本次运行）： ", true));
        }
        env = { LANTERN_AI_PROVIDER: provider.id, LANTERN_AI_MODEL: model, LANTERN_AI_KEY: key };
      } else {
        if (a.provider || a.model) throw new Error("--mode env uses Lantern environment settings only. 环境变量模式请仅使用 Lantern 环境变量。");
        env = scoped;
      }
      try { providerOptions(env); }
      catch (error) {
        console.log(error.message + "\nOpening Studio with manual review. 正在打开工作室，可使用手动审阅。");
        env = {};
      }
    }
    const port = Number(a.port ?? 4175);
    if (!Number.isInteger(port) || port < 0 || port > 65535)
      throw new Error("Invalid port / 端口无效");
    let service;
    try {
      service = await serve({ file, port, env });
    } catch (e) {
      if (e.code !== "EADDRINUSE") throw e;
      const msg =
        "Port " +
        port +
        " is already in use. Keep using your existing studio if it owns that port, or start this one with --port 4176. Different ports have separate browser workspaces. 端口已被占用，可返回原工作室或用 --port 4176 指定其他端口。不同端口各自保存工程。";
      console.log(msg);
      if (
        !terminal ||
        !(
          await terminal.ask(
            "Use another available port? / 使用其他空闲端口？ [y/N] ",
          )
        ).match(/^(y|yes|是)$/i)
      )
        throw new Error(msg);
      service = await serve({ file, port: 0, env });
    }
    console.log(service.origin + "/");
    console.log(
      "Keep this terminal open. Ctrl+C stops the studio. 保持终端开启，按 Ctrl+C 关闭。",
    );
    if (!a["no-open"]) openBrowser(service.origin + "/");
    return service;
  } finally {
    terminal?.close();
  }
}
if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(resolve(process.argv[1])).href
)
  launchPilot().catch((e) => {
    console.error(e.message);
    process.exitCode = 1;
  });
