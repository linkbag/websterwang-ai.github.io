import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { fromPilotContext } from '../src/pilot-proposal.js';
import { answerProject, proposeProject, providerOptions } from './pilot.mjs';
import { chatgptConnector } from './pilot-chatgpt.mjs';
import { nodeProviderFetch } from './pilot-node-transport.mjs';

const prefix = '/__lantern/pilot/';
const maximum = 512 * 1024;

async function readRequest(req) {
  if (Number(req.headers['content-length']) > maximum) throw new Error('Request exceeds 512 KiB. 请求过大。');
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maximum) throw new Error('Request exceeds 512 KiB. 请求过大。');
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

export function pilotMiddleware({ port, env = process.env, fetchImpl = nodeProviderFetch, accountDirectory }) {
  const host = '127.0.0.1:' + port;
  const origin = 'http://' + host;
  let config, setupError;
  try { config = providerOptions(env); } catch (error) { setupError = error.message; }
  let busy = false;
  const plan = chatgptConnector({ port, fetchImpl, directory:accountDirectory });
  return async (req, res, next) => {
    const path = req.url?.split('?',1)[0];
    const callback = path === '/auth/callback';
    if (!callback && !req.url?.startsWith(prefix)) return next();
    function send(status, value) {
      if (res.destroyed || res.writableEnded) return;
      res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Referrer-Policy':'no-referrer', 'X-Content-Type-Options': 'nosniff' });
      res.end(JSON.stringify(value));
    }
    if (req.headers.host !== host || (req.headers.origin && req.headers.origin !== origin)) return send(403, { error: 'Use the local studio address.' });
    if (callback && req.method === 'GET') {
      try { await plan.callback(new URL(req.url, origin).searchParams); } catch {}
      res.writeHead(303, { Location:prefix+'chatgpt/return','Referrer-Policy':'no-referrer','Cache-Control':'no-store' });
      return res.end();
    }
    if (path === prefix+'chatgpt/return' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type':'text/html; charset=utf-8','Referrer-Policy':'no-referrer','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'; frame-ancestors 'none'" });
      return res.end('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Lantern Studio</title><h1>Lantern Studio</h1><p>Return to your Studio tab to check your sign-in result. You can close this window.</p><p lang="zh">请回到工作室标签页查看登录结果。此窗口可以关闭。</p>');
    }
    if (path.startsWith(prefix+'chatgpt/')) {
      if (req.method !== 'POST' || req.headers.origin !== origin) return send(403, {error:'Use your Studio tab.'});
      if (req.headers['content-type']?.split(';')[0] !== 'application/json') return send(415, {error:'JSON required.'});
      const controller = new AbortController();
      res.on('close',()=>{ if (!res.writableEnded) controller.abort(); });
      const action = req.url.slice((prefix+'chatgpt/').length);
      try {
        const data = await readRequest(req);
        if (action === 'accounts') return send(200,await plan.accounts());
        if (action === 'start') return send(200,await plan.start(data.profile,data.consent));
        if (action === 'status') return send(200,plan.status(data.handle));
        if (action === 'logout') return send(200,await plan.logout(data.handle));
        if (!['question','proposal'].includes(action)) return send(404,{error:'Unknown route.'});
        if (busy) return send(429,{error:'Please wait for the current request. 请等待当前请求完成。'});
        const completeText = plan.inference(data.handle,data.model);
        const options = {project:fromPilotContext(data.context),scope:data.scope,prompt:data.prompt,lang:data.lang,model:data.model,signal:controller.signal,completeText};
        busy = true;
        try {
          if (action === 'question') return send(200,await answerProject(options));
          const {proposal}=await proposeProject(options);
          return send(200,{proposal});
        } finally { busy=false; }
      } catch(error) { return send(400, {error:error instanceof SyntaxError ? 'Invalid response or request. 数据格式无效。' : error.message}); }
    }
    if (req.method === 'GET' && req.url === prefix + 'status') return send(200, { lanternPilot: 1, configured: Boolean(config), model: config?.model || '',provider:config ? new URL(config.base).host : '',providerId:config?.provider.id || '',local:false });
    if (req.method !== 'POST' || ![prefix+'proposal',prefix+'question'].includes(req.url)) return send(404, { error: 'Unknown pilot route.' });
    if (req.headers.origin !== origin) return send(403, { error: 'Use the local studio address.' });
    if (req.headers['content-type']?.split(';')[0].trim() !== 'application/json') return send(415, { error: 'JSON is required.' });
    if (!config) return send(503, { error: setupError });
    if (busy) return send(429, { error: 'A proposal is already in progress. 请等待正在生成的建议。' });
    busy = true;
    const controller = new AbortController();
    res.on('close', () => { if (!res.writableEnded) controller.abort(); });
    try {
      const { context, prompt, scope, lang } = await readRequest(req);
      const project = fromPilotContext(context);
      const options={...config,project,prompt,scope,lang,fetchImpl,signal:controller.signal};
      if(req.url===prefix+'question')return send(200,await answerProject(options));
      const { proposal } = await proposeProject(options);
      // The full project, media, undo history and final apply action stay in the editor.
      send(200, { proposal });
    } catch (error) {
      send(400, { error: error instanceof SyntaxError ? 'Invalid JSON. JSON 格式不正确。' : error.message });
    } finally { busy = false; }
  };
}

async function launch() {
  const { createServer } = await import('vite');
  const port = 4175;
  const middleware = pilotMiddleware({ port });
  const server = await createServer({
    server: { host: '127.0.0.1', port, strictPort: true, cors: false },
    plugins: [{ name: 'lantern-cloud-relay', configureServer(vite) { vite.middlewares.use(middleware); } }],
  });
  await server.listen();
  server.printUrls();
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  launch().catch(error => { console.error(error.message); process.exitCode = 1; });
}
