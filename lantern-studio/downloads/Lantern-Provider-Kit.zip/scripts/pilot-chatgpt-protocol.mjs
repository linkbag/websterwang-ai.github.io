import { createPublicKey, verify } from "node:crypto";

export const issuer = "https://auth.openai.com";
export const resource = "https://api.openai.com/v1";
export const tokenUrl = issuer + "/api/accounts/oauth/token";
export const revokeUrl = issuer + "/api/accounts/oauth/revoke";
export const jwksUrl = issuer + "/.well-known/jwks.json";
export const scopes =
  "openid profile email offline_access resource.invoke chatgpt.tokens.use.direct";
export const hasPlan = (scope) =>
  ["resource.invoke", "chatgpt.tokens.use.direct"].every((s) =>
    scope.includes(s),
  );
export const http = (fetcher, url, options = {}) =>
  fetcher(url, {
    redirect: "error",
    credentials: "omit",
    referrerPolicy: "no-referrer",
    ...options,
    signal: options.signal
      ? AbortSignal.any([options.signal, AbortSignal.timeout(90_000)])
      : AbortSignal.timeout(15_000),
  });

async function boundedBody(response, maximum, onText) {
  if (!response.body)
    throw Error("OpenAI returned an empty response. OpenAI 未返回内容。");
  const reader = response.body.getReader(),
    decoder = new TextDecoder();
  let size = 0,
    ended = false;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) {
        onText(decoder.decode());
        ended = true;
        break;
      }
      size += value.byteLength;
      if (size > maximum)
        throw Error(
          "OpenAI response exceeded the size limit. OpenAI 的答复超出长度限制。",
        );
      onText(decoder.decode(value, { stream: true }));
    }
  } finally {
    if (!ended) await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}

export async function json(response, maximum = 128_000) {
  let body = "";
  await boundedBody(response, maximum, (part) => {
    body += part;
  });
  try {
    return JSON.parse(body);
  } catch {
    throw Error(
      "OpenAI returned unreadable JSON. OpenAI 返回了无法读取的数据。",
    );
  }
}

function issue(code, status) {
  const safeCode =
    typeof code === "string" && /^[a-zA-Z0-9_-]{1,100}$/.test(code) ? code : "";
  const extra = safeCode.includes("usage_limit")
    ? " Review your app limit in ChatGPT Settings → Usage. 请在 ChatGPT 设置的用量页面查看应用限额。"
    : safeCode.includes("not_eligible")
      ? " Check your plan, workspace, and region. 请核对套餐、工作区和地区资格。"
      : "";
  const error = Error(
    "OpenAI " +
      (status ? "HTTP " + status : "Responses") +
      (safeCode ? " · " + safeCode : "") +
      "." +
      extra,
  );
  error.providerCode = safeCode;
  error.status = status;
  return error;
}

export async function requireOk(response) {
  if (response.ok) return response;
  const packet = await json(response).catch(() => ({}));
  throw issue(
    packet?.error?.code || packet?.error || packet?.code,
    response.status,
  );
}

export async function verifyIdentity(token, { clientId, nonce, now, fetcher }) {
  const invalid = () =>
    Error("Invalid OpenAI identity token. OpenAI 身份令牌校验失败。");
  if (typeof token !== "string" || token.length > 32_768) throw invalid();
  const parts = token.split(".");
  if (
    parts.length !== 3 ||
    parts.some((part) => !/^[A-Za-z0-9_-]+$/.test(part))
  )
    throw invalid();
  let header, identity;
  try {
    [header, identity] = parts
      .slice(0, 2)
      .map((p) => JSON.parse(Buffer.from(p, "base64url")));
  } catch {
    throw invalid();
  }
  if (
    header?.alg !== "RS256" ||
    typeof header.kid !== "string" ||
    !header.kid ||
    header.crit
  )
    throw invalid();
  const jwks = await json(await requireOk(await http(fetcher, jwksUrl)));
  const keys = jwks.keys?.filter(
    (k) =>
      k.kid === header.kid &&
      k.kty === "RSA" &&
      (!k.use || k.use === "sig") &&
      (!k.alg || k.alg === "RS256"),
  );
  if (keys?.length !== 1) throw invalid();
  const key = createPublicKey({ key: keys[0], format: "jwk" });
  if (
    !verify(
      "RSA-SHA256",
      Buffer.from(parts[0] + "." + parts[1]),
      key,
      Buffer.from(parts[2], "base64url"),
    )
  )
    throw invalid();
  const audiences = Array.isArray(identity?.aud)
    ? identity.aud
    : [identity?.aud];
  const seconds = now() / 1000;
  if (
    identity?.iss !== issuer ||
    !audiences.includes(clientId) ||
    ((audiences.length > 1 || identity.azp) && identity.azp !== clientId) ||
    !Number.isFinite(identity.exp) ||
    identity.exp <= seconds ||
    (identity.nbf !== undefined &&
      (!Number.isFinite(identity.nbf) || identity.nbf > seconds + 30)) ||
    (identity.iat !== undefined &&
      (!Number.isFinite(identity.iat) || identity.iat > seconds + 30)) ||
    identity.nonce !== nonce ||
    typeof identity.sub !== "string" ||
    !identity.sub ||
    identity.sub.length > 512
  )
    throw invalid();
  return identity;
}

export async function responseText(
  fetcher,
  token,
  { model, instructions, content, signal },
) {
  const response = await requireOk(
    await http(fetcher, resource + "/responses", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
        Accept: "text/event-stream",
      },
      body: JSON.stringify({
        model,
        instructions,
        input: [{ role: "user", content }],
        stream: true,
        store: false,
      }),
      signal,
    }),
  );
  if (!response.headers.get("content-type")?.includes("text/event-stream")) {
    await response.body?.cancel();
    throw Error(
      "OpenAI did not return the requested event stream. OpenAI 未返回所需的数据流。",
    );
  }
  let buffer = "",
    result = "",
    complete = false;
  const processBlock = (block) => {
    const data = block
      .split(/\r?\n/)
      .filter((line) => line.startsWith("data:"))
      .map((line) => line.slice(5).trimStart())
      .join("\n");
    if (!data || data === "[DONE]") return;
    const event = JSON.parse(data);
    if (
      ["response.failed", "response.incomplete", "error"].includes(event.type)
    )
      throw issue(event.response?.error?.code || event.code || event.type);
    if (
      event.type === "response.output_text.delta" &&
      !complete &&
      typeof event.delta === "string"
    )
      result += event.delta;
    if (
      event.type === "response.completed" &&
      event.response?.status === "completed"
    )
      complete = true;
  };
  await boundedBody(response, 2_000_000, (part) => {
    buffer += part;
    let boundary;
    while ((boundary = /\r?\n\r?\n/.exec(buffer))) {
      processBlock(buffer.slice(0, boundary.index));
      buffer = buffer.slice(boundary.index + boundary[0].length);
    }
  });
  if (buffer.trim()) processBlock(buffer);
  if (!complete || !result.trim())
    throw Error(
      "The ChatGPT stream ended before completing the answer. ChatGPT 未完整返回答复。",
    );
  return result.trim();
}
