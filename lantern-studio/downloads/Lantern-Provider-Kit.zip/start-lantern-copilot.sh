#!/bin/sh
set -eu
cd -P "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1 || ! node -e "process.exit(Number(process.versions.node.split('.')[0]) >= 24 ? 0 : 1)"; then
  echo "Install Node.js 24 or later / 请安装 Node.js 24 或更高版本。"
  echo "https://nodejs.org/en/download"
  exit 1
fi
exec node ./scripts/pilot-launch.mjs "$@"
