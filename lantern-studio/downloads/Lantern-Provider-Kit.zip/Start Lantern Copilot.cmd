@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0" || exit /b 1
where.exe node.exe >nul 2>nul
if errorlevel 1 goto neednode
node.exe -e "process.exit(Number(process.versions.node.split('.')[0]) >= 24 ? 0 : 1)"
if errorlevel 1 goto neednode
node.exe "scripts/pilot-launch.mjs" %*
if errorlevel 1 goto failed
popd
exit /b 0
:neednode
echo Install Node.js 24 or later, then open this launcher again.
echo 安装 Node.js 24 或更高版本后，请再次打开此启动器。
echo https://nodejs.org/en/download
:failed
pause
popd
exit /b 1
