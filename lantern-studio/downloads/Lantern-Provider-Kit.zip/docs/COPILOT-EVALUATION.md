# Provider copilot verification · 服务商 AI 助手验证

The release separates three different results. Manual authoring is tested against the editor and the exported game. Copilot behavior is tested against controlled, remote-provider responses. Contacting a provider's live public endpoints verifies connectivity. No customer credentials or billable generation were used to qualify this release.

本版分别验证手动创作、服务商协议及真实网络连通性。手动创作会检查导出的游戏；助手交互使用可重复的服务商模拟响应；网络检查访问官方端点。本轮验证未使用客户密钥或付费推理。

| Exercise | Observed result |
| --- | --- |
| Create without AI | All eight formats completed the offline starter journey, including reaching an ending and restoring the exact blank project with Undo. The separate postcard lesson exercises hand-written choices, translated dialogue, imported art and sound, backup and both language exports. |
| Sign in to a provider | Chromium, Firefox and WebKit exercised the complete OpenRouter PKCE protocol with a controlled provider. The real Studio callback removed the query, rejected a mismatched state, accepted a matching callback and exchanged its code using the original verifier. One scoped question then used the authorized credential. Denied consent made zero inference calls. Reload forgot the connection. |
| Use a ChatGPT plan | Chromium, Firefox and WebKit completed the connector workflow with a signed test identity and a simulated provider. Checks included account selection, consent, token verification, the account's model list, a scoped question, and reviewing and applying a proposal. Declined consent, missing plan permission, revoked sessions, refresh errors, cancellation and incomplete responses were exercised. Official OpenAI discovery was checked without a customer's account. Live consent, account eligibility and inference were not exercised. [OpenAI registration contract](https://developers.openai.com/siwc/token-sharing-open-source/sign-in) |
| Connect with a key | The production UI handled a rejected credential and a successful read-only probe. The probe sent no game data. A separate click sent the chosen scope, returned an answer and reviewed an edit. The key was absent from transmitted manuscript data and game backups. |
| Respect an author's draft | Tests cover wrong scope, protected English/Chinese text, invalid proposals, cancellation and a simultaneous save from another tab. Only the author's Apply action commits an edit. Undo restores earlier content. |
| Terminal-held credentials | The extracted provider kit served its portable editor and its sign-in callback. Its relay recognized supported official HTTPS endpoints, required a matching key and rejected an unrecognized or loopback inference endpoint. The editor was also launched with no provider configured. |
| Live browser-access checks | OpenRouter, DeepSeek, Gemini and OpenAI allowed the cross-origin request headers for a browser connection. Both mainland 智谱 and international Z.AI omitted the required headers at their chat endpoint. Their supported path in Lantern is the terminal API connector. These probes did not issue a generation. |
| Existing assets | A previously saved collection containing an image, voice recording and video restored into a fresh profile. The procedural sprite, sound and title-card tools still worked. Six cloud media routes exercised controlled responses. |

Model choice, quotas, writing quality and the validity of a particular customer's credentials depend on the provider. A structurally valid change can still miss the author's intention. Review both languages and play the changed route. The semantic test cases are available to evaluate the actual provider and model you plan to use. The previous release's study stays in its [versioned archive](https://github.com/linkbag/lantern-studio/blob/studio-v9/docs/COPILOT-EVALUATION.md).

## Reproduce protocol and authoring checks

```sh
npm ci
npm run build
npm test
node tests/pilot-direct.browser.mjs
node tests/pilot-signin.browser.mjs
node tests/pilot-chatgpt.browser.mjs
node tests/pilot-consent.browser.mjs
node tests/pilot-starters.browser.mjs
node tests/pilot-kit.browser.mjs
node tests/live-edit.browser.mjs
```

Set `LANTERN_DEV_ENGINE` to `firefox` or `webkit` for the sign-in test and install those Playwright browser builds. To reproduce the manual-only journey, run `npm run portable` and pass the portable file's absolute `file://` URL to `node tests/postcard-journey.browser.mjs`. [Manual lesson](AI-PILOT.md) · [Workbench verification](WORKBENCH-VERIFICATION.md)

## Evaluate a real account by choice

Configure `LANTERN_AI_PROVIDER`, `LANTERN_AI_MODEL` and `LANTERN_AI_KEY` for your terminal process. This opt-in evaluator sends synthetic game requests to that provider, which may incur charges. It requires an explicit flag and a new filename for its report.

```sh
node scripts/pilot-evaluate.mjs --confirm-provider-requests --suite regression --report regression.json
node scripts/pilot-evaluate.mjs --confirm-provider-requests --suite holdout --report holdout.json
```

Each report records the requested outcome and semantic check. A previous provider's score does not establish the quality of a different model.
