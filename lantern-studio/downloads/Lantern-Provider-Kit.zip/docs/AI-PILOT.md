# AI copilot and manual authoring · AI 助手与手动创作

The editor, source view, playtest, build, export and offline routines work as soon as you open Studio. Open **AI copilot** when you want a provider to answer a question or propose changes. Connecting checks account access. You choose the game text and submit it separately.

打开工作室后就能编辑、写代码、试玩、构建和导出。需要模型帮忙时，打开 **AI 助手**。连接时只检查账户权限。选择游戏内容并点击发送后，服务商才会收到稿件。

## Connect a provider · 连接服务商

| How you connect / 连接方式 | Where to use it / 可用位置 |
| --- | --- |
| **Continue with ChatGPT / 使用 ChatGPT 继续** | Eligible ChatGPT Plus and Pro accounts can authorize plan usage in the optional provider connector. Hosted and portable Studio show the connector download under **Use a ChatGPT plan**. / 符合条件的 Plus 和 Pro 账户可通过可选连接器授权使用套餐额度。在托管版或单文件版选择**使用 ChatGPT 套餐**即可找到下载入口。 |
| **Sign in with OpenRouter / 使用 OpenRouter 登录** | On the hosted Studio or a Studio served on this computer, select OpenRouter. Review the authorization screen in the provider window. The default model is `openrouter/free`; a different model can have its own pricing. / 托管版或本机网址可用。在服务商窗口核对授权。默认使用 `openrouter/free`，更换模型前请留意其价格。 |
| **Bring an API key / 使用自己的 API 密钥** | Select OpenRouter, DeepSeek, Google Gemini or OpenAI. Enter the model ID and the matching provider key, then choose **Connect API key**. This also works from the portable HTML with internet access. / 选择服务商，填写模型 ID 和对应密钥，点击**连接 API 密钥**。直接打开的便携 HTML 也可通过网络连接。 |
| **Terminal-held key / 由终端持有密钥** | All six provider choices, including mainland 智谱 GLM and international Z.AI. Download the provider connector. It forwards requests to the official cloud endpoint. / 六个服务选项均可用，包括中国大陆智谱和国际 Z.AI。下载服务商连接器，由它向官方云端接口发送请求。 |

1. Choose **AI copilot** in the top bar and select your provider. The account link opens its official site. An OpenAI API key uses OpenAI API billing. OpenRouter sign-in authorizes the OpenRouter account and the models available through it.
2. With a key, use **Connect API key**. For OpenRouter sign-in, allow the provider window to open, review its access, credit limit and expiry, and authorize there. Return to Studio. The panel displays the provider and selected model.
3. Select **Ask a question** or **Propose an edit**. Select a scope and expand **What will be shared?**. Only submit once you are comfortable with the content and any provider charges.
4. Read the answer or inspect the proposed difference. **Apply to project** makes one undoable edit. **Discard proposal** leaves your draft intact.
5. **Disconnect provider** clears the tab connection. Reloading the editor also clears credentials from that tab. To revoke an OpenRouter authorization at the service, use its key settings.

1. 从顶栏打开 **AI 助手**，选择服务商。账户链接会打开其官网。使用 OpenAI 密钥时计入 OpenAI API 账单。使用 OpenRouter 登录时，通过该账户访问所选模型。
2. 填写密钥后点击**连接 API 密钥**。使用 OpenRouter 登录时，允许打开服务商窗口，在那里核对访问、额度和有效期并授权，再返回工作室。
3. 选择**提出问题**或**提出修改**和发送范围，展开**将分享哪些内容？**。核对内容及可能产生的费用后再发送。
4. 阅读回答或对照修改前后的值。**应用到项目**会产生一次可撤销的修改；**放弃建议**会保留原稿。
5. 点击**断开连接**或刷新页面可清除当前标签页凭据。要撤销服务商端的授权，可在 OpenRouter 密钥设置中操作。

For a browser API key or OpenRouter sign-in, the tab sends its credential directly to the selected provider over HTTPS and keeps it in memory. A ChatGPT plan session uses the connector to hold its tokens. The editor prepares scoped game text and necessary reference IDs. Uploaded media bytes, asset credits, source prompts and custom web code stay out of that context. [OpenRouter authorization](https://openrouter.ai/docs/guides/overview/auth/oauth) · [Free router](https://openrouter.ai/openrouter/free) · [Provider key settings](https://openrouter.ai/settings/keys)

浏览器通过 HTTPS 直接联系所选服务商，仅在当前页面会话内使用凭据。发送范围包括选定的游戏文本及必要标识，素材二进制内容、素材署名、素材提示词和自定义网页代码都不会放进此上下文。

## Example with Ferry Keeper Wen · 以守渡人温伯为例

1. In **Game formats → Quest RPG**, click **Edit example**. Open *Bells of Mistford*. Select **Ferry Keeper Wen** and read his current line. **Live playtest here** lets you type and see his dialogue beside the editor. Save the event.
2. To involve a provider, open **AI copilot → Propose an edit**. Choose **Mistford Quay** and enter `Change only Ferry Keeper Wen’s English dialogue to “Ring the bronze bell when the mist reaches the dock.” Keep Chinese unchanged.`
3. Open the context preview. Submit **Generate proposal**. Verify the person, the English line and the preserved Chinese text. Apply once. **Undo** lets you compare with the previous draft.
4. In **Build & test**, choose **Build web game → Run this build**. Choose Wayfarer difficulty and visit Wen. Check the wording and quest behavior in the actual game. Download the HTML to play it offline.

1. 进入 **游戏类型 → 剧情角色扮演 → 编辑示例**，打开《雾渡寻铃》。选中守渡人温伯，如要手写对白，可点击**在此实时试玩**，边写边看，完成后保存事件。
2. 如要使用服务商，打开 **AI 助手 → 提出修改**，范围选**雾渡码头**。输入「只把守渡人温伯的中文对白改成『雾到码头时，敲响铜铃。』，保留英文原文」。
3. 展开并查看分享内容，选择**生成修改建议**。核对角色、修改后的中文和保留的英文，再应用。可使用**撤销**恢复原稿。
4. 打开 **构建与测试 → 构建网页游戏 → 运行此构建**，以「行路人」难度找温伯对话，在实际游戏中核对台词和任务效果。下载 HTML 可离线游玩。

## Terminal connector · 终端连接器

### Use a ChatGPT plan · 使用 ChatGPT 套餐

1. In **AI copilot → Use a ChatGPT plan**, download and extract the provider connector. Run its launcher with Node.js 24 or later, choose **Open Studio** and open the printed `http://127.0.0.1` address. Import your editable backup if you created the game at another address.
2. Choose **AI copilot → ChatGPT plan → Continue with ChatGPT**. Review the account, workspace and plan permission on OpenAI’s own page. Return to Studio, select a model offered by your account and choose **Use selected model**.
3. Select the project text to share and submit a question or proposed change. OpenAI applies account eligibility, workspace policy, usage limits and any credit settings. Review changes before applying them. **Disconnect provider** ends the session and asks OpenAI to revoke the renewable credential. You can also manage usage and access in ChatGPT settings. [ChatGPT usage settings](https://chatgpt.com/settings/usage)

1. 进入 **AI 助手 → 使用 ChatGPT 套餐**，下载并解压服务商连接器，用 Node.js 24 或更新版本运行启动器。选择**打开工作室**，打开终端显示的 `http://127.0.0.1` 网址。如工程原先在另一网址创建，可导入可编辑备份。
2. 选择 **AI 助手 → ChatGPT 套餐 → 使用 ChatGPT 继续**。在 OpenAI 的页面核对账户、工作区和套餐授权，返回工作室后选一个账户可用的模型，再点**使用所选模型**。
3. 选择共享的工程范围，提交问题或修改请求。是否可用以及额度和点数由 OpenAI 的账户及工作区设置决定。审阅后再应用修改。点击**断开连接**会退出此次会话，并请求 OpenAI 撤销续期凭据。

The connector uses OpenAI’s public registration for open-source applications. The callback runs on this computer. Lantern’s hosted website currently directs you to the connector. OpenAI’s hosted partner sign-in has separate registration requirements. [OpenAI sign-in quickstart](https://developers.openai.com/siwc/quickstart) · [Open-source registration](https://developers.openai.com/siwc/token-sharing-open-source/sign-in) · [Plan models and inference](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference)

Lantern keeps access and renewable tokens in connector memory. Reopening the connector requires signing in again. The connector saves its own random host ID and each verified registration’s identifier, subject and optional verified email under `~/.lantern-studio/chatgpt/` to recognize returning registrations. Each tab holds a temporary connector session handle. Game projects and exports contain neither credentials nor account metadata.

连接器仅在内存中保存访问和续期令牌。重启后需要重新登录。连接器在 `~/.lantern-studio/chatgpt/` 保存随机主机标识、已验证的账户注册号、主体标识及可选的已验证邮箱，以便下次继续使用原注册。标签页仅保留临时连接标识；工程和导出文件不含账户信息或凭据。

A GLM key belongs to its own region. The mainland and international chat endpoints require a server-side connection from Lantern. Select the matching service in **AI copilot** and choose **Download provider connector ZIP**. The full download on the hosted release includes the portable editor. An offline helper-only download should be extracted beside your trusted `Lantern Studio.html`.

Both GLM connectors suggest `glm-5.4`. The launcher also accepts a different model ID offered by your account. Lantern uses the standard regional API for application integrations. Z.ai documents the supported environments for its separate Coding Plan. [Mainland account guidance](https://docs.bigmodel.cn/cn/coding-plan/faq) · [Z.ai connection guide](https://zcode.z.ai/en/docs/configuration)

If you already keep a key in a private UTF-8 text file, run the following command from the extracted connector folder. Replace the example path with your file. The launcher reads it for this process. Only the path appears in your terminal history. Use `glm-global` for an international API key.

```powershell
node scripts/pilot-launch.mjs --provider glm-cn --model glm-5.4 --key-file "C:/private/my-glm-key.txt"
```

中国大陆和国际 GLM 连接器默认使用 `glm-5.4`。若密钥已经保存在私人 UTF-8 文本文件中，可按上述命令指定文件。大陆标准 API 使用 `glm-cn`，国际标准 API 使用 `glm-global`。启动后，在工作室的 **AI 助手 → 服务商** 选择 **此工作室预配置的服务**，点击连接。随后打开游戏，选择共享范围，勾选同意，提问或审阅修改。

智谱中国大陆和国际 Z.AI 使用各自的密钥。选择对应服务，点击**下载服务商连接器 ZIP**。托管正式版提供包含便携编辑器的完整包。若在单文件版中下载了仅含连接器的压缩包，请将它解压到你的 `Lantern Studio.html` 旁边。

1. Extract the ZIP. On a machine with Node.js 24+ open **Start Lantern Copilot.cmd** in Windows, or run `sh start-lantern-copilot.sh` in macOS/Linux.
2. Choose **Cloud API with a terminal-only key**. Enter the provider, the exact model ID in your account and the key when prompted. Secret entry is masked. For a managed setup, choose the environment option with `LANTERN_AI_PROVIDER`, `LANTERN_AI_MODEL` and `LANTERN_AI_KEY` already set for that process.
3. Open the Studio address printed in the terminal. In **AI copilot**, choose **This Studio’s configured provider → Check server connection**. Then send a scoped request to verify inference. Keep the terminal open while working.
4. To move a project between the hosted editor and the connector address, export an editable project backup, open the other editor and import it. Browser storage is separate for each address.

1. 完整解压。在安装 Node.js 24 或更新版本的电脑上，Windows 双击 **Start Lantern Copilot.cmd**；macOS/Linux 运行 `sh start-lantern-copilot.sh`。
2. 选择**用终端密钥连接云服务**，选服务商，输入账户可用的模型 ID，在隐藏输入框中填写密钥。
3. 打开终端显示的网址，进入 **AI 助手 → 此工作室预配置的服务 → 检查服务器连接**。发送一条选定范围的请求，可验证实际推理。使用期间保持终端开启。
4. 在托管版与终端网址间转移游戏时，请先下载可编辑的工程备份，再到另一个工作室导入。不同网址的工程保存在各自的浏览器存储空间。

**Recover a draft from the previous desktop launcher.** If your game was saved at `http://127.0.0.1:4185/`, extract the full provider kit and run `node scripts/pilot-launch.mjs --mode guide --port 4185` there. Open the same address in the same browser profile and download an editable backup. The editor starts without an active provider. / 如果旧草稿保存在该网址，解压完整包后运行上面的命令，用原浏览器配置打开同一网址即可下载工程备份。工作室启动时不会自动连接服务商。

## Build a game without an account · 无需账户制作游戏

Open the portable HTML. Choose **Game formats**, pick a format and choose **Start blank**. You can begin writing and placing game objects immediately. For a starter, open **Routines → Offline authoring tools → Preview playable starter**. Review the change and select **Apply to project → Playtest**. To create an original game from scratch with exact dialogue, choices and original art, follow **User manual → The Last Postcard**. You can finish and export it while offline.

打开便携 HTML，进入**游戏类型**，选所需类型并新建空白工程，即可写作、摆放对象。需要起步小样时，进入 **创作流程 → 离线创作工具 → 预览可玩起步流程**，审阅后选择**应用到项目 → 试玩**。若想从零手工制作一款有对白、分支和原创素材的游戏，可按**使用手册**中的《最后一张明信片》教程完成，包括离线导出。

| Format / 类型                      | Play it / 通关方法                                                                                                                             |
| --- | --- |
| Visual novel / 视觉小说            | Decide where the lighthouse keeper’s postcard will go to see either ending. / 决定灯塔明信片的去向，可走向两个结局。                           |
| Top-down adventure / 俯视冒险      | Find the key, cross two rooms, collect the lights and reach the beacon. / 找到钥匙，穿过两个房间，收集灯火后抵达灯塔。                         |
| Crate puzzle / 推箱解谜            | Push one crate onto the loading mark. / 把货箱推上装船标记。                                                                                   |
| Point-and-click mystery / 点击解谜 | Read the ferry ticket and use its seat number to open the drawer. / 查看船票，用座位号打开抽屉。                                               |
| Creature encounter / 生物遭遇      | Reach the companion, earn its trust and bring it back to camp. / 找到伙伴、赢得信任后带它回营地。                                              |
| Quest RPG / 任务角色扮演           | Accept the deckhand’s request, open the chest, deliver the token and return to the lantern. / 找水手接取委托，从箱中取出信物，交还后回到灯旁。 |
| Text adventure / 文字冒险          | Type `take key`, then `open door`, or use the visible buttons. / 输入 `拿钥匙` 再输入 `开门`，也可以使用画面上的行动按钮。                     |
| Interactive film / 互动影片        | Watch the harbor signal and choose between two filmed endings at the timed decision. / 观看港口信号，在限时抉择处选取两段结局影片之一。        |

See the [verification report](COPILOT-EVALUATION.md) for test coverage and the distinction between protocol checks and a signed-in generation.
