/** Pure rules shared by previews, downloaded games and the reachability check. */
export function createEncounterEngine() {
  const directions = {
    up: [0, -1],
    down: [0, 1],
    left: [-1, 0],
    right: [1, 0],
  };
  const same = (a, b) => a.x === b.x && a.y === b.y;
  const walkable = (map, x, y) => [".", ","].includes(map[y]?.[x]);
  const start = (e) => ({
    ...e.start,
    phase: "world",
    camp: false,
    bonded: false,
    returned: false,
    stamina: e.stamina,
    trust: 0,
    tide: "calm",
  });
  function move(e, state, direction) {
    if (state.phase !== "world" || !Object.hasOwn(directions, direction))
      return state;
    const [dx, dy] = directions[direction],
      x = state.x + dx,
      y = state.y + dy;
    if (!walkable(e.layout, x, y)) return state;
    const next = { ...state, x, y };
    if (same(next, e.checkpoint)) {
      next.camp = true;
      if (next.bonded) next.returned = true;
    }
    if (same(next, e.opponent) && !next.bonded)
      return {
        ...next,
        phase: "encounter",
        stamina: e.stamina,
        trust: 0,
        tide: "calm",
      };
    return next;
  }
  function act(e, state, action) {
    if (state.phase !== "encounter" || !["chime", "shelter"].includes(action))
      return state;
    const next = { ...state, tide: state.tide === "calm" ? "surge" : "calm" };
    if (action === "shelter") {
      next.stamina = Math.min(e.stamina, state.stamina + 1);
      return next;
    }
    next.trust = Math.min(e.goal, state.trust + e.chime);
    if (next.trust === e.goal) return { ...next, phase: "won", bonded: true };
    next.stamina = Math.max(
      0,
      state.stamina - (state.tide === "surge" ? e.surge : 1),
    );
    return next.stamina ? next : { ...next, phase: "lost" };
  }
  function retry(e, state) {
    return state.phase === "lost"
      ? {
          ...state,
          phase: "encounter",
          stamina: e.stamina,
          trust: 0,
          tide: "calm",
        }
      : state;
  }
  function returnToWorld(e, state) {
    if (state.phase === "won") return { ...state, phase: "world" };
    if (state.phase === "lost")
      return {
        ...state,
        ...(state.camp ? e.checkpoint : e.start),
        phase: "world",
        stamina: e.stamina,
        trust: 0,
        tide: "calm",
      };
    return state;
  }
  function rulesId(e) {
    return JSON.stringify([
      e.layout,
      ...[e.start, e.checkpoint, e.opponent].flatMap((p) => [p.x, p.y]),
      e.stamina,
      e.goal,
      e.chime,
      e.surge,
    ]);
  }
  function progress(p, state) {
    return {
      kind: "lantern-encounter-progress",
      version: 1,
      projectId: p.id,
      rules: rulesId(p.encounter),
      state: { ...state },
    };
  }
  function restore(p, save) {
    const e = p.encounter,
      s = save?.state;
    if (
      save?.kind !== "lantern-encounter-progress" ||
      save.version !== 1 ||
      save.projectId !== p.id ||
      save.rules !== rulesId(e) ||
      !s
    )
      return null;
    if (
      !["world", "encounter", "won", "lost"].includes(s.phase) ||
      !["calm", "surge"].includes(s.tide) ||
      !Number.isInteger(s.x) ||
      !Number.isInteger(s.y) ||
      !walkable(e.layout, s.x, s.y) ||
      !["camp", "bonded", "returned"].every((k) => typeof s[k] === "boolean") ||
      !Number.isInteger(s.trust) ||
      s.trust < 0 ||
      s.trust > e.goal ||
      !Number.isInteger(s.stamina) ||
      s.stamina < 0 ||
      s.stamina > e.stamina ||
      (s.returned && (!s.camp || !s.bonded)) ||
      s.bonded !== (s.trust === e.goal) ||
      (s.stamina === 0) !== (s.phase === "lost") ||
      (s.phase === "won" && !s.bonded) ||
      (s.phase !== "world" && !same(s, e.opponent)) ||
      (s.bonded && !["won", "world"].includes(s.phase)) ||
      (s.returned && s.phase !== "world") ||
      (s.phase === "world" &&
        !s.bonded &&
        (s.trust !== 0 || s.stamina !== e.stamina))
    )
      return null;
    return Object.fromEntries(
      Object.keys(start(e)).map((key) => [key, s[key]]),
    );
  }
  return {
    start,
    move,
    act,
    retry,
    returnToWorld,
    progress,
    restore,
    rulesId,
    walkable,
    directions,
  };
}
