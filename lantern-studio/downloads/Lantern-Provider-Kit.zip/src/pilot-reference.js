// Resolve names to IDs for a model editing a specific existing record. This never
// derives replacement text or applies an edit. The model still authors the result.
import {pilotKind} from "./pilot-commands.js";
const titleNames = /\b(?:title|name)\b|名称|名字|标题/i;
const bodyNames = /\b(?:dialogue|dialog|transcript|body|description|feedback|reply)\b|对白|台词|文字稿|正文|描述|反馈|回复/i;
function records(project){
  const result=[];
  const add=(op,row,owner,title,body,parent)=>{if(row)result.push({op,id:row.id,owner,title,body,parent,row});};
  switch(pilotKind(project)){
    case "quest-rpg":
      for(const m of project.rpg.maps){add("upsertMap",m,m.id,"name");for(const s of m.spots)add("upsertSpot",s,m.id,"name","text",m.id);}
      break;
    case "interactive-film":for(const s of project.segments)add("upsertSegment",s,s.id,"title","transcript");break;
    case "text-adventure":for(const s of project.passages){add("upsertPassage",s,s.id,"title","body");for(const a of s.actions)add("upsertAction",a,s.id,"label","reply",s.id);}break;
    case "point-mystery":for(const h of project.hotspots){add("upsertHotspot",h,h.id,"name");for(const a of h.actions)add("upsertAction",a,h.id,"label","feedback",h.id);}break;
    case "tile-adventure":case "crate-puzzle":for(const s of project.levels)add("upsertLevel",s,s.id,"title");break;
    case "novel":for(const s of project.scenes){add("upsertScene",s,s.id,"title");for(const c of s.choices)add("upsertChoice",c,s.id,"text",null,s.id);}break;
  }
  return result;
}
export function namedEditReference(project,scope,prompt){
  // Keep open-ended briefs and multi-step creation on the full command surface.
  if(!/\bonly\b|\b(?:leave|keep|preserve|retain)\b|只改|仅|不变|保持|保留/i.test(prompt))return null;
  const intent=prompt.split(/\b(?:keep|leave|preserve|retain)\b|其余|保持|保留/i)[0].split(/\bto\s*[:：]|改为|改成/)[0];
  const lower=intent.toLocaleLowerCase(),all=records(project).filter(r=>scope===null||r.owner===scope);
  function mentioned(r){return [r.id,r.row[r.title]?.en,r.row[r.title]?.zh].some(n=>typeof n==="string"&&n.length>=2&&lower.includes(n.toLocaleLowerCase()));}
  let hits=all.filter(mentioned);
  if(!hits.length&&scope!==null)hits=all.filter(r=>r.id===scope&&!r.parent);
  if(hits.length!==1)return null;
  const r=hits[0],title=titleNames.test(intent),body=bodyNames.test(intent);
  if(title===body)return null;
  const field=title?r.title:r.body;if(!field)return null;
  const english=/\bEnglish\b|英文|英语/i.test(intent),chinese=/\bChinese\b|中文|汉语/i.test(intent);
  const languages=english===chinese?["en","zh"]:english?["en"]:["zh"];
  return {op:r.op,id:r.id,...(r.parent?{parent:r.parent}:{}),field,languages,current:r.row[field]};
}
export function focusedReplySchema(ref,literal){
  const exact=value=>({type:"string",enum:[value]});
  const obj=(properties,required=Object.keys(properties))=>({type:"object",properties,required,additionalProperties:false});
  // A verbatim replacement supplied by the author is fixed by the grammar.
  // Creative writing and translation keep a free string for model-generated prose.
  const pair=obj(Object.fromEntries(ref.languages.map(k=>[k,literal&&ref.languages.length===1?exact(literal):{type:"string"}])),ref.languages.length===1?ref.languages:[]);
  const op=obj({op:exact(ref.op),...(ref.parent?{parent:exact(ref.parent)}:{}),value:obj({id:exact(ref.id),[ref.field]:pair})});
  return obj({operations:{type:"array",minItems:1,maxItems:1,items:op}});
}
/** Separate an explicitly supplied literal from a trailing “Keep ...” instruction.
 * Free-form writing briefs have no literal and are written entirely by the model. */
export function requestedLiteral(prompt) {
  const match=prompt.match(/(?:\bto\s*[:：]|(?:改为|改成|替换为)\s*[:：])\s*([\s\S]+)/iu);
  if(!match)return undefined;
  let value=match[1].split(/(?<=[.!?。！？"'”’」』])\s+(?=(?:Keep|Preserve|Retain|Leave)\b)|(?<=[。！？」』])\s*(?=保留|保持|其余)/u)[0].trim();
  const quotes={'"':'"','“':'”',"'":"'","‘":"’","「":"」","『":"』"};
  if(value.length>1&&quotes[value[0]]===value.at(-1))value=value.slice(1,-1);
  return value||undefined;
}
export function checkFocusedProposal(proposal,ref) {
  if(!ref)return;
  const op=proposal?.operations?.[0],v=op?.value,pair=v?.[ref.field];
  if(proposal?.operations?.length!==1||op?.op!==ref.op||op?.parent!==ref.parent||v?.id!==ref.id||Object.keys(v).some(k=>k!=="id"&&k!==ref.field)||
    !pair||typeof pair!=="object"||Object.keys(pair).some(k=>!ref.languages.includes(k))){
    throw new Error("The model changed fields beyond the single requested text edit. No proposal was applied. 模型修改了指定文本以外的字段，这次建议未应用。");
  }
}
