import { createTextEngine } from "./text-engine.js";
const engine = createTextEngine();
const validId = (v) =>
  typeof v === "string" &&
  /^[a-zA-Z0-9_][a-zA-Z0-9_-]{0,79}$/.test(v) &&
  !["__proto__", "prototype", "constructor"].includes(v);
const object = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const copy = (v, n) =>
  object(v) &&
  ["en", "zh"].every((k) => typeof v[k] === "string" && v[k].length <= n);
const list = (v, n) => Array.isArray(v) && v.length <= n;
const unique = (rows) =>
  rows.every((r) => object(r) && validId(r.id)) &&
  new Set(rows.map((r) => r.id)).size === rows.length;
const preference = (p) => "lantern-text-passage-" + p.id;
export function getTextSelection(project) {
  if (!Array.isArray(project?.passages)) return "";
  let id;
  try {
    id =
      globalThis.sessionStorage?.getItem(preference(project)) ||
      globalThis.window?.localStorage?.getItem(preference(project));
  } catch {}
  return (
    [id, project.start, project.passages[0]?.id].find(
      (id) => id && project.passages.some((p) => p?.id === id),
    ) || ""
  );
}
export function setTextSelection(project, id) {
  if (!project?.passages?.some((p) => p.id === id)) return false;
  try {
    globalThis.sessionStorage?.setItem(preference(project), id);
  } catch {}
  try {
    globalThis.window?.localStorage?.setItem(preference(project), id);
  } catch {}
  return true;
}
export function validateTextAdventure(p, lang = "en") {
  const errors = [],
    warnings = [],
    t = (en, zh) => (lang === "zh" ? zh : en);
  const invalid = (en, zh) => {
    if (errors.length < 100) errors.push(t(en, zh));
  };
  const warn = (en, zh) => {
    if (warnings.length < 100) warnings.push(t(en, zh));
  };
  if (
    !object(p) ||
    p.kind !== "text-adventure" ||
    p.version !== 7 ||
    !validId(p.id) ||
    !copy(p.title, 300) ||
    (p.credits !== undefined && !copy(p.credits, 30000))
  )
    invalid(
      "Invalid text adventure identity, version, title or credits.",
      "文字冒险的标识、版本、标题或署名无效。",
    );
  if (
    !list(p?.passages, 180) ||
    !p.passages.length ||
    !list(p.items, 80) ||
    !list(p.flags, 80) ||
    !list(p.materials ?? [], 256)
  ) {
    invalid(
      "Use 1–180 passages and lists of up to 80 items and flags each.",
      "请使用 1 至 180 个段落；道具和标记各最多 80 项。",
    );
    return { errors, warnings };
  }
  for (const [rows, en, zh] of [
    [p.passages, "passage", "段落"],
    [p.items, "item", "道具"],
    [p.flags, "flag", "标记"],
  ]) {
    if (!unique(rows))
      invalid("Invalid or duplicate " + en + " ID.", zh + "标识无效或重复。");
  }
  const passages = new Set(p.passages.map((r) => r?.id)),
    items = new Set(p.items.map((r) => r?.id)),
    flags = new Set(p.flags.map((r) => r?.id));
  if (!validId(p.start) || !passages.has(p.start))
    invalid("Choose an existing starting passage.", "请选择已有段落作为起点。");
  for (const row of [...p.items, ...p.flags]) {
    if (!copy(row?.name, 300) || !engine.local(row.name, "en"))
      invalid(
        "Each item and flag needs a name in at least one language.",
        "每个道具和标记都需要至少一种语言的名称。",
      );
  }
  const textRef = (value, set) =>
    value === undefined || value === "" || (validId(value) && set.has(value));
  const validMedia = (id, kind) =>
    id === undefined ||
    id === "" ||
    (validId(id) &&
      (p.materials || []).some((m) => m?.id === id && m.kind === kind));
  for (const s of p.passages) {
    if (
      !s ||
      !copy(s.title, 300) ||
      !copy(s.body, 30000) ||
      typeof s.ending !== "boolean" ||
      !list(s.actions, 48) ||
      !unique(s.actions)
    ) {
      invalid(
        "A passage has invalid text, ending status or actions.",
        "某段落的文本、结局状态或行动列表无效。",
      );
      continue;
    }
    if (!validMedia(s.image, "image") || !validMedia(s.audio, "audio"))
      invalid(
        "Choose project media of the correct type for " +
          s.id +
          " or clear its assignment.",
        "请为段落 " + s.id + " 选择正确类型的工程素材，或清除该设置。",
      );
    if (s.ending && s.actions.length)
      invalid(
        "An ending cannot contain actions: " + s.id,
        "结局段落不能含有行动：" + s.id,
      );
    if (!s.ending && !s.actions.length)
      warn(
        "Unfinished passage with no actions: " + s.id,
        "无行动的未完成段落：" + s.id,
      );
    if (!engine.local(s.title, "en"))
      warn("Passage has no title: " + s.id, "段落标题为空：" + s.id);
    if (!engine.local(s.body, "en"))
      warn("Passage has no text: " + s.id, "段落正文为空：" + s.id);
    const labels = new Map();
    for (const a of s.actions) {
      if (
        !copy(a.label, 250) ||
        !engine.local(a.label, "en") ||
        (a.reply !== undefined && !copy(a.reply, 8000)) ||
        !validId(a.target) ||
        !passages.has(a.target)
      ) {
        invalid(
          "An action in " +
            s.id +
            " needs a label and an existing destination.",
          "段落 " + s.id + " 的某个行动缺少标题或有效的目标段落。",
        );
        continue;
      }
      if (
        a.aliases !== undefined &&
        (!object(a.aliases) ||
          !["en", "zh"].every(
            (k) =>
              list(a.aliases[k], 24) &&
              a.aliases[k].every(
                (x) => typeof x === "string" && x.trim() && x.length <= 120,
              ),
          ))
      ) {
        invalid(
          "Use lists of up to 24 short command aliases per language in " +
            s.id +
            ".",
          "段落 " + s.id + " 的每种语言最多支持 24 个简短的同义指令。",
        );
        continue;
      }
      if (
        ["needsItem", "lacksItem", "give", "take"].some(
          (k) => !textRef(a[k], items),
        ) ||
        ["needsFlag", "lacksFlag", "set", "clear"].some(
          (k) => !textRef(a[k], flags),
        )
      )
        invalid(
          "Unknown item or flag on " + s.id + " / " + a.id + ".",
          "段落 " + s.id + " 的行动 " + a.id + " 引用了不存在的道具或标记。",
        );
      if (
        (a.lacksItem &&
          (a.lacksItem === a.needsItem || a.lacksItem === a.take)) ||
        (a.needsFlag && a.needsFlag === a.lacksFlag) ||
        (a.give && a.give === a.take) ||
        (a.set && a.set === a.clear)
      )
        invalid(
          "Contradictory conditions or effects on " + s.id + " / " + a.id + ".",
          "段落 " + s.id + " 的行动 " + a.id + " 含有互相矛盾的条件或效果。",
        );
      for (const phrase of new Set(
        [
          a.label.en,
          a.label.zh,
          ...(a.aliases?.en || []),
          ...(a.aliases?.zh || []),
        ]
          .map(engine.normalize)
          .filter(Boolean),
      )) {
        if (labels.has(phrase) && labels.get(phrase) !== a.id)
          warn(
            "Overlapping command in " + s.id + " · " + phrase,
            "段落 " + s.id + " 中有重复指令 · " + phrase,
          );
        labels.set(phrase, a.id);
      }
    }
  }
  if (!p.passages.some((s) => s?.ending))
    warn("The story has no ending yet.", "故事尚无结局。");
  return { errors, warnings };
}
// Traverse the same legal actions a player sees, with an explicit ceiling for large branching projects.
export function exploreTextAdventure(p, limit = 3500) {
  const key = (s) =>
    JSON.stringify([s.passage, [...s.items].sort(), [...s.flags].sort()]);
  const first = engine.start(p),
    queue = [first],
    seen = new Set([key(first)]),
    reached = new Set(),
    endings = new Set(),
    dead = new Set();
  let capped = false;
  for (let i = 0; i < queue.length; i++) {
    const s = queue[i],
      passage = engine.passage(p, s);
    reached.add(s.passage);
    if (passage.ending) {
      endings.add(s.passage);
      continue;
    }
    let legal = 0;
    for (const a of passage.actions) {
      const next = engine.move(p, s, a.id);
      if (!next) continue;
      legal++;
      const k = key(next);
      if (seen.has(k)) continue;
      if (queue.length >= limit) {
        capped = true;
        continue;
      }
      seen.add(k);
      queue.push(next);
    }
    if (!legal) dead.add(s.passage);
  }
  return {
    reached: [...reached],
    endings: [...endings],
    dead: [...dead],
    capped,
    states: seen.size,
  };
}
export function checkTextAdventure(p, lang = "en") {
  const t = (en, zh) => (lang === "zh" ? zh : en),
    { errors, warnings } = validateTextAdventure(p, lang);
  if (errors.length) return errors;
  const r = exploreTextAdventure(p),
    name = (id) =>
      engine.local(p.passages.find((s) => s.id === id)?.title, lang) || id;
  const lines = [
    t("Reachable endings", "可到达的结局") +
      " · " +
      r.endings.length +
      " / " +
      p.passages.filter((s) => s.ending).length,
    ...r.endings.map((id) => t("Reached", "已到达") + " · " + name(id)),
    ...warnings,
  ];
  if (r.capped)
    lines.push(
      t(
        "Search budget reached. Additional routes need a manual playtest.",
        "已达搜索上限，其余路线需要手动试玩。",
      ),
    );
  else
    for (const s of p.passages.filter((s) => !r.reached.includes(s.id)))
      lines.push(
        t("Unreachable passage", "无法到达的段落") + " · " + name(s.id),
      );
  for (const id of r.dead)
    lines.push(
      t("A reachable state has no available action", "某个可达状态无可用行动") +
        " · " +
        name(id),
    );
  return lines;
}
