// Coordinates are fractions of the displayed room picture. Flags belong to the
// game session, so revisiting a clue never resets a discovery.
import { mysteryStep } from "./mystery-state.js";
export { mysteryStep };
export const translated = (en = "", zh = "") => ({ en, zh });
export const localText = (value, lang) =>
  value?.[lang] || value?.[lang === "zh" ? "en" : "zh"] || "";
export const newId = (prefix) => prefix + "_" + crypto.randomUUID().replaceAll("-", "");

export function newMysteryAction(id = newId("act")) {
  return {
    id,
    label: translated("Examine", "查看"),
    requires: "",
    requiresState: "set",
    effect: "",
    effectState: "set",
    feedback: translated(),
    blocked: translated(),
    ending: "",
    material: "",
  };
}

export function createMystery({ blank = false, art = "", audio = "" } = {}) {
  const t = translated;
  const p = {
    version: 6,
    kind: "point-mystery",
    id: newId("mystery"),
    title: blank
      ? t("Untitled mystery", "未命名谜案")
      : t("Locked Observatory", "上锁的天文台"),
    credits: blank
      ? t()
      : t("An original Lantern Studio mystery.", "Lantern Studio 原创谜案。"),
    materials: [],
    flags: [],
    hotspots: [],
    endings: [],
    room: {
      intro: blank
        ? t()
        : t(
            "The dome is locked until dawn. Through the static, three notes repeat. Someone on the mountain is waiting for an answer.",
            "穹顶将封锁至黎明。杂音中，三个音符不断重复。山里有人在等你的回应。",
          ),
      background: "",
      ambience: "",
    },
  };
  if (blank) return p;
  function material(id, name, kind, mime, data, credit, prompt = "") {
    p.materials.push({
      id,
      name,
      kind,
      mime,
      data,
      credit,
      source: "",
      license: "CC0-1.0",
      prompt,
      tags: [],
    });
  }
  if (art) {
    material(
      "dome",
      "Observatory interior · 天文台室内",
      "image",
      "image/webp",
      art,
      "Lantern Studio · AI-assisted illustration",
      "Create original wide 16:9 background art for a 2D indie point-and-click mystery, a locked mountaintop observatory, 1890s. A carefully composed atmospheric hand-painted storybook gouache illustration, sharp confident shapes, cinematic soft light and subtle paper grain, jewel dark teal and warm honey brass palette, a believable beautiful inviting room. Full-frame landscape architecture viewed from inside at night. Three spatially SEPARATE, easily visible game props 1) open illuminated astronomical logbook atop a broad wooden desk in the LOWER LEFT quarter, its book centered 22% across 72% down, 2) magnificent large brass telescope with tripod CENTER of the room, shaft centered 53% across 48% down, 3) a vintage signal transmitter console with a red telegraph lever and small glowing amber bulbs on a pedestal on the RIGHT, centered 83% across 63% down. Behind the telescope a grand circular dome window with shadowed struts, crescent moon, luminous stars and misty mountains below. The observatory's high dark ribbed dome occupies upper part of composition, charming shelves on side walls, uncluttered near scenery. Balanced midtones for readability. No text, letters, numbers, labels, typography, watermark, callouts, user interface, border, people, decorative Celtic knots or insignia. All three props fully within frame. Highest craft of indie point and click adventure environment concept art. Landscape 16:9, one frame only.",
    );
    p.room.background = "dome";
  }
  material(
    "margin",
    "A note in the margin · 页边手记",
    "text",
    "text/plain",
    "03:17 · Cygnus, 42° NE\nIf three notes return, the ship has made it home.\n\n03:17 · 天鹅座，东北 42°\n若听见三个回音，说明飞船已平安归来。",
    "Lantern Studio",
  );
  if (audio)
    material(
      "notes",
      "Three returning notes · 三声回音",
      "audio",
      "audio/wav",
      audio,
      "Lantern Studio · synthesized tones",
    );
  p.flags = ["coordinates", "signal"];
  const action = (id, label, feedback, options = {}) => ({
    ...newMysteryAction(id),
    label,
    feedback,
    ...options,
  });
  p.hotspots = [
    {
      id: "ledger",
      name: t("Star ledger", "观星手记"),
      rect: { x: 0.06, y: 0.63, w: 0.28, h: 0.24 },
      actions: [
        action(
          "read",
          t("Read the margin", "读页边手记"),
          t(
            "A mark in the margin points to Cygnus. You copy the coordinates onto your sleeve.",
            "页边的记号指向天鹅座。你把坐标抄在衣袖上。",
          ),
          { effect: "coordinates", material: "margin" },
        ),
      ],
    },
    {
      id: "telescope",
      name: t("Brass telescope", "黄铜望远镜"),
      rect: { x: 0.35, y: 0.25, w: 0.34, h: 0.39 },
      actions: [
        action(
          "align",
          t("Align the telescope", "校准望远镜"),
          t(
            "Three flashes answer from beyond the ridge. The missing ship is safe.",
            "山脊后闪起三道回应的光。失踪的飞船平安无事。",
          ),
          {
            requires: "coordinates",
            effect: "signal",
            blocked: t(
              "The sky is too wide to search. Where did the last astronomer record her bearings?",
              "星空太大了。上一位天文学家把方位记在哪儿了？",
            ),
            material: audio ? "notes" : "",
          },
        ),
      ],
    },
    {
      id: "transmitter",
      name: t("Signal transmitter", "信号发射台"),
      rect: { x: 0.71, y: 0.5, w: 0.23, h: 0.3 },
      actions: [
        action("broadcast", t("Broadcast the coordinates", "广播坐标"), t(), {
          requires: "signal",
          blocked: t(
            "The rescue tower needs a confirmed sighting. Check the telescope first.",
            "救援塔需要确切的目击信息，先去望远镜看看。",
          ),
          ending: "dawn",
        }),
        action("quiet", t("Send a private reply", "发送私人回信"), t(), {
          requires: "signal",
          blocked: t(
            "You need to see who is calling before you answer privately.",
            "你得先确认是谁在呼叫，才能私下回信。",
          ),
          ending: "secret",
        }),
      ],
    },
  ];
  p.endings = [
    {
      id: "dawn",
      title: t("A signal at dawn", "黎明的信号"),
      text: t(
        "Your broadcast brings every rescue lamp on the ridge to life. By sunrise, the missing crew is walking home.",
        "广播响彻山谷，山脊上的救援灯依次亮起。日出时分，失踪的船员终于踏上归途。",
      ),
    },
    {
      id: "secret",
      title: t("Between the stars", "群星之间的秘密"),
      text: t(
        "You return the three notes on the private channel. A silver wing tips in farewell. The sky keeps its secret.",
        "你在私人频道回送三个音符。银色机翼轻轻倾斜，向你道别。星空守住了它的秘密。",
      ),
    },
  ];
  return p;
}

export function validateMystery(p, lang = "en") {
  const errors = [],
    warnings = [],
    add = (en, zh) => errors.push(lang === "zh" ? zh : en);
  const warn = (en, zh) => warnings.push(lang === "zh" ? zh : en);
  const id = (v) => typeof v === "string" && /^[A-Za-z0-9_-]{1,100}$/.test(v);
  const bi = (v, max = 12000) =>
    v &&
    ["en", "zh"].every((k) => typeof v[k] === "string" && v[k].length <= max);
  const object = (v) => v && typeof v === "object" && !Array.isArray(v);
  const list = (v, n) => Array.isArray(v) && v.length <= n;
  if (
    !object(p) ||
    p.version !== 6 ||
    p.kind !== "point-mystery" ||
    !id(p.id) ||
    !bi(p.title, 300) ||
    !bi(p.credits, 30000)
  )
    add(
      "Invalid mystery identity, version, title or credits.",
      "谜案标识、版本、标题或署名无效。",
    );
  if (
    !object(p?.room) ||
    !bi(p.room.intro) ||
    !list(p.materials, 256) ||
    !list(p.flags, 32) ||
    !list(p.hotspots, 36) ||
    !list(p.endings, 24)
  ) {
    add(
      "A mystery needs room settings and lists of materials, flags, hotspots and endings.",
      "谜案需包含房间设置及素材、标记、互动区和结局列表。",
    );
    return { errors, warnings };
  }
  const mat = (ref, kinds) =>
    ref === "" ||
    (typeof ref === "string" &&
      p.materials.some((m) => m?.id === ref && kinds.includes(m.kind)));
  if (!mat(p.room.background, ["image"]) || !mat(p.room.ambience, ["audio"]))
    add(
      "Choose an existing background image and ambience track, or leave them empty.",
      "请选择已有的背景图片和环境音轨，或将其留空。",
    );
  if (
    p.flags.some((f) => typeof f !== "string" || !f.trim() || f.length > 100) ||
    new Set(p.flags).size !== p.flags.length
  )
    add(
      "Flags need distinct names, up to 100 characters each.",
      "标记名称不能重复或为空，每个名称不超过 100 字。",
    );
  const ids = (a) =>
    a.every((o) => object(o) && id(o.id)) &&
    new Set(a.map((o) => o.id)).size === a.length;
  if (!ids(p.hotspots) || !ids(p.endings))
    add(
      "Hotspot and ending IDs must be unique within each list.",
      "互动区与结局的标识必须在各自的列表内唯一。",
    );
  for (const h of p.hotspots) {
    const r = h?.rect;
    if (
      !bi(h?.name, 300) ||
      !r ||
      !["x", "y", "w", "h"].every(
        (k) => typeof r[k] === "number" && Number.isFinite(r[k]),
      ) ||
      r.x < 0 ||
      r.y < 0 ||
      r.w < 0.02 ||
      r.h < 0.02 ||
      r.x + r.w > 1.000001 ||
      r.y + r.h > 1.000001
    )
      add(
        "Each hotspot needs a name and a rectangle inside the picture.",
        "每个互动区均需名称及位于图内的矩形范围。",
      );
    if (!list(h?.actions, 12) || !ids(h.actions)) {
      add(
        "Each hotspot needs a list of actions with unique IDs.",
        "每个互动区均需带有唯一标识的操作列表。",
      );
      continue;
    }
    if (!h.actions.length)
      warn("A hotspot has no actions.", "有一个互动区没有操作。");
    for (const a of h.actions) {
      if (
        !bi(a.label, 300) ||
        !bi(a.feedback) ||
        !bi(a.blocked) ||
        !["set", "unset"].includes(a.requiresState) ||
        !["set", "unset"].includes(a.effectState) ||
        ![a.requires, a.effect].every((f) => f === "" || p.flags.includes(f)) ||
        !(a.ending === "" || p.endings.some((e) => e?.id === a.ending)) ||
        !mat(a.material, ["image", "audio", "video", "text"])
      ) {
        add(
          "Check this action’s text, flag, ending and material references.",
          "请检查操作文本及其引用的标记、结局和素材。",
        );
      }
    }
  }
  if (p.endings.some((e) => !bi(e?.title, 300) || !bi(e?.text)))
    add(
      "Each ending needs a bilingual title and text field.",
      "每个结局需要双语标题及正文栏。",
    );
  if (!p.hotspots.length)
    warn(
      "Add a hotspot to give players something to explore.",
      "添加互动区，让玩家可以探索。",
    );
  if (!p.endings.length)
    warn(
      "Add an ending and attach it to a hotspot action.",
      "请添加结局，并和互动区的操作关联。",
    );
  return { errors, warnings };
}

export function checkMystery(p, lang = "en") {
  const { errors, warnings } = validateMystery(p, lang);
  if (errors.length) return errors;
  const t = (en, zh) => (lang === "zh" ? zh : en);
  const queue = [{ flags: [], ending: "" }],
    seen = new Set(["[]"]),
    found = new Set();
  for (let i = 0; i < queue.length && i < 1500; i++) {
    for (const h of p.hotspots)
      for (const a of h.actions) {
        const s = mysteryStep(p, queue[i], h.id, a.id);
        if (s.ending) found.add(s.ending);
        else {
          const key = JSON.stringify(s.flags);
          if (!seen.has(key) && seen.size <= 1500) {
            seen.add(key);
            queue.push(s);
          }
        }
      }
  }
  const partial = seen.size > 1500;
  const lines = [
    t(
      `${p.hotspots.length} hotspots · ${p.flags.length} flags · ${found.size}/${p.endings.length} endings reached.`,
      `${p.hotspots.length} 个互动区 · ${p.flags.length} 个标记 · 可达结局 ${found.size}/${p.endings.length}。`,
    ),
    ...warnings,
  ];
  if (partial)
    lines.push(
      t(
        "The 1,500-state search limit was reached. Playtest remaining routes.",
        "已达到 1,500 个状态的搜索上限，请试玩其余路线。",
      ),
    );
  for (const e of p.endings.filter((e) => !found.has(e.id)))
    lines.push(
      t(
        partial ? "Still to verify — " : "Unreachable ending — ",
        partial ? "待验证的结局 — " : "不可达的结局 — ",
      ) + (localText(e.title, lang) || e.id),
    );
  const required = [
    p.title,
    ...p.hotspots.flatMap((h) => [
      h.name,
      ...h.actions.flatMap((a) => [
        a.label,
        ...[a.feedback, a.blocked].filter((v) => v.en || v.zh),
      ]),
    ]),
    ...p.endings.flatMap((e) => [e.title, e.text]),
    ...[p.room.intro, p.credits].filter((v) => v.en || v.zh),
  ];
  const missing = required.filter((v) => !v.en.trim() || !v.zh.trim()).length;
  lines.push(
    missing
      ? t(
          `${missing} bilingual fields still need text in one or both languages.`,
          `有 ${missing} 个双语栏需补充译文。`,
        )
      : t(
          "All authored text fields have both languages.",
          "已填写的文本都有中英文。",
        ),
  );
  return lines;
}
