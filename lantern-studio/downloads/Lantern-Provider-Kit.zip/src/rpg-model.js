const bi = (en, zh) => ({ en, zh });
export const rpgKinds = [
  "talk",
  "quest",
  "chest",
  "passage",
  "rest",
  "battle",
  "ending",
];
export const milestoneKinds = ["quest", "chest", "battle"];
const id = (value) =>
  typeof value === "string" &&
  /^[a-zA-Z0-9_][a-zA-Z0-9_-]{0,79}$/.test(value) &&
  !["constructor", "prototype", "__proto__"].includes(value);
const integer = (n, min, max) => Number.isInteger(n) && n >= min && n <= max;
export const rpgId = (prefix) =>
  prefix +
  "_" +
  (globalThis.crypto?.randomUUID?.() || Math.random().toString(36).slice(2));
const spot = (id, kind, x, y, en, zh, line, cn, extra = {}) => ({
  id,
  kind,
  x,
  y,
  name: bi(en, zh),
  text: bi(line, cn),
  ...extra,
});
export function newRpgMap(mapId = rpgId("map")) {
  return {
    id: mapId,
    name: bi("New crossing", "新渡口"),
    layout: ["#######", "#.....#", "#.....#", "#.....#", "#######"],
    spawn: { x: 1, y: 2 },
    spots: [],
  };
}
export function newRpgSpot(kind, x, y) {
  const names = {
    talk: bi("Villager", "村民"),
    quest: bi("Quest giver", "委托人"),
    chest: bi("Chest", "宝箱"),
    passage: bi("Passage", "通道"),
    rest: bi("Rest stop", "歇脚处"),
    battle: bi("Spirit", "精怪"),
    ending: bi("Journey’s end", "旅途终点"),
  };
  return {
    id: rpgId(kind),
    kind,
    x,
    y,
    name: names[kind],
    text: bi("", ""),
    ...(kind === "battle"
      ? { hp: 10, attack: 3, xp: 4 }
      : kind === "quest"
        ? { xp: 3 }
        : {}),
    ...(kind === "ending" ? { altText: bi("", "") } : {}),
  };
}
export function createRpgProject({ blank = false } = {}) {
  const quay = {
    id: "quay",
    name: bi("Mistford Quay", "雾渡码头"),
    spawn: { x: 1, y: 2 },
    layout: [
      "#########",
      "#..,,...#",
      "#,,,,,,.#",
      "#..,.~..#",
      "#..,....#",
      "#########",
    ],
    spots: [
      spot(
        "wen",
        "quest",
        2,
        1,
        "Ferry Keeper Wen",
        "守渡人温伯",
        "The bell-rope snapped in the flood. Bring me the bronze bell from the reed marsh; its note opens the court.",
        "洪水扯断了铃绳。请去芦荡寻回铜铃；铃声一响，通往铃庭的路就会打开。",
        { item: "bell", xp: 2 },
      ),
      spot(
        "lin",
        "quest",
        3,
        4,
        "Weaver Lin",
        "织娘林姨",
        "My daughter tied a red ribbon to the bell so boats would see it in fog. Bring it back, and we can mend the rope together.",
        "女儿把红绸系在铃上，好让雾里的船看见。把红绸带回来，我们一起补好铃绳。",
        { item: "ribbon", xp: 3 },
      ),
      spot(
        "inn",
        "rest",
        1,
        3,
        "Lotus Tea Stall",
        "荷茶摊",
        "Steam rises from a clay cup. Drink, rest and refill your travel flask.",
        "陶杯里热气袅袅。喝口热茶，歇脚，把药壶添满。",
      ),
      spot(
        "marsh_way",
        "passage",
        7,
        2,
        "Enter Reed Marsh",
        "前往芦荡",
        "Follow the old towpath between the reeds.",
        "循着纤道，拨开芦苇。",
        { to: "marsh" },
      ),
      spot(
        "court_way",
        "passage",
        7,
        1,
        "Enter Bell Court",
        "前往铃庭",
        "The bronze chime parts the mist. A stone bridge leads upriver.",
        "铜铃驱散雾气，一座石桥通向上游。",
        { to: "court", requires: "wen" },
      ),
    ],
  };
  const marsh = {
    id: "marsh",
    name: bi("Reed Marsh", "芦花荡"),
    spawn: { x: 1, y: 2 },
    layout: [
      "#########",
      "#..~....#",
      "#,,,.,,.#",
      "#.~..~..#",
      "#.......#",
      "#########",
    ],
    spots: [
      spot(
        "back_quay",
        "passage",
        1,
        1,
        "Return to Mistford Quay",
        "返回雾渡码头",
        "The ferry lantern glows beyond the reeds.",
        "芦苇尽头，渡灯亮着。",
        { to: "quay" },
      ),
      spot(
        "bell_box",
        "chest",
        6,
        2,
        "Bronze Bell Chest",
        "铜铃匣",
        "Wrapped in rush leaves, the missing bell rings once against your palm.",
        "层层芦叶中，失落的铜铃在掌心轻轻一响。",
        { item: "bell" },
      ),
      spot(
        "ribbon_box",
        "chest",
        3,
        4,
        "Ribbon Chest",
        "红绸匣",
        "A red ribbon floats inside a lacquer box. Someone stitched a small boat into its hem.",
        "漆匣里躺着一条红绸，边角绣着一叶小舟。",
        { item: "ribbon" },
      ),
      spot(
        "wisp",
        "battle",
        7,
        4,
        "Reed Wisp",
        "芦灯灵",
        "A green spark skips over the reeds. Steady its flicker before it scorches the marsh.",
        "一点青火跳过芦梢。稳住它的火光，别让芦荡着起来。",
        { hp: 7, attack: 2, xp: 4 },
      ),
    ],
  };
  const court = {
    id: "court",
    name: bi("Bell Court", "古铃庭"),
    spawn: { x: 1, y: 2 },
    layout: [
      "########",
      "#...~..#",
      "#,,,,,.#",
      "#..~...#",
      "#......#",
      "########",
    ],
    spots: [
      spot(
        "court_home",
        "passage",
        1,
        1,
        "Return to Mistford Quay",
        "返回雾渡码头",
        "The stone bridge winds homeward.",
        "顺着石桥，就能回到渡口。",
        { to: "quay" },
      ),
      spot(
        "warden",
        "battle",
        4,
        2,
        "Mist Warden",
        "雾庭守灵",
        "The guardian raises a mirror of river mist. Break its rhythm with the bell before the ford vanishes.",
        "守灵举起一面水雾之镜。赶在渡口隐去之前，用铜铃打乱它的节律。",
        { hp: 16, attack: 4, xp: 6 },
      ),
      spot(
        "pavilion",
        "ending",
        6,
        3,
        "Bell Pavilion",
        "鸣铃亭",
        "One clear note rolls downriver. A lone boat finds the lantern and comes home. You promise to keep the ford lit.",
        "一声清铃沿河荡开。孤舟循灯归岸，你应下了守渡的约定。",
        {
          requires: "warden",
          altFlag: "lin",
          altText: bi(
            "The mended red ribbon unfurls. Every family rings a little bell from its door, and the whole fleet answers through the silver mist.",
            "补好的红绸迎风展开。家家门前响起小铃，银雾里的船队一一应和。",
          ),
        },
      ),
    ],
  };
  const empty = newRpgMap("crossing");
  empty.spots.push(
    spot(
      "home",
      "ending",
      5,
      2,
      "Home lantern",
      "归家灯",
      "Your footsteps reach the waiting light.",
      "你循着灯光踏上归途。",
    ),
  );
  return {
    version: 7,
    kind: "quest-rpg",
    id: blank ? rpgId("rpg") : "bells_of_mistford",
    title: blank
      ? bi("Untitled quest", "未命名奇遇")
      : bi("Bells of Mistford", "雾渡寻铃"),
    credits: blank
      ? bi("", "")
      : bi(
          "Original story, maps and game rules by Lantern Studio contributors.",
          "原创故事、地图与游戏规则：Lantern Studio 贡献者。",
        ),
    materials: [],
    rpg: {
      hero: blank ? bi("Traveler", "旅人") : bi("Lan", "阿澜"),
      opening: blank
        ? bi(
            "Follow the path and write the first chapter of your journey.",
            "沿着小径走去，写下旅途的第一章。",
          )
        : bi(
            "At dawn the river goes silent. Without the ferry bell, the last boats cannot find the shore. Speak with Keeper Wen, who tends the crossing.",
            "拂晓时，河面忽然寂静。渡铃不响，最后一批船就寻不到岸。去找守渡人温伯问问吧。",
          ),
      maxHp: 14,
      power: 4,
      startingTonics: 2,
      heal: 8,
      cover: "",
      music: "",
      start: blank ? "crossing" : "quay",
      items: blank
        ? []
        : [
            {
              id: "bell",
              name: bi("Bronze ferry bell", "渡口铜铃"),
              description: bi(
                "Its note carries across the fog.",
                "铃声能穿过河雾。",
              ),
            },
            {
              id: "ribbon",
              name: bi("Boat-stitched ribbon", "绣舟红绸"),
              description: bi(
                "A red ribbon stitched with a tiny boat.",
                "绣有小舟的红绸。",
              ),
            },
          ],
      maps: blank ? [empty] : [quay, marsh, court],
    },
  };
}
export function validateRpg(p, lang = "en") {
  const zh = lang === "zh",
    errors = [],
    warnings = [],
    t = (a, b) => (zh ? b : a);
  const add = (list, a, b) => {
    if (list.length < 45) list.push(t(a, b));
  };
  const fail = (a, b) => add(errors, a, b),
    warn = (a, b) => add(warnings, a, b);
  const obj = (v) => v && typeof v === "object" && !Array.isArray(v);
  if (
    !obj(p) ||
    p.kind !== "quest-rpg" ||
    p.version !== 7 ||
    !id(p.id) ||
    !obj(p.rpg)
  ) {
    fail("Expected a version 7 quest RPG.", "需要第 7 版剧情角色扮演工程。");
    return { errors, warnings };
  }
  const r = p.rpg;
  const text = (v, label, limit = 4000, required = true) => {
    if (
      !obj(v) ||
      !["en", "zh"].some((k) => Object.hasOwn(v, k)) ||
      ["en", "zh"].some(
        (k) =>
          Object.hasOwn(v, k) &&
          (typeof v[k] !== "string" || v[k].length > limit),
      )
    )
      fail(
        "Invalid bilingual text · " + label,
        "双语文本格式或长度不正确 · " + label,
      );
    else if (required && !v.en?.trim() && !v.zh?.trim())
      warn("Write a caption · " + label, "请填写文本 · " + label);
  };
  text(p.title, t("game title", "游戏标题"), 300);
  if (p.credits !== undefined)
    text(p.credits, t("credits", "署名"), 30000, false);
  text(r.hero, t("traveler", "旅人"), 150);
  text(r.opening, t("opening", "开场"));
  for (const [key, min, max] of [
    ["maxHp", 1, 100],
    ["power", 1, 30],
    ["startingTonics", 0, 12],
    ["heal", 1, 100],
  ])
    if (!integer(r[key], min, max))
      fail("Check the traveler’s combat values.", "请检查旅人的战斗数值。");
  for (const [key, kind] of [
    ["cover", "image"],
    ["music", "audio"],
  ])
    if (
      r[key] !== undefined &&
      r[key] !== "" &&
      (!id(r[key]) ||
        !Array.isArray(p.materials) ||
        !p.materials.some((m) => m?.id === r[key] && m.kind === kind))
    )
      fail(
        "Choose an existing " + kind + " material.",
        "请选择对应的工程素材。",
      );
  if (
    !Array.isArray(r.maps) ||
    r.maps.length < 1 ||
    r.maps.length > 16 ||
    !Array.isArray(r.items) ||
    r.items.length > 96
  ) {
    fail(
      "Use 1–16 maps and up to 96 quest items.",
      "请使用 1–16 张地图，任务物品上限为 96 个。",
    );
    return { errors, warnings };
  }
  const itemIds = new Set(),
    maps = new Set(),
    spots = new Set(),
    flags = new Set(),
    all = [];
  function unique(set, key) {
    if (!id(key) || set.has(key))
      fail(
        "Give each entry a unique, valid ID.",
        "各条目需要唯一且有效的标识。",
      );
    else set.add(key);
  }
  for (const it of r.items) {
    if (!obj(it)) {
      fail("Invalid item.", "物品格式错误。");
      continue;
    }
    unique(itemIds, it.id);
    text(it.name, t("item", "物品"), 150);
    text(
      it.description ?? { en: "" },
      t("description", "物品说明"),
      4000,
      false,
    );
  }
  for (const m of r.maps) {
    if (!obj(m)) {
      fail("Invalid map.", "地图格式错误。");
      continue;
    }
    unique(maps, m.id);
    text(m.name, t("map", "地图"), 150);
    const a = m.layout,
      w = Array.isArray(a) && typeof a[0] === "string" ? a[0].length : 0,
      valid =
        Array.isArray(a) &&
        integer(a.length, 4, 14) &&
        integer(w, 4, 18) &&
        a.every(
          (row) =>
            typeof row === "string" &&
            row.length === w &&
            /^[.,#~]+$/.test(row),
        );
    if (!valid)
      fail(
        "Use a rectangular 4–18 by 4–14 map of ground, path, stone or water.",
        "地图须为宽 4–18、高 4–14 的矩形，地形可用地面、小径、岩石或水。",
      );
    const grounded = (v) =>
      valid &&
      obj(v) &&
      Number.isInteger(v.x) &&
      Number.isInteger(v.y) &&
      [".", ","].includes(a[v.y]?.[v.x]);
    if (!grounded(m.spawn))
      fail(
        "Place the arrival point on walkable ground.",
        "请将抵达点放在可通行的格子上。",
      );
    if (!Array.isArray(m.spots) || m.spots.length > 48) {
      fail(
        "Use at most 48 encounters on a map.",
        "每张地图最多可设置 48 个事件。",
      );
      continue;
    }
    const used = new Set();
    for (const s of m.spots) {
      if (!obj(s) || !rpgKinds.includes(s.kind)) {
        fail("Unknown map event.", "地图事件类型未知。");
        continue;
      }
      unique(spots, s.id);
      if (milestoneKinds.includes(s.kind)) flags.add(s.id);
      all.push(s);
      text(s.name, t("event", "事件"), 150);
      text(s.text, t("dialogue", "对白"), 4000, false);
      const cell = s.x + "," + s.y;
      if (!grounded(s) || used.has(cell))
        fail(
          "Put each event on its own walkable cell.",
          "每个事件应放在独立可通行的格子上。",
        );
      used.add(cell);
      if (s.kind === "ending" && s.altText !== undefined)
        text(s.altText, t("alternate ending", "隐藏结局"), 4000, false);
      if (
        s.kind === "battle" &&
        (!integer(s.hp, 1, 200) || !integer(s.attack, 1, 50))
      )
        fail(
          "Enemy HP must be 1–200 and attack 1–50.",
          "敌方生命须为 1–200，攻击须为 1–50。",
        );
      if (["battle", "quest"].includes(s.kind) && !integer(s.xp ?? 0, 0, 50))
        fail("Experience reward must be 0–50.", "经验奖励须为 0–50。");
    }
  }
  if (!maps.has(r.start))
    fail("Choose an existing starting map.", "请选择已有的起始地图。");
  for (const s of all) {
    for (const [key, set, needed, label] of [
      [
        "to",
        maps,
        s.kind === "passage",
        t("passage destination", "通道目的地"),
      ],
      [
        "item",
        itemIds,
        ["quest", "chest"].includes(s.kind),
        t("quest item", "任务物品"),
      ],
      ["requires", flags, false, t("required milestone", "前置事件")],
      [
        "altFlag",
        flags,
        false,
        t("alternate ending milestone", "隐藏结局事件"),
      ],
    ]) {
      const val = s[key];
      if (
        val !== undefined &&
        val !== "" &&
        (!set.has(val) || (key === "requires" && val === s.id))
      )
        fail(
          "Invalid reference · " + label + " · " + s.id,
          "引用不存在或无效 · " + label + " · " + s.id,
        );
      else if (needed && !val)
        warn("Choose " + label + " · " + s.id, "请选择" + label + " · " + s.id);
    }
  }
  if (!all.some((s) => s.kind === "ending"))
    warn(
      "Add an ending to finish the journey.",
      "请添加一个结局事件，以便结束旅程。",
    );
  return { errors, warnings };
}
