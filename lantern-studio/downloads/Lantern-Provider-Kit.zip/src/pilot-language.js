const descriptions={
  en:{name:"English",inEnglish:"English",inChinese:"(?:英文|英语|英語|英文版)"},
  zh:{name:"Chinese",inEnglish:"(?:Chinese|Mandarin)",inChinese:"(?:中文|汉语|漢語|简体中文|簡體中文)"},
};

/** Detect explicit preservation instructions, independently from locating a named
 * character or editable field. Undetected requests continue through normal review. */
export function protectedLanguages(request){
  if(typeof request!=="string")return [];
  const input=request.normalize("NFKC").replace(/[’‘]/g,"'");
  const prose="(?:text|copy|translation|dialogue|dialog|lines?|writing|prose|feedback|response|captions?|subtitles?|transcript|names?|titles?|content|language|original|wording|version|replies|aliases|verbs|labels?|descriptions?|prompts?)";
  const articles="(?:(?:the|its|his|her|their|my|our|all|any|every|single|other|current|existing|original|originally written|already translated|whole|entire|word of|of|of the|[\\w-]+'s)\\s+)*";
  const zhPrefix="(?:现有|已有|原有|原来|原本|原先|原始|全部|所有|目前|当前|原|他|她|其|的|任何|每条|整部|游戏|项目|工程|中|之)*";
  return Object.entries(descriptions).flatMap(([key,word])=>{
    const language=word.inEnglish,cn=word.inChinese;
    const preserve=new RegExp("\\b(?:keep|keeping|preserve|preserving|retain|retaining|protect|leave|leaving|maintain)\\s+"+articles+language+"\\b","iu");
    const negative=new RegExp("\\b(?:do not|don't|never|without|avoid)\\s+(?:change|alter|modify|edit|rewrite|remove|touch|replace|overwrite|translate|changing|altering|modifying|editing|rewriting|removing|touching|replacing|overwriting|translating)\\s+"+articles+language+"\\b","iu");
    const untouched=new RegExp("\\b"+language+"(?:\\s+"+prose+")?\\s+(?:(?:must|should|shall|has to|is to)\\s+)?(?:stay|remain|be kept|be left)\\s+(?:exactly\\s+)?(?:unchanged|intact|as is|untouched|the same)\\b","iu");
    const chinese=new RegExp("(?:保留|保持|保護|保护|留存|维持|維持|(?:不(?:要|可|能|用|得)?|别|別|勿|不要再)(?:修改|改动|改動|改变|改變|更改|调整|調整|改写|改寫|覆盖|覆蓋|删除|刪除|动|動|改|碰))"+zhPrefix+cn+"|"+cn+"(?:的)?(?:原文|翻译|翻譯|台词|臺詞|对白|對白|文本|文字|内容|內容|名称|名稱|回复|回覆|字幕|反馈|反饋|描述|标签|標籤|提示|版本)?(?:必须|必須|请|請|要)?(?:保持|维持|維持|保留|维持原样|維持原樣|不得改动|不变|不變)(?:不变|不變|原样|原樣|原文)?","u");
    return preserve.test(input)||negative.test(input)||untouched.test(input)||chinese.test(input)?[key]:[];
  });
}

// Stable IDs survive reordering. Coordinates distinguish map signs, locks and
// passages. Anonymous arrays (e.g. timed captions) preserve their text by order.
function textLedger(project,lang){
  const entries=new Map();
  function visit(value,path){
    if(!value||typeof value!=="object")return;
    if(Array.isArray(value)){
      value.forEach((item,i)=>{
        const key=typeof item?.id==="string"?["id",item.id]:Number.isInteger(item?.x)&&Number.isInteger(item?.y)?["cell",item.x,item.y]:["index",i];
        visit(item,[...path,key]);
      });return;
    }
    if(Object.hasOwn(value,"en")||Object.hasOwn(value,"zh")){
      entries.set(JSON.stringify(path),{text:Object.hasOwn(value,lang)?JSON.stringify(value[lang]):undefined,label:path.map(step=>typeof step==="string"?step:"["+step.slice(1).join(",")+"]").join(".")});
      return;
    }
    for(const [key,child] of Object.entries(value)){
      if(["webCode","materials","src","data"].includes(key))continue;
      visit(child,[...path,key]);
    }
  }
  visit(project,[]);return entries;
}
export function verifyProtectedLanguages(original,candidate,request){
  for(const lang of protectedLanguages(request)){
    const before=textLedger(original,lang),after=textLedger(candidate,lang);
    for(const [path,old] of before)if(!after.has(path)||after.get(path).text!==old.text){
      throw new Error("The request preserves "+descriptions[lang].name+" but the proposal changes an existing translation at "+old.label+". 此建议更改了要求保留的"+(lang==="zh"?"中文":"英文")+"文本。");
    }
  }
}
