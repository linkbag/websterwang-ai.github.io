const bi = (en = "", zh = "") => ({ en, zh });
export const textId = (prefix) =>
  prefix + "_" + crypto.randomUUID().replaceAll("-", "").slice(0, 12);
export const newTextPassage = (id) => ({
  id,
  title: bi("New passage", "新段落"),
  body: bi(),
  ending: false,
  image: "",
  audio: "",
  actions: [],
});
export const newTextAction = (target, id = textId("act")) => ({
  id,
  label: bi("Continue", "继续"),
  aliases: { en: [], zh: [] },
  reply: bi(),
  target,
});
export function createTextAdventure({ blank = false } = {}) {
  const project = {
    version: 7,
    kind: "text-adventure",
    id: blank ? textId("text") : "letters_at_low_tide",
    title: bi("Letters at Low Tide", "退潮时的来信"),
    credits: bi(
      "Story and game design by Lantern Studio contributors. Original game and prose released under the MIT License.",
      "故事与游戏设计：Lantern Studio 贡献者。原创游戏及文本采用 MIT 许可证。",
    ),
    start: "slipway",
    items: [],
    flags: [],
    passages: [],
    materials: [],
  };
  if (blank) {
    const opening = newTextPassage("opening");
    opening.title = bi("Opening", "开篇");
    return {
      ...project,
      title: bi("Untitled text adventure", "未命名文字冒险"),
      credits: bi(),
      start: opening.id,
      passages: [opening],
    };
  }
  project.items = [
    { id: "letter", name: bi("Blue-edged envelope", "蓝边信封") },
  ];
  project.flags = [
    { id: "address", name: bi("Recipient identified", "查明收件人") },
    { id: "bell", name: bi("Ming’s bell story", "明讲过雾钟的故事") },
  ];
  const a = (id, en, zh, target, aliases, reply, rule = {}) => ({
    id,
    label: bi(en, zh),
    target,
    aliases: { en: aliases[0], zh: aliases[1] },
    reply: bi(...reply),
    ...rule,
  });
  const passage = (id, en, zh, prose, actions = [], ending = false) => ({
    ...newTextPassage(id),
    title: bi(en, zh),
    body: bi(...prose),
    ending,
    actions,
  });
  project.passages = [
    passage(
      "slipway",
      "The third step",
      "第三级台阶",
      [
        "When the tide drops below the third step, something blue catches on the ferry ring. An envelope. The postmark is thirty years old today. In the space for an address someone has written, “For the one who hears the bell.”\n\nThe disused sorting room still has its door propped open with a stone.",
        "潮水退到第三级台阶时，一只蓝边信封卡在旧渡口的铁环里。邮戳是三十年前的今天。收件人一栏只有五个字：给听钟的人。\n\n分拣室早已停用。门还开着，底下垫了一块石头。",
      ],
      [
        a(
          "take_letter",
          "Lift the envelope",
          "拾起信封",
          "slipway",
          [
            ["take envelope", "take letter", "pick up envelope"],
            ["拿信", "拿信封", "捡起信封"],
          ],
          [
            "Inside the fold of the flap you find a second instruction. “If she has gone, leave it where the water reaches.” The seal is unbroken.",
            "封口的折边里还有一行字：她要是走了，就把信放回潮水能够到的地方。封蜡完好。",
          ],
          { give: "letter", lacksItem: "letter" },
        ),
        a(
          "enter_room",
          "Enter the sorting room",
          "走进分拣室",
          "sorting",
          [
            ["enter sorting room", "go in", "enter"],
            ["进屋", "进分拣室", "去分拣室"],
          ],
          [],
        ),
      ],
    ),
    passage(
      "sorting",
      "The returned-mail shelf",
      "退件架",
      [
        "The room smells of flour paste. A delivery register lies under a saucer to keep its pages from curling. Someone pencilled two directions on the wall: uphill for the bell house, down the rails for the tide line.",
        "屋里还有浆糊的味道。一只茶碟压着投递簿，防止纸页卷起。墙上有人用铅笔画了两支箭：上坡去钟屋，顺铁轨下行到潮线。",
      ],
      [
        a(
          "read_register",
          "Read the delivery register",
          "查阅投递簿",
          "sorting",
          [
            ["read register", "read ledger", "look up address"],
            ["看投递簿", "查簿", "查地址"],
          ],
          [
            "A note in the margin reads, “Ming takes the night bell now, just like her mother. Letters for the bell go to Ming.” The ink has gone brown. The address hasn't changed.",
            "簿边一行小字：明替她母亲接了晚班。凡写听钟人收，一律送交明。墨水已褪成棕色，地址倒一直没变。",
          ],
          { set: "address" },
        ),
        a(
          "visit_bell",
          "Visit the bell house",
          "去钟屋",
          "bell_house",
          [
            ["visit bell house", "go uphill", "bell house"],
            ["上坡", "钟屋"],
          ],
          [],
        ),
        a(
          "visit_tide",
          "Walk to the tide line",
          "走到潮线",
          "tideline",
          [
            ["walk to tide line", "go to sea", "tide line"],
            ["去潮线", "海边"],
          ],
          [],
        ),
        a(
          "back_steps",
          "Return to the ferry steps",
          "回渡口台阶",
          "slipway",
          [
            ["return to steps", "go to steps"],
            ["回台阶", "回渡口"],
          ],
          [],
        ),
      ],
    ),
    passage(
      "bell_house",
      "A hand on the bell rope",
      "钟绳上的手",
      [
        "An old woman is wrapping red thread around the worn part of a bell rope. “Ming,” she says when you ask her name. “Leave room on the bench. My mother's letters always took up more space than you'd think.”",
        "一位老人正往磨毛的钟绳上缠红线。你问她怎么称呼，她说，叫我明吧。接着她把长凳上的剪刀挪开：“坐吧。我妈的信啊，看着薄，一放就是一大摊。”",
      ],
      [
        a(
          "ask_bell",
          "Ask about the fog bell",
          "问起雾钟",
          "bell_house",
          [
            ["ask about bell", "ask ming"],
            ["问雾钟", "问明"],
          ],
          [
            "“Two strokes meant the boat had made it in. One meant keep a light burning.” Ming rubs the red thread. “We didn't have a stroke for coming home late.”",
            "“两声是船进港了，一声是灯先别熄。”明捻了捻红线。“回来晚了该敲几声，我们一直没定。”",
          ],
          { set: "bell", lacksFlag: "bell" },
        ),
        a(
          "give_letter",
          "Give Ming the letter",
          "把信交给明",
          "homecoming",
          [
            ["give letter", "deliver letter", "give ming envelope"],
            ["交信", "把信给明", "递信"],
          ],
          [
            "You lay the envelope on the bare place beside her.",
            "你把信放在长凳腾出的那一小块空处。",
          ],
          { needsFlag: "address", needsItem: "letter", take: "letter" },
        ),
        a(
          "back_room",
          "Return to the sorting room",
          "回分拣室",
          "sorting",
          [
            ["return", "go back", "sorting room"],
            ["返回", "回去"],
          ],
          [],
        ),
      ],
    ),
    passage(
      "tideline",
      "Where the water reaches",
      "潮水够得着的地方",
      [
        "The ferry rails run out under the channel. Paper boats from the village school sit in the mud, each with a child's pebble for ballast. The first one has just begun to rock. The blue envelope would fit inside.",
        "渡船的旧铁轨一直伸进水道。滩泥里停着村小孩子们折的纸船，每只船都压了一颗石子。头一只刚刚晃动。蓝边信封恰好放得下。",
      ],
      [
        a(
          "release_letter",
          "Send the letter to sea",
          "把信送回海上",
          "drift",
          [
            ["send to sea", "release letter", "float letter"],
            ["放信", "把信放回海里", "寄往大海"],
          ],
          [
            "You exchange the pebble for the envelope. The paper hull settles level.",
            "你取出压舱的石子，换上信封。纸船平平地坐稳了。",
          ],
          { needsItem: "letter", take: "letter" },
        ),
        a(
          "back_room",
          "Return to the sorting room",
          "回分拣室",
          "sorting",
          [
            ["return", "go back", "sorting room"],
            ["返回", "回去"],
          ],
          [],
        ),
      ],
    ),
    passage(
      "homecoming",
      "Delivered by hand",
      "亲手投递",
      [
        "Ming opens the flap with her thumbnail. Out falls a pattern for mending a rope, the same stitch she has just taught her fingers to make. On the back: “You'll have to show me when I get home.”\n\nMing folds it into her apron. At dusk the harbor hears three strokes, with a long breath between the second and the third.",
        "明用拇指挑开封口。一张补绳结的图样落在膝上，针脚就和她刚才缠的一样。翻过来，背面写着：等我回家，你可要教我。\n\n明把纸折起来，塞进围裙。傍晚，港里传来三声钟响。第二声和第三声之间，隔着长长的一口气。",
      ],
      [],
      true,
    ),
    passage(
      "drift",
      "No return address",
      "没有回邮地址",
      [
        "The tide lifts the whole fleet at once. Your boat slips between two buoys and keeps going. From uphill comes a single stroke of the bell.\n\nYou stay until the blue edge is too small to point to. In the sorting room you turn the register to a clean page, then leave it clean.",
        "涨潮把整队纸船一齐托起。载信的那只从两座浮标之间穿过去，一路往外。坡上响了一声钟。\n\n你一直等到那点蓝色小得没法指给旁人看，才折回分拣室。你把投递簿翻到崭新的一页，一个字也没有写。",
      ],
      [],
      true,
    ),
  ];
  return project;
}
