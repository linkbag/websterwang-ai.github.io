import { createEncounterEngine } from "./encounter-core.js";

const text = (en, zh) => ({ en, zh });
const legalId = (id) =>
  typeof id === "string" &&
  /^[A-Za-z0-9_][A-Za-z0-9_-]{0,79}$/.test(id) &&
  !["constructor", "__proto__", "prototype"].includes(id);
export const encounterCopyKeys = [
  "hero",
  "creature",
  "chimeName",
  "shelterName",
  "intro",
  "win",
  "loss",
  "home",
];
export function createEncounterProject({ blank = false } = {}) {
  const e = {
    hero: text("Pip", "阿沫"),
    creature: text("Whelkin", "螺小满"),
    chimeName: text("Ring the shell chime", "摇响贝铃"),
    shelterName: text("Shelter behind the rocks", "躲到礁石后"),
    intro: text(
      "At low tide a little shellback has drifted into a strange pool. Remember the camp and call it home with your shell chime.",
      "潮水退去，一只背壳兽漂进了陌生的水潭。记住营地的位置，用贝铃把它唤回家。",
    ),
    win: text(
      "Whelkin answers with a note of its own. Together, make your way back to camp.",
      "螺小满也轻轻应了一声。带它一起回营地吧。",
    ),
    loss: text(
      "A wash of foam drowns out the last note. Catch your breath and try a different rhythm.",
      "泡沫盖过了最后一个音。歇口气，再换个节奏试试。",
    ),
    home: text(
      "Two sets of tracks lead to camp. Tonight the shell chime has a second voice.",
      "两行脚印一路通向营地。今夜的贝铃，有了应和的声音。",
    ),
    layout: [
      "#########",
      "#...,...#",
      "#.#.##..#",
      "#.,,,,..#",
      "#....~..#",
      "#########",
    ],
    start: { x: 1, y: 3 },
    checkpoint: { x: 3, y: 3 },
    opponent: { x: 7, y: 1 },
    stamina: 5,
    goal: 6,
    chime: 2,
    surge: 4,
    image: "",
    audio: "",
  };
  if (blank)
    Object.assign(e, {
      hero: text("Traveler", "旅人"),
      creature: text("Pool friend", "水潭伙伴"),
      chimeName: text("Call", "呼唤"),
      shelterName: text("Shelter", "躲浪"),
      intro: text(
        "Follow the shore to meet your first creature.",
        "沿岸出发，寻找你的第一位伙伴。",
      ),
      win: text("Your new friend follows you.", "新伙伴跟上了你。"),
      loss: text("Rest and try again.", "休息后再来一次。"),
      home: text("You returned together.", "你们一起回来了。"),
      layout: ["######", "#....#", "#....#", "######"],
      start: { x: 1, y: 2 },
      checkpoint: { x: 2, y: 2 },
      opponent: { x: 4, y: 1 },
    });
  return {
    version: 6,
    kind: "creature-encounter",
    id: blank
      ? "encounter_" +
        (globalThis.crypto?.randomUUID?.() ||
          Math.random().toString(36).slice(2))
      : "tidepool_trial",
    title: blank
      ? text("Untitled encounter", "未命名相遇")
      : text("Tidepool Trial", "潮池试炼"),
    credits: blank
      ? text("", "")
      : text(
          "Original story, rules and trail by Lantern Studio contributors.",
          "原创故事、规则及地图：Lantern Studio 贡献者。",
        ),
    materials: [],
    encounter: e,
  };
}

export function validateEncounter(p, lang = "en") {
  const errors = [],
    warnings = [],
    t = (en, zh) => (lang === "zh" ? zh : en);
  const fail = (en, zh) => errors.push(t(en, zh));
  const field = {
    title: "游戏标题",
    credits: "制作名单",
    hero: "旅人名字",
    creature: "伙伴名字",
    chimeName: "呼唤行动名称",
    shelterName: "躲浪行动名称",
    intro: "开场日志",
    win: "成功文本",
    loss: "失败文本",
    home: "回营结语",
    stamina: "初始体力",
    goal: "所需信任",
    chime: "每次呼唤增加信任",
    surge: "浪涌消耗体力",
    start: "起点",
    checkpoint: "营地",
    opponent: "伙伴",
    image: "伙伴插画",
    audio: "相遇铃声",
  };
  if (
    !p ||
    p.version !== 6 ||
    p.kind !== "creature-encounter" ||
    !legalId(p.id)
  ) {
    fail(
      "Expected a v6 creature encounter with a valid ID.",
      "需要带有效标识的第 6 版伙伴相遇工程。",
    );
    return { errors, warnings };
  }
  function localized(value, key, max, optional = false) {
    if (
      !value ||
      typeof value !== "object" ||
      Array.isArray(value) ||
      !["en", "zh"].some((k) => Object.hasOwn(value, k)) ||
      ["en", "zh"].some(
        (k) =>
          Object.hasOwn(value, k) &&
          (typeof value[k] !== "string" || value[k].length > max),
      )
    )
      fail(
        `${key} needs English or Chinese text, up to ${max} characters per language.`,
        `${field[key]} 需要英文或中文文本，每种语言最多 ${max} 字符。`,
      );
    else if (!optional && !value.en?.trim() && !value.zh?.trim())
      warnings.push(t(`Add text for ${key}.`, `请填写${field[key]}。`));
  }
  localized(p.title, "title", 300);
  if (p.credits !== undefined) localized(p.credits, "credits", 30000, true);
  const e = p.encounter;
  if (!e || typeof e !== "object" || Array.isArray(e)) {
    fail("Encounter settings are missing.", "缺少相遇设置。");
    return { errors, warnings };
  }
  for (const key of encounterCopyKeys)
    localized(
      e[key],
      key,
      ["intro", "win", "loss", "home"].includes(key) ? 3000 : 150,
    );
  for (const key of ["stamina", "goal", "chime", "surge"])
    if (!Number.isInteger(e[key]) || e[key] < 1 || e[key] > 25)
      fail(
        `${key} must be a whole number from 1 to 25.`,
        `${field[key]}必须是 1 至 25 的整数。`,
      );
  const map = e.layout,
    width =
      Array.isArray(map) && typeof map[0] === "string" ? map[0].length : 0;
  const validMap =
    Array.isArray(map) &&
    map.length >= 4 &&
    map.length <= 10 &&
    width >= 4 &&
    width <= 14 &&
    map.every(
      (row) =>
        typeof row === "string" &&
        row.length === width &&
        /^[.,#~]+$/.test(row),
    );
  if (!validMap)
    fail(
      "Draw a rectangular trail 4–14 tiles wide and 4–10 high using ground, path, rock or water.",
      "地图须为宽 4 至 14、高 4 至 10 的矩形，仅使用地面、小径、石头和水面。",
    );
  const used = new Set();
  for (const key of ["start", "checkpoint", "opponent"]) {
    const pos = e[key];
    if (
      !pos ||
      !Number.isInteger(pos.x) ||
      !Number.isInteger(pos.y) ||
      !validMap ||
      ![".", ","].includes(map[pos.y]?.[pos.x])
    )
      fail(
        `Place ${key} on walkable ground.`,
        `请把${field[key]}放在可以行走的地面上。`,
      );
    else {
      const id = pos.x + "," + pos.y;
      if (used.has(id))
        fail(
          "Give the start, camp and creature separate cells.",
          "起点、营地和伙伴必须位于不同格子。",
        );
      used.add(id);
    }
  }
  for (const [key, kind] of [
    ["image", "image"],
    ["audio", "audio"],
  ])
    if (
      e[key] !== undefined &&
      e[key] !== "" &&
      (!legalId(e[key]) ||
        !Array.isArray(p.materials) ||
        !p.materials.some((m) => m?.id === e[key] && m.kind === kind))
    )
      fail(
        `Choose an existing ${kind} material for ${key}.`,
        `请为${field[key]}选择素材库中已有的对应素材。`,
      );
  if (!errors.length) {
    const engine = createEncounterEngine(),
      cells = new Set([e.start.x + "," + e.start.y]);
    for (const cell of cells)
      for (const [dx, dy] of Object.values(engine.directions)) {
        const [x, y] = cell.split(",").map(Number);
        if (engine.walkable(map, x + dx, y + dy))
          cells.add(x + dx + "," + (y + dy));
      }
    for (const key of ["checkpoint", "opponent"])
      if (!cells.has(e[key].x + "," + e[key].y))
        warnings.push(
          t(
            `The trail to ${key} is blocked.`,
            `通往${field[key]}的路被堵住了。`,
          ),
        );
  }
  return { errors, warnings };
}

export function encounterOutcomes(e) {
  const engine = createEncounterEngine(),
    initial = { ...engine.start(e), ...e.opponent, phase: "encounter" };
  const queue = [{ state: initial, path: [] }],
    seen = new Set(),
    result = { won: null, lost: null };
  for (let i = 0; i < queue.length; i++) {
    const { state, path } = queue[i],
      key = [state.phase, state.stamina, state.trust, state.tide].join("/");
    if (seen.has(key)) continue;
    seen.add(key);
    if (state.phase !== "encounter") {
      result[state.phase] ??= path;
      if (result.won && result.lost) break;
      continue;
    }
    for (const action of ["chime", "shelter"])
      queue.push({
        state: engine.act(e, state, action),
        path: [...path, action],
      });
  }
  return result;
}
