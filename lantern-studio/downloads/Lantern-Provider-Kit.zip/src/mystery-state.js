// Each action checks the current clues before it changes a flag or reaches an ending.
export function mysteryStep(p, state, hotspotId, actionId) {
  const hotspot = p.hotspots.find((h) => h.id === hotspotId);
  const action = hotspot?.actions.find((a) => a.id === actionId);
  if (!action || state.ending) return state;
  const blocked =
    action.requires &&
    state.flags.includes(action.requires) !== (action.requiresState === "set");
  const last = { hotspotId, actionId, blocked: Boolean(blocked) };
  if (blocked) return { ...state, last };
  const flags = new Set(state.flags);
  if (action.effect) {
    if (action.effectState === "set") flags.add(action.effect);
    else flags.delete(action.effect);
  }
  return { flags: [...flags].sort(), ending: action.ending, last };
}
