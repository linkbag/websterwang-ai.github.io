import { isTileProject, promoteTileProjectVersion, validateTileProject } from './tile-core.js';
import { validWebCode } from './web-code.js';
import { validateMystery } from './mystery-model.js';
import { validateEncounter } from './encounter-model.js';
import { validateRpg } from './rpg-model.js';
import { validateTextAdventure } from './text-model.js';
import { validateFilm } from './film-model.js';
import { validateProjectMaterials } from './material-model.js';

// Compact media stays inside the portable project. The byte limits apply to decoded media.
export const MAX_ASSET_BYTES = 16 * 1024 * 1024;
export const MAX_MEDIA_BYTES = 64 * 1024 * 1024;
export const CHOICE_RULES = ['requires', 'unless', 'sets', 'clears'];
const MAX_MESSAGES = 60;
const MAX_GRAPH_STATES = 8192;
const idPattern = /^[a-zA-Z0-9_][a-zA-Z0-9_-]{0,79}$/;
const unsafeIds = new Set(['__proto__', 'prototype', 'constructor']);
const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const safeId = value => typeof value === 'string' && idPattern.test(value) && !unsafeIds.has(value);
const flagPattern = /^[\p{L}\p{N}_][\p{L}\p{M}\p{N}_-]{0,79}$/u;
const reservedFlags = new Set([...Object.getOwnPropertyNames(Object.prototype), 'prototype']);
const hasUnicodeFlag = project => Array.isArray(project.flags) && project.flags.some(flag => typeof flag === 'string' && /[^\x00-\x7f]/.test(flag));
const imageFile = /^art\/[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}\.webp$/;
const soundFile = /^sound\/[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}\.wav$/;
const imagePrefix = /^data:image\/(?:png|jpeg|webp|gif|avif);base64,/i;
const audioPrefix = /^data:audio\/(?:mpeg|mp3|wav|x-wav|wave|ogg|webm|mp4|aac|flac|x-m4a);base64,/i;

function mediaBytes(asset) {
  const { kind, src } = asset;
  if (typeof src !== 'string' || src.length > Math.ceil(MAX_ASSET_BYTES / 3) * 4 + 64) return -1;
  if (kind !== 'image' && kind !== 'audio') return -1;
  if ((kind === 'image' ? imageFile : soundFile).test(src)) return 0;
  const prefix = src.match(kind === 'image' ? imagePrefix : audioPrefix);
  if (!prefix) return -1;
  const body = src.slice(prefix[0].length);
  if (!body.length || body.length % 4 !== 0 || !/^[a-zA-Z0-9+/]+={0,2}$/.test(body)) return -1;
  const size = body.length / 4 * 3 - (body.endsWith('==') ? 2 : body.endsWith('=') ? 1 : 0);
  return size <= MAX_ASSET_BYTES ? size : -1;
}

function usesInventoryOrCredits(project) {
  return (Array.isArray(project.inventory) && project.inventory.length > 0) ||
    ['en', 'zh'].some(key => typeof project.credits?.[key] === 'string' && project.credits[key].trim());
}

/** Raise the format only after a visual edit starts using a newer feature. Retain the previous format otherwise. */
export function promoteProjectVersion(project) {
  if (isTileProject(project)) return promoteTileProjectVersion(project);
  if (![1, 2, 3].includes(project.version)) return project;
  if (usesInventoryOrCredits(project) || hasUnicodeFlag(project)) project.version = 3;
  else if (project.version === 1 && Array.isArray(project.scenes) &&
    project.scenes.some(scene => Array.isArray(scene?.choices) && scene.choices.some(c => c?.unless || c?.clears))) project.version = 2;
  return project;
}

/** Check structure, references and reachable graph states in any supported portable project. */
export function validateProject(project, locale = 'en') {
  if (!validWebCode(project?.webCode)) return { errors: [locale === "zh" ? "网页扩展只接受 CSS 和 JavaScript，每项上限为 100,000 个字符。" : "Web extensions accept CSS and JavaScript strings up to 100,000 characters each."], warnings: [] };
  const mediaErrors = validateProjectMaterials(project, locale);
  if (mediaErrors.length) return {errors:mediaErrors,warnings:[]};
  if (project?.kind === 'point-mystery') return validateMystery(project, locale);
  if (project?.kind === 'creature-encounter') return validateEncounter(project, locale);
  if (project?.kind === 'quest-rpg') return validateRpg(project, locale);
  if (project?.kind === 'text-adventure') return validateTextAdventure(project, locale);
  if (project?.kind === 'interactive-film') return validateFilm(project, locale);
  if (project?.version === 4 || project?.version === 5 || isTileProject(project)) return validateTileProject(project, locale);
  const errors = [];
  const warnings = [];
  const message = (en, zh) => locale === 'zh' ? zh : en;
  function add(list, en, zh) {
    if (list.length < MAX_MESSAGES) list.push(message(en, zh));
    else if (list.length === MAX_MESSAGES) list.push(message('Additional issues omitted.', '还有其他问题未显示。'));
  }
  const fail = (en, zh) => add(errors, en, zh);
  const warn = (en, zh) => add(warnings, en, zh);
  function text(value, path, limit, allowBlank = false) {
    if (!record(value) || (!['en', 'zh'].some(key => Object.hasOwn(value, key)) && !(allowBlank && Object.keys(value).length === 0)) ||
      ['en', 'zh'].some(key => Object.hasOwn(value, key) && (typeof value[key] !== 'string' || value[key].length > limit))) {
      fail(`${path} needs en or zh text (up to ${limit} characters each).`, `${path} 需要 en 或 zh 文本（每项最多 ${limit} 个字符）。`);
    } else if (!allowBlank && !value.en?.trim() && !value.zh?.trim()) {
      warn(`${path} is blank in both languages.`, `${path} 的中英文都是空白。`);
    }
  }
  function list(value, path, max) {
    if (!Array.isArray(value) || value.length > max) {
      fail(`${path} needs a list with at most ${max} entries.`, `${path} 需要一个列表，最多 ${max} 项。`);
      return [];
    }
    return value;
  }
  function indexed(value, path, max) {
    const items = new Map();
    for (const [i, item] of list(value, path, max).entries()) {
      if (!record(item) || !safeId(item.id) || items.has(item.id)) {
        fail(`${path}[${i}] needs a unique, safe ID (letters, numbers, underscore or hyphen).`, `${path}[${i}] 需要唯一的有效标识（字母、数字、下划线或连字符）。`);
      } else items.set(item.id, item);
    }
    return items;
  }
  function ref(key, collection, path, optional = false) {
    if ((optional && key === '') || collection.has(key)) return;
    fail(`${path} refers to a missing or invalid ID.`, `${path} 引用了不存在或无效的标识。`);
  }
  if (!record(project) || ![1, 2, 3].includes(project.version)) {
    fail('Expected a Lantern project with version 1, 2 or 3.', '需要版本为 1、2 或 3 的 Lantern 项目。');
    return { errors, warnings };
  }
  if (!safeId(project.id)) fail('Project ID is invalid.', '项目标识无效。');
  text(project.title, 'title', 300);
  if (project.novelLayout !== undefined && !['dialogue', 'page'].includes(project.novelLayout)) fail('Choose a dialogue or page reading layout.', '请选择单句对话或整页阅读排版。');
  const characters = indexed(project.characters, 'characters', 1000);
  const assets = indexed(project.assets, 'assets', 1000);
  const scenes = indexed(project.scenes, 'scenes', 1000);
  const flags = new Set();
  const spellings = new Set();
  for (const [index, flag] of list(project.flags, 'flags', 128).entries()) {
    if (typeof flag !== 'string' || !flagPattern.test(flag) || reservedFlags.has(flag)) {
      fail(`Flag ${index + 1} needs 1–80 letters, numbers, underscores or hyphens. Combining marks can follow a letter. Spaces, code syntax and reserved names are unavailable.`,
        `第 ${index + 1} 个故事标记需要 1 到 80 个字符，可用中文等文字、数字、下划线或连字符，文字后可加组合附标。请去掉空格、代码符号或保留名称。`);
      continue;
    }
    const spelling = flag.normalize('NFC');
    if (spellings.has(spelling)) fail(`Duplicate flag “${spelling}”. Give each flag a distinct name.`, `故事标记“${spelling}”重名了，请使用不同名称。`);
    spellings.add(spelling);
    flags.add(flag);
  }
  if (project.version < 3 && hasUnicodeFlag(project)) fail('Multilingual flag names require project version 3.', '多语言故事标记需要将工程版本设为 3。');
  if (project.version < 3 && usesInventoryOrCredits(project)) {
    fail('Inventory and game credits require project version 3.', '物品栏和游戏署名需要将工程版本设为 3。');
  }
  if (project.credits !== undefined) text(project.credits, 'credits', 30000, true);
  if (project.inventory !== undefined) {
    for (const item of indexed(project.inventory, 'inventory', 256).values()) {
      const path = `inventory.${item.id}`;
      text(item.name, `${path}.name`, 300);
      text(item.description, `${path}.description`, 30000, true);
      ref(item.flag, flags, `${path}.flag`);
      if (!['set', 'unset'].includes(item.when)) fail(`${path}.when must be set or unset.`, `${path}.when 必须为 set 或 unset。`);
    }
  }
  if (!scenes.size) fail('Add at least one scene.', '请至少添加一个场景。');
  ref(project.start, scenes, 'start');
  for (const character of characters.values()) {
    text(character.name, `characters.${character.id}.name`, 300);
    if (character.portrait !== undefined && character.portrait !== '' && assets.get(character.portrait)?.kind !== 'image') {
      fail(`characters.${character.id}.portrait needs an image asset.`, `characters.${character.id}.portrait 需要图像素材。`);
    }
    if (typeof character.color !== 'string' || !/^#[a-f\d]{6}$/i.test(character.color)) {
      fail(`Character ${character.id} needs a six-digit hex color.`, `角色 ${character.id} 需要六位十六进制颜色值。`);
    }
  }
  let totalBytes = 0;
  for (const asset of assets.values()) {
    const path = `assets.${asset.id}`;
    text(asset.name, `${path}.name`, 300);
    const size = mediaBytes(asset);
    if (size < 0) fail(`${path} needs supported embedded media up to 16 MiB or a built-in file.`, `${path} 需要支持的内嵌媒体（最多 16 MiB）或内置文件。`);
    else totalBytes += size;
    if (typeof asset.credit !== 'string' || asset.credit.length > 2000) {
      fail(`${path}.credit must be text up to 2000 characters.`, `${path}.credit 必须为文本，最多 2000 个字符。`);
    }
  }
  if (totalBytes > MAX_MEDIA_BYTES) fail('Imported media exceeds 64 MiB in total.', '导入媒体的总大小超过 64 MiB。');
  for (const scene of scenes.values()) {
    const path = `scenes.${scene.id}`;
    text(scene.title, `${path}.title`, 300);
    if (typeof scene.ending !== 'boolean') fail(`${path}.ending must be true or false.`, `${path}.ending 必须为 true 或 false。`);
    for (const [key, kind] of [['background', 'image'], ['audio', 'audio']]) {
      if (scene[key] !== '' && assets.get(scene[key])?.kind !== kind) {
        fail(`${path}.${key} needs a matching ${kind} asset.`, `${path}.${key} 需要对应类型的媒体素材。`);
      }
    }
    ref(scene.next, scenes, `${path}.next`, true);
    const lines = indexed(scene.lines, `${path}.lines`, 1000);
    const choices = indexed(scene.choices, `${path}.choices`, 100);
    for (const line of lines.values()) {
      const linePath = `${path}.lines.${line.id}`;
      ref(line.speaker, characters, `${linePath}.speaker`, true);
      if (line.voice !== undefined && line.voice !== '' && assets.get(line.voice)?.kind !== 'audio') {
        fail(`${linePath}.voice needs an audio asset.`, `${linePath}.voice 需要音频素材。`);
      }
      text(line.text, `${linePath}.text`, 30000);
    }
    for (const choice of choices.values()) {
      const choicePath = `${path}.choices.${choice.id}`;
      text(choice.text, `${choicePath}.text`, 1000);
      ref(choice.target, scenes, `${choicePath}.target`);
      for (const key of CHOICE_RULES) {
        if (choice[key] !== undefined) ref(choice[key], flags, `${choicePath}.${key}`, true);
      }
      if (project.version === 1 && (choice.unless || choice.clears)) {
        fail(`${choicePath} uses a reversible flag. Set the project version to 2.`, `${choicePath} 使用了可逆标记，请将项目版本设为 2。`);
      }
      if (choice.requires && choice.requires === choice.unless) {
        fail(`${choicePath} requires the same flag to be both on and off.`, `${choicePath} 同时要求同一标记开启和关闭。`);
      }
      if (choice.sets && choice.sets === choice.clears) {
        fail(`${choicePath} sets and clears the same flag. Choose one effect.`, `${choicePath} 同时设置和清除同一标记。请保留一种效果。`);
      }
    }
    if (scene.ending && (choices.size || scene.next)) warn(`${scene.id} has outgoing links on an ending.`, `${scene.id} 是结局，但仍有后续连接。`);
  }
  if (!errors.length) inspectRoutes(project, scenes, warn);
  return { errors, warnings };
}

function inspectRoutes(project, scenes, warn) {
  const flagBits = new Map(project.flags.map((flag, i) => [flag, 1n << BigInt(i)]));
  const states = [[project.start, 0n]];
  const known = new Set([`${project.start}:0`]);
  const visited = new Set();
  const stuck = new Set();
  const incoming = new Map();
  const endings = [];
  function enqueue(id, bits, previous) {
    const key = `${id}:${bits}`;
    if (!incoming.has(key)) incoming.set(key, new Set());
    incoming.get(key).add(previous);
    if (!known.has(key) && states.length <= MAX_GRAPH_STATES) {
      known.add(key);
      states.push([id, bits]);
    }
  }
  for (let i = 0; i < states.length && states.length <= MAX_GRAPH_STATES; i++) {
    const [id, bits] = states[i];
    const key = `${id}:${bits}`;
    const scene = scenes.get(id);
    visited.add(id);
    if (scene.ending) {
      endings.push(key);
      continue;
    }
    const options = scene.choices.filter(choice =>
      (!choice.requires || (bits & flagBits.get(choice.requires)) !== 0n) &&
      (!choice.unless || (bits & flagBits.get(choice.unless)) === 0n));
    for (const choice of options) {
      const nextBits = (bits | (flagBits.get(choice.sets) ?? 0n)) & ~(flagBits.get(choice.clears) ?? 0n);
      enqueue(choice.target, nextBits, key);
    }
    if (!options.length && scene.next) enqueue(scene.next, bits, key);
    else if (!options.length) stuck.add(id);
  }
  for (const id of stuck) warn(`The route can stop at ${id} without an ending. Add an available choice, a next scene, or an ending.`, `在 ${id} 剧情可能意外中断。请添加可用选项、下一场景或结局。`);
  if (states.length > MAX_GRAPH_STATES) {
    warn('Route analysis reached its limit. Playtest the remaining flag combinations.', '路线分析达到上限。请试玩其余状态组合。');
    return;
  }
  for (const id of scenes.keys()) {
    if (!visited.has(id)) warn(`Scene ${id} cannot be reached from the start.`, `从开场无法到达场景 ${id}。`);
  }
  if (!endings.length) {
    warn('No ending can be reached from the start.', '从开场无法到达任何结局。');
    return;
  }
  const canFinish = new Set(endings);
  for (let i = 0; i < endings.length; i++) {
    for (const from of incoming.get(endings[i]) ?? []) {
      if (!canFinish.has(from)) { canFinish.add(from); endings.push(from); }
    }
  }
  const trapped = new Set(states.filter(([id, bits]) => !canFinish.has(`${id}:${bits}`)).map(([id]) => id));
  for (const id of trapped) {
    if (!stuck.has(id)) warn(`Some routes through ${id} cannot reach any ending.`, `经过 ${id} 的某些路线无法到达任何结局。`);
  }
}
