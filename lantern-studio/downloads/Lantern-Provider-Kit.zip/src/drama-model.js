import { rainRegister } from "./drama-sample.js";

export const dramaText = (en = "", zh = "") => ({ en, zh });
const t = dramaText;
export function dramaId(prefix = "drama") {
  const stem = typeof prefix === "string" && /^[A-Za-z0-9_][A-Za-z0-9_-]{0,46}$/.test(prefix) ? prefix : "drama";
  return stem + "_" + crypto.randomUUID().replaceAll("-", "");
}
const safeId = (id) => typeof id === "string" && /^[A-Za-z0-9_][A-Za-z0-9_-]{0,79}$/.test(id) && !["__proto__", "prototype", "constructor"].includes(id);
const record = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const list = (v, max) => Array.isArray(v) && v.length <= max;
const taskTypes = ["collect", "inspect", "order", "match", "hold"];
const local = (v, lang) => v?.[lang]?.trim() || v?.[lang === "zh" ? "en" : "zh"]?.trim() || "";

function validSourceUrl(value) {
  if (value === "") return true;
  if (typeof value !== "string" || value.length > 2048 || !/^https?:\/\//i.test(value) || /[\s\\\u0000-\u001f\u007f]/u.test(value)) return false;
  try {
    const url = new URL(value);
    return Boolean(url.hostname) && !url.username && !url.password;
  } catch { return false; }
}

export function newDramaAct() {
  return { id: dramaId("act"), title: t("New act", "新一幕"), role: t(), place: t() };
}
export function newDramaBeat(actId) {
  return {
    id: dramaId("beat"), act: actId, title: t("New beat", "新一场"), speaker: "",
    body: t(), image: "", voice: "", task: null, choices: [], ending: false,
  };
}
export function newDramaTask(type = "collect") {
  if (!taskTypes.includes(type)) throw new RangeError("Unknown stage challenge type.");
  const prompts = {
    collect: t("Gather every object.", "收齐每件物品。"),
    inspect: t("Examine every clue.", "逐一查看线索。"),
    order: t("Put the cues in their correct order.", "按先后顺序排列提示。"),
    match: t("Match each item to its group.", "为每一项选出对应的分组。"),
    hold: t("Hold the cue or confirm it in two steps.", "按住提示，或分两步确认。"),
  };
  const targets = type === "match" ? [
    { id: dramaId("group"), label: t("First group", "第一组") },
    { id: dramaId("group"), label: t("Second group", "第二组") },
  ] : [];
  const items = type === "hold" ? [] : [t("First cue", "第一条提示"), t("Second cue", "第二条提示")].map((label, i) => ({
    id: dramaId("cue"), label, detail: t(), target: targets[i]?.id || "", voice: "",
  }));
  return { type, prompt: prompts[type], success: t("The cue is complete.", "这一环节已完成。"), items, targets, holdMs: 1000 };
}
export function createDrama({ blank = false, media = [] } = {}) {
  if (!blank) return rainRegister(media);
  const act = { ...newDramaAct(), id: "act_one", title: t("First act", "第一幕") };
  const opening = { ...newDramaBeat(act.id), id: "opening", title: t("In the wings", "候场"),
    body: t("The stage is yours. Someone in the front row looks up.", "轮到你上场了。第一排有人抬起头。"),
    choices: [{ id: "step_out", label: t("Take the stage", "走上舞台"), reply: t(), to: "curtain_call", needs: [], unless: [], grant: [], take: [] }] };
  const ending = { ...newDramaBeat(act.id), id: "curtain_call", title: t("Curtain call", "谢幕"), ending: true,
    body: t("The curtain falls. Who will you bring on stage next?", "幕布落下。下一次，你想让谁登场？") };
  return {
    version: 7, kind: "stage-drama", id: dramaId("drama"), title: t("Untitled stage drama", "未命名短剧"),
    credits: t(), start: opening.id, materials: [], acts: [act], cast: [], tokens: [], beats: [opening, ending], epilogues: [],
  };
}

export function validateDrama(p, lang = "en") {
  const msg = (en, zh) => lang === "zh" ? zh : en;
  const errors = [], warnings = [];
  function emit(lines, en, zh) {
    if (lines.length < 60) lines.push(msg(en, zh));
    else if (lines.length === 60) lines.push(msg("Additional issues omitted.", "还有其他问题未显示。"));
  }
  const fail = (en, zh) => emit(errors, en, zh);
  const warn = (en, zh) => emit(warnings, en, zh);
  let textSize = 0;
  function text(v, max, name, visible = false) {
    if (!record(v) || !["en", "zh"].every((k) => typeof v[k] === "string" && v[k].length <= max)) {
      fail(`${name} needs English and Chinese text fields of up to ${max} characters each.`, `${name} 需要中、英两个文本字段，每个最多 ${max} 字。`);
      return;
    }
    // A scoped provider context substitutes this exact fixed pair for unrelated prose,
    // including empty fields. It contains none of the author's manuscript.
    if (v.en !== "[withheld]" || v.zh !== "［未分享］") textSize += v.en.length + v.zh.length;
    const en = !!v.en.trim(), zh = !!v.zh.trim();
    if (visible && !en && !zh) warn("Add visible text to " + name + ".", "请填写可见文字：" + name + "。");
    else if (en !== zh) warn("Translation falls back to the other language: " + name, "此处将显示另一种语言：" + name);
  }
  function rows(value, max, name, min = 0) {
    if (!list(value, max) || value.length < min) {
      fail(`${name} must contain ${min}–${max} entries.`, `${name} 应有 ${min} 至 ${max} 项。`);
      return [];
    }
    const ids = new Set(), good = [];
    for (const row of value) {
      if (!record(row) || !safeId(row.id) || ids.has(row.id)) {
        fail("Invalid or duplicate ID in " + name + ".", name + " 中有无效或重复的标识。");
        continue;
      }
      ids.add(row.id);
      good.push(row);
    }
    return good;
  }
  if (!record(p) || p.kind !== "stage-drama" || p.version !== 7 || !safeId(p.id)) {
    fail("Invalid stage drama identity or version.", "短剧标识或版本无效。");
    return { errors, warnings };
  }
  text(p.title, 300, msg("Game title", "剧名"), true);
  text(p.credits, 30000, msg("Credits", "署名"));
  const acts = rows(p.acts, 32, msg("Acts", "幕"), 1);
  const cast = rows(p.cast, 64, msg("Cast", "角色"));
  const tokens = rows(p.tokens, 48, msg("Tokens", "信物"));
  const beats = rows(p.beats, 192, msg("Beats", "场"), 1);
  const epilogues = rows(p.epilogues, 96, msg("Epilogues", "尾声"));
  const materials = rows(p.materials, 256, msg("Materials", "素材"));
  const ids = (items) => new Set(items.map((i) => i.id));
  const actIds = ids(acts), castIds = ids(cast), tokenIds = ids(tokens), beatIds = ids(beats);
  const kinds = new Map(materials.map((m) => [m.id, m.kind]));
  for (const m of materials) if (!["image", "audio", "video", "text"].includes(m.kind))
    fail("Unknown material kind: " + m.id, "素材类型无效：" + m.id);
  function mediaRef(id, kind, name) {
    if (id !== "" && (!safeId(id) || kinds.get(id) !== kind))
      fail("Select an existing " + kind + " material for " + name + ".", "请为 " + name + " 选择已有的" + (kind === "image" ? "图片" : "音频") + "素材。");
  }
  function tokenList(v, name) {
    if (!list(v, 48) || !Array.from(v).every((id) => tokenIds.has(id)) || new Set(v).size !== v.length) {
      fail("Use distinct existing tokens in " + name + ".", name + " 只能引用已有信物，且不能重复。");
      return [];
    }
    return v;
  }
  function pair(a, b, name) {
    const first = tokenList(a, name), second = tokenList(b, name);
    if (first.some((id) => second.includes(id)))
      fail("Contradictory token rules in " + name + ".", name + " 的信物规则互相矛盾。");
  }
  function optionalText(owner, key, max, name) {
    if (owner[key] !== undefined) text(owner[key], max, name + " / " + key);
  }
  function variants(value, name, type) {
    if (value === undefined) return;
    for (const v of rows(value, type === "scene" || type === "reply" ? 64 : 96, name)) {
      const label = name + " / " + v.id;
      pair(v.needs, v.unless, label);
      if (type === "scene") {
        if (v.body === undefined && v.direction === undefined) fail("Set a line or direction in " + label, "请填写变体台词或舞台提示：" + label);
        optionalText(v, "body", 30000, label);
        optionalText(v, "direction", 30000, label);
      } else text(v.body, type === "reply" ? 8000 : 30000, label);
    }
  }
  if (p.cover !== undefined) mediaRef(p.cover, "image", msg("Cover", "封面"));
  if (p.framing !== undefined) {
    const f = p.framing, heading = msg("Production framing", "剧目介绍与谢幕");
    if (!record(f)) fail("Production framing must be an object.", "剧目介绍与谢幕设置应为对象。");
    else {
      if (f.theme !== undefined && !["paper", "lacquer", "midnight"].includes(f.theme)) fail("Choose paper, lacquer or midnight for the theatre theme.", "剧场主题请选择纸页、朱漆或午夜。");
      if (f.chimes !== undefined && typeof f.chimes !== "boolean") fail("The theatre cues setting must be true or false.", "舞台音效开关应为布尔值。");
      optionalText(f, "tagline", 300, heading);
      optionalText(f, "intro", 30000, heading);
      optionalText(f, "endingLead", 30000, heading);
      variants(f.endingTitles, msg("Ending titles", "结局标题"), "ending");
      variants(f.postscript, msg("Postscripts", "尾声附记"), "postscript");
      if (f.sources !== undefined) for (const s of rows(f.sources, 96, msg("Sources", "资料来源"))) {
        text(s.title, 300, s.id, true);
        text(s.note, 30000, s.id + " / " + msg("source note", "来源说明"));
        if (!validSourceUrl(s.url)) fail("Use a complete HTTP or HTTPS source URL without credentials: " + s.id, "请填写完整、不含登录信息的 HTTP 或 HTTPS 来源网址：" + s.id);
      }
    }
  }
  function task(value, name) {
    if (value === null) return;
    if (!record(value) || !taskTypes.includes(value.type)) {
      fail("Choose a supported challenge in " + name + ".", "请为 " + name + " 选择支持的互动类型。");
      return;
    }
    text(value.prompt, 2000, name + " / " + msg("challenge prompt", "任务提示"), true);
    text(value.success, 2000, name + " / " + msg("completion", "完成反馈"));
    optionalText(value, "holdLabel", 300, name);
    if (value.releaseToFinish !== undefined && typeof value.releaseToFinish !== "boolean")
      fail("The release-to-finish setting must be true or false: " + name, "松开后完成设置应为布尔值：" + name);
    if (!Number.isInteger(value.holdMs) || value.holdMs < 250 || value.holdMs > 10000)
      fail("Set the hold duration to 250–10000 ms in " + name + ".", name + " 的按住时长应为 250 至 10000 毫秒。");
    const targets = rows(value.targets, 32, name + " / " + msg("groups", "分组"), value.type === "match" ? 1 : 0);
    const required = value.type === "order" ? 2 : value.type === "hold" ? 0 : 1;
    const items = rows(value.items, 32, name + " / " + msg("challenge items", "互动项目"), required);
    const groups = ids(targets);
    for (const target of targets) text(target.label, 300, name + " / " + target.id, true);
    for (const item of items) {
      const location = name + " / " + item.id;
      text(item.label, 300, location, true);
      text(item.detail, 8000, location + " / " + msg("transcript", "文字说明"));
      mediaRef(item.voice, "audio", location);
      if (item.image !== undefined) mediaRef(item.image, "image", location);
      if (typeof item.target !== "string" || (value.type === "match" ? !groups.has(item.target) : item.target !== "" && !safeId(item.target)))
        fail("Invalid challenge group for " + location + ".", location + " 的互动分组无效。");
    }
  }
  if (!beatIds.has(p.start)) fail("Choose an existing opening beat.", "请选择已有的开场。");
  for (const a of acts) {
    text(a.title, 300, a.id, true);
    text(a.role, 300, a.id + " / " + msg("role", "扮演身份"));
    text(a.place, 300, a.id + " / " + msg("setting", "地点"));
    optionalText(a, "short", 300, a.id);
    optionalText(a, "date", 300, a.id);
    optionalText(a, "intro", 30000, a.id);
    if (a.image !== undefined) mediaRef(a.image, "image", a.id);
    if (!beats.some((b) => b.act === a.id)) warn("This act has no beats: " + a.id, "这幕还没有场：" + a.id);
  }
  for (const c of cast) {
    text(c.name, 300, c.id, true);
    text(c.bio, 30000, c.id + " / " + msg("biography", "小传"));
    mediaRef(c.portrait, "image", c.id);
    optionalText(c, "role", 300, c.id);
    optionalText(c, "inspiration", 8000, c.id);
    optionalText(c, "mark", 300, c.id);
    if (c.hidden !== undefined && typeof c.hidden !== "boolean") fail("Set cast visibility to true or false: " + c.id, "人物隐藏设置应为布尔值：" + c.id);
  }
  for (const token of tokens) {
    text(token.name, 300, token.id, true);
    if (token.hidden !== undefined && typeof token.hidden !== "boolean") fail("Set token visibility to true or false: " + token.id, "信物隐藏设置应为布尔值：" + token.id);
  }
  for (const b of beats) {
    text(b.title, 300, b.id, true);
    text(b.body, 30000, b.id + " / " + msg("script", "正文"), true);
    optionalText(b, "direction", 30000, b.id);
    optionalText(b, "place", 300, b.id);
    variants(b.variants, b.id + " / " + msg("scene variants", "场景变体"), "scene");
    if (!actIds.has(b.act) || (b.speaker !== "" && !castIds.has(b.speaker)) || typeof b.ending !== "boolean")
      fail("Check the act, speaker and ending setting on " + b.id + ".", "请检查 " + b.id + " 所属的幕、说话者与结局设置。");
    mediaRef(b.image, "image", b.id);
    mediaRef(b.voice, "audio", b.id);
    task(b.task, b.id);
    const choices = rows(b.choices, 24, b.id + " / " + msg("choices", "选项"));
    if (b.ending && choices.length) fail("An ending cannot contain choices: " + b.id, "结局场不能含有选项：" + b.id);
    if (!b.ending && !choices.length) warn("Unfinished beat with no continuation: " + b.id, "这场还没有后续选项：" + b.id);
    for (const c of choices) {
      const location = b.id + " / " + c.id;
      text(c.label, 300, location, true);
      text(c.reply, 8000, location + " / " + msg("reply", "回应"));
      variants(c.replyVariants, location + " / " + msg("reply variants", "回应变体"), "reply");
      if (c.replySpeaker !== undefined && c.replySpeaker !== "" && !castIds.has(c.replySpeaker)) fail("Choose an existing reply speaker: " + location, "请选择已有的回应角色：" + location);
      if (!beatIds.has(c.to)) fail("Choose an existing destination for " + location + ".", "请为 " + location + " 选择已有目标场。");
      pair(c.needs, c.unless, location);
      pair(c.grant, c.take, location);
    }
  }
  for (const e of epilogues) {
    text(e.title, 300, e.id, true);
    text(e.body, 30000, e.id + " / " + msg("epilogue", "尾声"), true);
    pair(e.needs, e.unless, e.id);
  }
  if (textSize > 2000000) fail("The script exceeds 2,000,000 characters across both languages.", "双语剧本文字总量超过 2,000,000 字。");
  if (!beats.some((b) => b.ending)) warn("The play has no ending beat yet.", "剧中还没有结局场。");
  return { errors, warnings };
}

// Two inventories at a beat are equivalent for route checks when they agree
// on every token that can affect a future choice, epilogue or curtain title. An edge that
// grants or removes a token makes its previous value irrelevant beyond that edge.
function observableTokens(beats, panels) {
  const forPanels = panels.reduce((bits, panel) => bits | panel.needs | panel.unless, 0n);
  const live = new Map(), incoming = new Map();
  for (const [id, beat] of beats) {
    let bits = beat.ending ? forPanels : 0n;
    for (const c of beat.choices) {
      bits |= c.needs | c.unless;
      if (!incoming.has(c.to)) incoming.set(c.to, []);
      incoming.get(c.to).push({ from: id, overwritten: c.take | c.grant });
    }
    live.set(id, bits);
  }
  const pending = new Set([...live].filter(([, bits]) => bits).map(([id]) => id));
  while (pending.size) {
    const id = pending.values().next().value;
    pending.delete(id);
    for (const edge of incoming.get(id) || []) {
      const old = live.get(edge.from), updated = old | (live.get(id) & ~edge.overwritten);
      if (updated !== old) { live.set(edge.from, updated); pending.add(edge.from); }
    }
  }
  return live;
}

// Reverse traversal also catches closed loops that have visible choices.
function routes(p, maxStates) {
  const index = new Map(p.tokens.map((v, i) => [v.id, 1n << BigInt(i)]));
  const mask = (values) => values.reduce((bits, id) => bits | index.get(id), 0n);
  const rules = (row) => ({ needs: mask(row.needs), unless: mask(row.unless) });
  const allowed = (rule, held) => (rule.needs & held) === rule.needs && (rule.unless & held) === 0n;
  const beats = new Map(p.beats.map((b) => [b.id, {
    ending: b.ending,
    choices: b.choices.map((c) => ({ ...rules(c), id: c.id, to: c.to, grant: mask(c.grant), take: mask(c.take) })),
  }]));
  const panels = p.epilogues.map((e) => ({ ...rules(e), id: e.id }));
  const titles = (p.framing?.endingTitles || []).map(e => ({ ...rules(e), id: e.id }));
  const relevant = observableTokens(beats, [...panels, ...titles]);
  const witnesses = new Map();
  const queue = [], byKey = new Map(), parents = [];
  const reached = new Set(), taken = new Set(), endings = new Set(), shown = new Set(), dead = new Set(), trapped = new Set(), bare = new Set();
  const finishStates = [], finishes = new Set();
  let capped = false;
  function state(id, held, previous = -1, choice = "", decision = false) {
    held &= relevant.get(id);
    const key = id + ":" + held;
    if (byKey.has(key)) return byKey.get(key);
    if (queue.length >= maxStates) { capped = true; return -1; }
    const i = queue.length;
    byKey.set(key, i); queue.push({ id, held, previous, choice, decision }); parents.push([]);
    return i;
  }
  state(p.start, 0n);
  for (let i = 0; i < queue.length; i++) {
    const { id, held } = queue[i], beat = beats.get(id);
    reached.add(id);
    if (beat.ending) {
      endings.add(id); finishStates.push(i); finishes.add(i);
      if (titles.length) {
        const titleId = titles.find(entry => allowed(entry, held))?.id || "";
        // Breadth-first order guarantees this trail has the fewest scene transitions.
        if (!witnesses.has(titleId)) witnesses.set(titleId, i);
      }
      const visible = panels.filter((e) => allowed(e, held));
      for (const e of visible) shown.add(e.id);
      if (panels.length && !visible.length) bare.add(id);
      continue;
    }
    const legal = beat.choices.filter(c => allowed(c, held));
    for (const c of legal) {
      taken.add(id + "/" + c.id);
      const next = state(c.to, (held & ~c.take) | c.grant, i, c.id, legal.length > 1);
      if (next >= 0) parents[next].push(i);
    }
    if (!legal.length) dead.add(id);
  }
  if (!capped) {
    for (let i = 0; i < finishStates.length; i++) {
      for (const parent of parents[finishStates[i]]) {
        if (finishes.has(parent)) continue;
        finishes.add(parent); finishStates.push(parent);
      }
    }
    queue.forEach((s, i) => { if (!finishes.has(i)) trapped.add(s.id); });
  }
  const titleTrails = [];
  for (const [titleId, terminal] of witnesses) {
    const decisions = [];
    let moves = 0;
    for (let s = queue[terminal]; s.previous >= 0; s = queue[s.previous]) {
      moves++;
      if (s.decision) decisions.push({ beatId: queue[s.previous].id, choiceId: s.choice });
    }
    titleTrails.push({ titleId, endingBeatId: queue[terminal].id, moves, decisions: decisions.reverse() });
  }
  return { reached, taken, endings, shown, dead, trapped, bare, titleTrails, states: queue.length, capped };
}

export function inspectDrama(p, lang = "en", { maxStates = 4000 } = {}) {
  const validation = validateDrama(p, lang);
  if (validation.errors.length) return { ...validation, info: [], lines: validation.errors, stats: null };
  const t = (en, zh) => lang === "zh" ? zh : en;
  const budget = Number.isFinite(maxStates) ? Math.max(1, Math.min(8000, Math.floor(maxStates))) : 4000;
  const r = routes(p, budget);
  const name = (row) => local(row.title || row.label, lang) || row.id;
  const info = [t(
    `${r.reached.size}/${p.beats.length} beats reachable · ${r.endings.size} reachable ending${r.endings.size === 1 ? "" : "s"} · ${r.shown.size}/${p.epilogues.length} epilogue panels found.`,
    `可达场 ${r.reached.size}/${p.beats.length}，可达结局 ${r.endings.size} 个，已找到尾声 ${r.shown.size}/${p.epilogues.length} 篇。`,
  )];
  const warnings = [];
  const note = (message) => {
    if (warnings.length < 160) warnings.push(message);
    else if (warnings.length === 160) warnings.push(t("Additional diagnostics omitted.", "还有其他检查结果未显示。"));
  };
  if (r.capped) note(t("Search budget reached. Play unconfirmed routes manually.", "已达搜索上限。尚未确认的路线需要手动试玩。"));
  else if (!r.endings.size) note(t("No ending is reachable from the opening.", "从开场无法到达结局。"));
  const titleRows = p.framing?.endingTitles || [];
  const short = (s, limit = 64) => s.length > limit ? s.slice(0, limit - 1) + "…" : s;
  const titleName = row => row && local(row.body, lang).trim() || t("Curtain call", "谢幕");
  const names = new Map(titleRows.map(row => [row.id, titleName(row)]));
  const found = new Map(), reachedRules = new Set();
  if (titleRows.length) {
    const beatById = new Map(p.beats.map(b => [b.id, b]));
    for (const trail of r.titleTrails) {
      reachedRules.add(trail.titleId);
      const title = names.get(trail.titleId) || titleName(null);
      const previous = found.get(title);
      if (!previous || trail.moves < previous.moves) found.set(title, trail);
    }
    const coverage = r.capped ? t(" (partial search)", "（搜索未穷尽）") : "";
    info[0] = t(
      `${r.reached.size}/${p.beats.length} beats reachable · ${r.endings.size} terminal scene${r.endings.size === 1 ? "" : "s"} · ${found.size} distinct curtain title${found.size === 1 ? "" : "s"} reached · ${r.shown.size}/${p.epilogues.length} epilogue panels found.`,
      `可达场 ${r.reached.size}/${p.beats.length}，可达终场 ${r.endings.size} 场，已见到不同谢幕标题 ${found.size} 种，已找到尾声 ${r.shown.size}/${p.epilogues.length} 篇。`,
    ) + coverage;
    for (const [title, trail] of found) {
      const header = t(`Rehearse “${short(title)}” · ${trail.moves} transition${trail.moves === 1 ? "" : "s"}`, `排练「${short(title)}」· ${trail.moves} 次转场`);
      if (!trail.decisions.length) {
        info.push(header + t(" · Complete the activities and follow the only choices.", " · 完成互动，按唯一可选项推进。"));
        continue;
      }
      info.push(header + t(" · At each branch, choose in this order.", " · 按以下顺序选择各处分支。"));
      // Split long directions below the workbench's 750-character observation limit.
      let part = "";
      for (const [i, step] of trail.decisions.slice(0, 80).entries()) {
        const choice = beatById.get(step.beatId).choices.find(c => c.id === step.choiceId);
        const text = (i + 1) + ". " + short(name(choice));
        if (part.length + text.length > 590) { info.push(part); part = ""; }
        part += (part ? " → " : "") + text;
      }
      if (part) info.push(part);
      if (trail.decisions.length > 80) info.push(t("Showing the first 80 branching choices of ", "此处仅列出前 80 个分支选项，总数为 ") + trail.decisions.length + t(".", "。"));
    }
    if (!r.capped) for (const row of titleRows) {
      if (!reachedRules.has(row.id)) note(t("This ending title rule never appears. Check its conditions and earlier titles: ", "此谢幕标题规则从未命中，请检查其条件和前序标题：") + short(titleName(row)) + " (" + row.id + ")");
    }
  }
  for (const b of p.beats) {
    if (r.endings.has(b.id)) info.push(t("Reachable ending: ", "可达结局：") + name(b));
    if (r.dead.has(b.id)) note(t("No choice is available with one reachable token set: ", "某种可达信物组合下没有可用选项：") + name(b));
    else if (r.trapped.has(b.id)) note(t("A reachable route from this beat cannot finish: ", "从这场出发的某条可达路线无法结束：") + name(b));
    if (r.bare.has(b.id)) note(t("No epilogue panel appears with one ending token set: ", "某种结局信物组合下不显示任何尾声：") + name(b));
    if (r.capped) continue;
    if (!r.reached.has(b.id)) {
      note(t(b.ending ? "Unreachable ending: " : "Unreachable beat: ", b.ending ? "无法到达的结局：" : "无法到达的场：") + name(b));
    } else for (const c of b.choices) {
      if (!r.taken.has(b.id + "/" + c.id)) note(t("Blocked choice: ", "始终被条件阻挡的选项：") + name(b) + " / " + name(c));
    }
  }
  for (const e of p.epilogues) {
    if (r.shown.has(e.id)) info.push(t("Reachable epilogue: ", "可达尾声：") + name(e));
    else if (!r.capped) note(t("Unreachable epilogue: ", "无法到达的尾声：") + name(e));
  }
  for (const warning of validation.warnings) note(warning);
  const stats = { reachableBeats: r.reached.size, reachableEndings: r.endings.size, reachableEpilogues: r.shown.size, states: r.states, capped: r.capped };
  if (titleRows.length) {
    stats.reachableTitles = found.size;
    stats.reachableTitleRules = titleRows.filter(row => reachedRules.has(row.id)).length;
    stats.authoredTitleRules = titleRows.length;
  }
  return { errors: [], warnings, info, lines: [info[0], ...warnings, ...info.slice(1)], stats, titleTrails: r.titleTrails };
}

export function checkDrama(p, lang = "en", options) {
  return inspectDrama(p, lang, options).lines;
}
