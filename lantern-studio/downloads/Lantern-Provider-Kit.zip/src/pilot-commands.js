import { createTileLevel } from "./tile-projects.js";
import { newFilmSegment } from "./film-model.js";
import { newMysteryAction } from "./mystery-model.js";
import { newTextPassage, newTextAction } from "./text-project.js";
import { newRpgMap } from "./rpg-model.js";
import { newDramaAct, newDramaBeat } from "./drama-model.js";

// This schema describes the writable subset. Neither an operation nor its payload
// is used as a property path, expression, tool name, source file or URL.
const S="text", N="number", B="boolean", L="bilingual", I="id", pos={x:N,y:N};
const bi=()=>({en:"",zh:""});
const tiles={id:I,title:L,layout:[S],spawn:pos,messages:[{...pos,text:L}],exits:[{...pos,to:I}],keyLocks:[{...pos,text:L}]};
const action={id:I,label:L,aliases:{en:[S],zh:[S]},reply:L,target:I,needsItem:S,lacksItem:S,give:S,take:S,needsFlag:S,lacksFlag:S,set:S,clear:S};
const passage={id:I,title:L,body:L,ending:B,image:S,audio:S,actions:[action]};
const decision={id:I,label:L,target:I};
const segment={id:I,title:L,video:S,poster:S,transcript:L,captions:[{at:N,text:L}],cue:"seconds|null",prompt:L,choices:[decision],timeout:N,defaultChoice:S};
const interaction={id:I,label:L,requires:S,requiresState:S,effect:S,effectState:S,feedback:L,blocked:L,ending:S,material:S};
const hotspot={id:I,name:L,rect:{x:N,y:N,w:N,h:N},actions:[interaction]};
const named={id:I,name:L},ending={id:I,title:L,text:L},room={intro:L,background:S,ambience:S};
const spot={id:I,kind:S,x:N,y:N,name:L,text:L,item:S,requires:S,altFlag:S,altText:L,to:S,hp:N,attack:N,xp:N};
const map={id:I,name:L,layout:[S],spawn:pos,spots:[spot]},rpgItem={...named,description:L};
const campaign={hero:L,opening:L,maxHp:N,power:N,startingTonics:N,heal:N,cover:S,music:S,start:I};
const meeting={hero:L,creature:L,chimeName:L,shelterName:L,intro:L,win:L,loss:L,home:L,layout:[S],start:pos,checkpoint:pos,opponent:pos,stamina:N,goal:N,chime:N,surge:N,image:S,audio:S};
const line={id:I,speaker:S,text:L,voice:S},choice={id:I,text:L,target:I,requires:S,unless:S,sets:S,clears:S};
const scene={id:I,title:L,background:S,audio:S,lines:[line],choices:[choice],next:S,ending:B};
const character={id:I,name:L,color:S,portrait:S};
const stageRule={id:I,needs:[I],unless:[I],body:L};
const stageAct={id:I,title:L,short:L,role:L,place:L,date:L,intro:L,image:S};
const stageCast={id:I,name:L,bio:L,role:L,inspiration:L,mark:L,portrait:S,hidden:B};
const stageToken={...named,hidden:B};
const stageChoice={id:I,label:L,reply:L,replySpeaker:S,replyVariants:[stageRule],to:I,needs:[I],unless:[I],grant:[I],take:[I]};
const stageTask={type:S,prompt:L,success:L,items:[{id:I,label:L,detail:L,target:S,voice:S,image:S}],targets:[{id:I,label:L}],holdMs:N,holdLabel:L,releaseToFinish:B};
const stageBeat={id:I,act:I,title:L,speaker:S,body:L,place:L,direction:L,variants:[{...stageRule,direction:L}],image:S,voice:S,task:stageTask,choices:[stageChoice],ending:B};
const stageFraming={tagline:L,intro:L,endingLead:L,endingTitles:[stageRule],postscript:[stageRule],sources:[{id:I,title:L,note:L,url:S}],theme:S,chimes:B};
const stageEpilogue={id:I,title:L,body:L,needs:[I],unless:[I]};
const collection=(list,schema,blank,extra={})=>({list,schema,blank,...extra});
const nested=(parent,list,schema,blank)=>collection(list,schema,blank,{parent});
const settings=(location,schema)=>({settings:location,schema});
const fields=(schema)=>({schema});
const branchParent=(parent)=>({parent,wholeOnly:true,schema:{id:I,title:L,body:L,choice:L,choiceId:I},required:["id","title","body","choice"]});
const clueEnding={wholeOnly:true,schema:{id:I,name:L,rect:hotspot.rect,action:L,feedback:L,endingId:I,endingTitle:L,endingText:L},required:["id","name","action","endingId","endingTitle","endingText"]};
const vn={
  units:"scenes",unitOp:"upsertScene",schema:{start:I,flags:[S],characters:[character],scenes:[scene]},
  commands:{
    upsertScene:collection("scenes",scene,id=>({id,title:bi(),background:"",audio:"",lines:[],choices:[],next:"",ending:false})),
    upsertLine:nested("scenes","lines",line,id=>({id,speaker:"",text:bi()})),
    upsertChoice:nested("scenes","choices",choice,id=>({id,text:bi(),target:""})),
    upsertCharacter:collection("characters",character,id=>({id,name:bi(),color:"#42645a"})),
    declareFlag:fields(S),
    addEndingBranch:branchParent("scenes"),
  }, hint:"Dialogue speakers use character IDs or an empty string. Choices may require/unless/set/clear declared flags using requires, unless, sets, clears. An ending uses ending:true. Append dialogue with upsertLine.",
  example:{op:"upsertLine",parent:"opening",value:{id:"reply",speaker:"",text:{en:"The lamp goes dark.",zh:"灯熄了。"}}},
};
const tile={
  units:"levels",unitOp:"upsertLevel",schema:{start:I,levels:[tiles],presentation:{playerSprite:S,soundtrack:S}},
  commands:{upsertLevel:collection("levels",tiles,(id,p)=>createTileLevel(p.kind,{id})),paintCell:{parent:"levels",schema:{x:N,y:N,tile:S}}},
};
const rpg={
  units:"maps",unitOp:"upsertMap",container:"rpg",schema:{rpg:{...campaign,items:[rpgItem],maps:[map]}},
  commands:{
    upsertMap:collection("maps",map,id=>newRpgMap(id)),upsertSpot:nested("maps","spots",spot,id=>({id,kind:"talk",x:1,y:1,name:bi(),text:bi()})),
    upsertItem:collection("items",rpgItem,id=>({id,name:bi(),description:bi()})),setCampaign:settings("rpg",campaign),
  },hint:"RPG map terrain is . or , for walkable cells, # or ~ for obstacles. Positions are 0-based. Spot kind: talk, quest, chest, passage, rest, battle, ending. A passage has to:map_id, a quest/chest has item:item_id; battle needs hp and attack. Reuse existing milestones.",
  example:{op:"upsertSpot",parent:"crossing",value:{id:"boatman",kind:"talk",x:2,y:1,name:{en:"Boatman",zh:"船夫"},text:{en:"The boat leaves at dawn.",zh:"船将在黎明启航。"}}},
};
export const pilotFormats={
  novel:vn,
  "tile-adventure":{...tile,hint:"A rectangular level is 4–20 columns by 4–16 rows. 0-based spawn. . or , ground, # wall, ~ water, k key, D gate, c light, F finish, n villager, > passage with exits entry. Optional keyLocks on > or F.",example:{op:"upsertLevel",value:{id:"crossing",title:{en:"Crossing",zh:"渡口"},layout:["#####","#..F#","#...#","#####"],spawn:{x:1,y:1}}}},
  "crate-puzzle":{...tile,hint:"A rectangular board is 4–20 columns by 4–16 rows. 0-based spawn. . or , ground, # wall, B crate, o target, * crate already on target. Match crate and target counts; leave pushing space.",example:{op:"upsertLevel",value:{id:"practice",title:{en:"First push",zh:"初次推动"},layout:["######","#.Bo.#","#....#","######"],spawn:{x:1,y:1}}}},
  "quest-rpg":rpg,
  "stage-drama":{
    units:"beats",unitOp:"upsertBeat",
    schema:{start:I,cover:S,framing:stageFraming,acts:[stageAct],cast:[stageCast],tokens:[stageToken],beats:[stageBeat],epilogues:[stageEpilogue]},
    commands:{
      upsertAct:collection("acts",stageAct,()=>newDramaAct()),
      upsertCastMember:collection("cast",stageCast,id=>({id,name:bi(),bio:bi(),portrait:""})),
      upsertToken:collection("tokens",stageToken,id=>({id,name:bi()})),
      upsertBeat:collection("beats",stageBeat,(_id,p)=>newDramaBeat(p.acts[0].id)),
      upsertChoice:nested("beats","choices",stageChoice,id=>({id,label:bi(),reply:bi(),to:"",needs:[],unless:[],grant:[],take:[]})),
      upsertEpilogue:collection("epilogues",stageEpilogue,id=>({id,title:bi(),body:bi(),needs:[],unless:[]})),
      setOpeningBeat:fields(I),
      setStageCover:fields(S),
      setStageFraming:settings("framing",stageFraming),
    },
    hint:"Acts group beats and can have chapter art, a date, a short title and an introduction. Each non-ending beat needs a choice with a valid 'to' beat. needs/unless/grant/take contain declared token IDs. Hidden tokens remember decisions without displaying a keepsake. Variants use the first matching body or direction; replyVariants use the state after choice effects. replySpeaker is a cast ID. A task can be null or collect, inspect, order, match or hold. Write order items in solution order and match each item to a target ID. A framing endingTitles rule supplies the first matching title, followed by endingLead, matching epilogues and all matching postscript rules. Set cover and chapter art to attached image IDs. Preserve existing ordered rules when editing arrays.",
    example:{op:"upsertBeat",value:{id:"salvage",body:{en:"The last page is still damp.",zh:"最后一页还没有干。"}}},
  },
  "creature-encounter":{schema:{encounter:meeting},commands:{setEncounter:settings("encounter",meeting)},hint:"stamina, goal, chime and surge are integers 1–25. start, checkpoint and opponent are separate walkable cells. Edit any subset of controls or authored lines.",example:{op:"setEncounter",value:{creature:{en:"Reed fox",zh:"芦苇狐"},chime:3,goal:6}}},
  "point-mystery":{units:"hotspots",unitOp:"upsertHotspot",schema:{room,flags:[S],hotspots:[hotspot],endings:[ending]},commands:{
    setRoom:settings("room",room),declareFlag:fields(S),addClueEnding:clueEnding,upsertEnding:collection("endings",ending,id=>({id,title:bi(),text:bi()})),
    upsertHotspot:collection("hotspots",hotspot,id=>({id,name:bi(),rect:{x:.2,y:.2,w:.2,h:.2},actions:[]})),
    upsertAction:nested("hotspots","actions",interaction,id=>newMysteryAction(id)),
  },hint:"Normalized rect x,y,w,h fit inside 0..1. Action requires/effect name flags; their states are set or unset. ending references an ending ID. Actions can reveal a project material by ID.",example:{op:"upsertAction",parent:"ledger",value:{id:"read",label:{en:"Read the margin",zh:"读页边注"},feedback:{en:"A time is circled.",zh:"一个时刻被圈出。"}}}},
  "text-adventure":{units:"passages",unitOp:"upsertPassage",schema:{start:I,items:[named],flags:[named],passages:[passage]},commands:{
    upsertPassage:collection("passages",passage,id=>newTextPassage(id)),upsertAction:nested("passages","actions",action,id=>newTextAction("",id)),
    addEndingBranch:branchParent("passages"),
    upsertItem:collection("items",named,id=>({id,name:bi()})),upsertFlag:collection("flags",named,id=>({id,name:bi()})),
  },hint:"Action aliases are optional {en:[...],zh:[...]}. Actions need an existing target and bilingual label, and can require or change item/flag IDs. Ending passages have ending:true, actions:[].",example:{op:"upsertPassage",value:{id:"farewell",title:{en:"Farewell",zh:"告别"},body:{en:"You step ashore.",zh:"你踏上了岸。"},ending:true}}},
  "interactive-film":{units:"segments",unitOp:"upsertSegment",schema:{start:I,segments:[segment]},commands:{
    upsertSegment:collection("segments",segment,id=>newFilmSegment(id)),upsertChoice:nested("segments","choices",decision,id=>({id,label:bi(),target:""})),addEndingBranch:branchParent("segments"),
  },hint:"Set cue to seconds or null for clip-end; timeout is 0 for no timer. A timed default references a choice ID. Segments without choices end. A segment can use transcript only or an attached video ID.",example:{op:"upsertSegment",value:{id:"reunion",title:{en:"Reunion",zh:"重逢"},transcript:{en:"The boats meet.",zh:"两艘船相会。"}}}},
};
export const pilotKind=p=>p.kind||"novel";
export const kindSpec=p=>{
  const k=pilotKind(p);
  if(!Object.hasOwn(pilotFormats,k))throw new Error("Unsupported game format. 不支持此游戏类型。");
  return pilotFormats[k];
};
const plain=v=>v!==null&&typeof v==="object"&&!Array.isArray(v)&&[Object.prototype,null].includes(Object.getPrototypeOf(v));
const safeId=v=>typeof v==="string"&&/^[A-Za-z0-9_-]{1,100}$/.test(v)&&!["constructor","prototype","__proto__"].includes(v);
function bad(field){throw new Error("Unsupported field or invalid value: "+field+" · 不支持的字段或值。");}

/** Read only declared keys into fresh objects. For model edits, reject unrecognized fields.
 * An abbreviated text pair or nested object revises the supplied keys only. */
export function readFields(shape,value,{strict=false,label="value"}={}){
  if(shape===stageTask && value===null)return null;
  const child=(schema,v,key)=>readFields(schema,v,{strict,label:label+"."+key});
  if(shape===L)shape={en:S,zh:S};
  if(Array.isArray(shape)){
    if(!Array.isArray(value)||value.length>1000)bad(label);
    return value.map((v,i)=>child(shape[0],v,i));
  }
  if(typeof shape==="object"){
    if(!plain(value))bad(label);
    if(strict&&Object.keys(value).some(k=>!Object.hasOwn(shape,k)))bad(label+"."+Object.keys(value).find(k=>!Object.hasOwn(shape,k)));
    return Object.fromEntries(Object.entries(shape).filter(([k])=>Object.hasOwn(value,k)).map(([k,s])=>[k,child(s,value[k],k)]));
  }
  const valid=shape===I?safeId(value):shape===S?typeof value==="string"&&value.length<=30000:shape===B?typeof value==="boolean":
    (shape==="seconds|null"&&value===null)||typeof value==="number"&&Number.isFinite(value);
  if(!valid)bad(label);return value;
}
export function mergeFields(previous,patch){
  if(Array.isArray(patch)){
    return patch.map(v=>{
      if(!plain(v))return v;
      const previousRow=Array.isArray(previous)?(v.id!==undefined?previous.find(item=>item?.id===v.id):v.at!==undefined?previous.find(item=>item?.at===v.at):v.x!==undefined&&v.y!==undefined?previous.find(item=>item?.x===v.x&&item?.y===v.y):undefined):undefined;
      return mergeFields(previousRow,v);
    });
  }
  if(!plain(patch))return patch;
  const next={...(plain(previous)?previous:{})};
  for(const [k,v] of Object.entries(patch))next[k]=mergeFields(next[k],v);
  return next;
}
export function pilotScopes(project){
  const spec=kindSpec(project),container=spec.container?project[spec.container]:project;
  return (spec.units?container[spec.units]:[]).map(o=>({id:o.id,title:o.title||o.name||{en:o.id,zh:o.id}}));
}
export function checkScope(project,scope){
  if(scope!==null&&!pilotScopes(project).some(o=>o.id===scope))throw new Error("Unknown selected section. 找不到所选范围。");
}
export function runOperation(p,item,scope){
  if(!plain(item)||typeof item.op!=="string"||!Object.hasOwn(item,"value")||Object.keys(item).some(k=>!["op","value","parent"].includes(k)))bad("operation");
  const {op,value,parent}=item,spec=kindSpec(p),container=spec.container?p[spec.container]:p;
  const cmd=op==="setTitle"?fields(L):Object.hasOwn(spec.commands,op)?spec.commands[op]:null;
  if(!cmd)throw new Error("Unsupported proposed edit: "+op+". 模型建议了不支持的操作。");
  if((cmd.parent&&!safeId(parent))||(!cmd.parent&&parent!==undefined))bad("parent");
  if(scope!==null&&cmd.wholeOnly)throw new Error("This creation edits outside the selected section. 新建内容超出了所选范围。");
  if(scope!==null&&!(op===spec.unitOp&&value?.id===scope)&&!(cmd.parent===spec.units&&parent===scope)){
    throw new Error("The proposal edits outside the selected section. 修改超出了所选范围。");
  }
  const v=readFields(cmd.schema,value,{strict:true,label:op});
  if(cmd.required?.some(k=>!Object.hasOwn(v,k)))bad(op);
  const words=value=>({...bi(),...value});
  if(op==="addClueEnding"){
    if(p.hotspots.some(h=>h.id===v.id)||p.endings.some(e=>e.id===v.endingId))throw new Error("Choose unused hotspot and ending IDs. 请使用未占用的互动区和结局标识。");
    p.endings.push({id:v.endingId,title:words(v.endingTitle),text:words(v.endingText)});
    p.hotspots.push({id:v.id,name:words(v.name),rect:v.rect||{x:.35,y:.35,w:.3,h:.3},actions:[{...newMysteryAction("examine"),label:words(v.action),feedback:words(v.feedback),ending:v.endingId}]});
    return;
  }
  if(op==="addEndingBranch"){
    const rows=container[cmd.parent],source=rows.find(o=>o.id===parent),actions=source?.choices||source?.actions;
    const id=v.choiceId||v.id;
    if(!source||rows.some(row=>row.id===v.id)||actions.some(c=>c.id===id))throw new Error("Choose an existing parent and unused ending/choice IDs. 请选择已有起点和未占用的结局、选项标识。");
    const title=words(v.title),text=words(v.body),label=words(v.choice);
    if(p.kind==="interactive-film"){
      rows.push({...newFilmSegment(v.id),title,transcript:text});
      actions.push({id,label,target:v.id});
    }else if(p.kind==="text-adventure"){
      rows.push({...newTextPassage(v.id),title,body:text,ending:true});
      source.ending=false;actions.push({...newTextAction(v.id,id),label});
    }else{
      rows.push({id:v.id,title,background:"",audio:"",lines:[{id:"arrival",speaker:"",text}],choices:[],next:"",ending:true});
      source.ending=false;actions.push({id,text:label,target:v.id});
    }
    return;
  }
  if(op==="setTitle"){p.title=mergeFields(p.title,v);return;}
  if(op==="setOpeningBeat"){p.start=v;return;}
  if(op==="setStageCover"){p.cover=v;return;}
  if(op==="declareFlag"){
    const flags=p.flags,spelling=v.normalize("NFC");
    if(!flags.some(f=>f.normalize("NFC")===spelling))flags.push(spelling);
    return;
  }
  if(cmd.settings){p[cmd.settings]=mergeFields(p[cmd.settings],v);return;}
  const owner=cmd.parent?container[cmd.parent].find(u=>u.id===parent):container;
  if(!owner)throw new Error("Unknown parent section. 找不到上级范围。");
  if(op==="paintCell"){
    const {x,y,tile}=v;
    const row=owner.layout[y];
    if(!Number.isInteger(x)||!Number.isInteger(y)||!row||x<0||x>=row.length||typeof tile!=="string"||tile.length!==1)bad("paintCell");
    const protectedCell=[...owner.messages,...owner.exits,...owner.keyLocks||[]].some(cell=>cell.x===x&&cell.y===y);
    if(row[x]!==tile&&protectedCell)throw new Error("This cell contains authored text, a passage or a lock. Review the level and its metadata together. 该格已有文字、通道或锁，请一起审阅关卡数据。");
    owner.layout[y]=row.slice(0,x)+tile+row.slice(x+1);return;
  }
  if(!safeId(v.id))bad(op+".id");
  const list=owner[cmd.list],pos=list.findIndex(o=>o.id===v.id);
  if(pos<0)list.push(mergeFields(cmd.blank(v.id,p),v));else list[pos]=mergeFields(list[pos],v);
}

export function pilotTask(p,scope,prompt=""){
  const kind=pilotKind(p),str=prompt.toLowerCase();
  if(scope===null&&["text-adventure","interactive-film","novel"].includes(kind)&&/\b(?:add|create|new)\b|新增|新建|添加/.test(str)&&/\bending\b|结局/.test(str)&&/\b(?:reachable|branch|lead|link|choice|action)\b|可达|分支|通往|选项|连接/.test(str)&&!/\b(?:two|three|multiple|several) endings\b|多个结局|两个结局/.test(str))
    return {commands:["addEndingBranch"],max:1,note:"One atomic addEndingBranch operation creates a NEW ending, writes its bilingual title and body, and appends a visible choice to the existing parent. Write choice as a bilingual label. Use a new short ASCII id and the actual parent ID."};
  if(scope===null&&kind==="point-mystery"&&p.hotspots.length===0&&/hotspot|互动区/.test(str)&&/ending|结局/.test(str)&&!/\b(?:two|multiple|flag|gate|blocked|several)\b|标记|受阻|多个/.test(str))
    return {commands:["addClueEnding"],max:1,note:"Use one addClueEnding to create a named hotspot, its action and a connected ending: id, name (bilingual hotspot name), action (bilingual button), endingId, endingTitle, endingText. Separate English and Chinese names. Write original bilingual text."};
  const existing=scope??(p.levels?.length===1?p.start:null);
  if(existing&&p.levels&&/\b(?:tile|cell|crate|target|beacon|wall|floor|gate)\b|格|箱子|目标|信标|烽火|墙/.test(str)&&!/\b(?:resize|dimension|new (?:level|stage|room)|larger|smaller|rename|passage|villager)\b|扩建|新建|新增关卡|重命名|村民|出口/.test(str))
    return {commands:["paintCell"],parent:existing,...(/\b(?:one|a|the) (?:finish|beacon)\b|一个信标|一个烽火/.test(str)&&!/\b(?:also|another|second|two|additionally)\b|并且|另外/.test(str)?{max:1}:{}),note:kind==="crate-puzzle"?"Paint cells using B=crate and o=its destination. Coordinates start at zero. Do not change the board dimensions.":"Paint cells using F=finish beacon, c=collectible light, k=key, D=gate, .=floor, #=wall, ~=water. Coordinates start at zero."};
  if(scope&&kind==="interactive-film"&&/\b(?:timer|timing|pause|seconds|countdown|cue)\b|计时|暂停|秒/.test(str)&&!/\b(?:add|write|rewrite|rename|new|replace|translate)\b|添加|翻译|改写|重命名/.test(str))
    return {commands:["upsertSegment"],fields:["id","cue","timeout","defaultChoice"],note:"This is a timing edit. cue=clip position in seconds (null=end); timeout=how long to decide (0=wait indefinitely); defaultChoice is an existing choice ID or empty. Send the segment ID and only changed timing fields."};
  if(kind==="creature-encounter"&&!/\b(?:title|game name|layout|trail|map)\b|游戏名|地图|地形/.test(str)){
    const aliases={creature:/\bcreature|companion|伙伴|生物/,hero:/\bhero|traveler|旅人|主角/,stamina:/\bstamina|体力/,chime:/\b(?:call|chime)\b|呼唤|贝铃/,goal:/\b(?:goal|win threshold|trust requirement)\b|所需信任|信任目标/,surge:/\bsurge\b|浪涌/,intro:/\b(?:intro|opening)\b|开场/,win:/\bvictory\b|胜利/,loss:/\bloss\b|失败/,home:/\bhome\b|回营/};
    const matched=Object.entries(aliases).filter(([,match])=>match.test(str)).map(([k])=>k);
    if(matched.length&&!/\b(?:action names?|skill|ability|call name|illustration|audio|sound|abilities)\b|技能|操作名|动作名|插画|音效/.test(str))return {commands:["setEncounter"],fields:matched,required:matched.filter(k=>k==="creature"&&/rename the creature|creature.{0,10}name|伙伴.{0,5}名/.test(str)||k==="chime"&&/call.{0,25}(?:earn|gain|give)|呼唤.{0,10}信任/.test(str)),max:1,note:"Use one setEncounter. Include all requested changes in value. Use literal {en,zh} objects for names and prose; numbers for rules. chime is trust gained each call. goal is trust needed to win. surge is stamina lost on a surge."};
  }
  return null;
}
function activeCommands(spec,scope,plan){
  let commands=Object.entries(spec.commands).filter(([op,cmd])=>scope===null||!cmd.wholeOnly&&(op===spec.unitOp||cmd.parent===spec.units));
  if(scope===null)commands.unshift(["setTitle",fields(L)]);
  if(plan)commands=commands.filter(([op])=>plan.commands.includes(op)).map(([op,cmd])=>[op,plan.fields?{...cmd,schema:Object.fromEntries(Object.entries(cmd.schema).filter(([k])=>plan.fields.includes(k)))}:cmd]);
  return commands;
}
export function pilotInstructions(p,scope=null,plan=null){
  const spec=kindSpec(p),example=structuredClone(spec.example);
  if(scope!==null){if(example.parent)example.parent=scope;else if(example.op===spec.unitOp)example.value.id=scope;}
  const commands=activeCommands(spec,scope,plan);
  const help=commands.map(([op,cmd])=>op+(cmd.parent?" with parent (existing "+cmd.parent+" ID)":"")+" value "+JSON.stringify(cmd.schema));
  return [
    "You are an editor for a "+pilotKind(p)+" game. Return the SMALLEST JSON edit, no commentary. Do not repeat existing source fields. Do not emit an operation just to copy an existing record. Avoid placeholders. When the author gives a bilingual pair English / 中文, write the two names separately, with no slash, in en and zh.",
    'Proposal shape {"operations":[{"op":"operationName","value":{...}}]}. Nested operations also require a top-level parent ID.'+(plan?(" "+plan.note):(" Example "+JSON.stringify({operations:[example]})+". Use the actual manuscript IDs.")),
    "Allowed operations below. Types are descriptions, not literal strings. bilingual is an object, e.g. {\"en\":\"Owl\",\"zh\":\"猫头鹰\"}. Existing fields omitted from an update stay intact. A supplied array replaces its membership; prefer a nested operation to add one row. Create a parent before its children. Materials are existing IDs, never file paths or bytes.",
    ...help,spec.hint,
    scope===null?"Scope: whole project. Link newly created sections into a reachable game when requested.":"Scope: only "+scope+". Other units are references. Their contents cannot be edited.",
  ].join("\n");
}

function jsonShape(shape){
  if(shape===stageTask)return {anyOf:[{type:"null"},jsonShape({...stageTask})]};
  if(shape===L)shape={en:S,zh:S};
  if(Array.isArray(shape))return {type:"array",items:jsonShape(shape[0])};
  if(typeof shape==="object")return {type:"object",properties:Object.fromEntries(Object.entries(shape).map(([k,v])=>[k,jsonShape(v)])),additionalProperties:false,...(Object.hasOwn(shape,"id")?{required:["id"]}:{})};
  return {type:shape===N?"number":shape===B?"boolean":shape==="seconds|null"?["number","null"]:"string"};
}
/** The same operation declarations drive decoding grammars, manual instructions and validation. */
export function pilotResponseSchema(p,scope=null,plan=null){
  const spec=kindSpec(p),commands=activeCommands(spec,scope,plan);
  const forms=commands.map(([op,cmd])=>{
    const value=jsonShape(cmd.schema);
    if(cmd.required?.length||plan?.required?.length)value.required=[...new Set([...(value.required||[]),...(cmd.required||[]),...(plan?.required||[])])];
    if(value.properties?.id&&scope!==null&&op===spec.unitOp)value.properties.id={type:"string",enum:[scope]};
    if(op==="paintCell")value.properties.tile={type:"string",enum:(p.kind==="crate-puzzle"?".,#~Bo*":".,#~kDcFn>").split("")};
    const owner=plan?.parent??scope;
    const props={op:{type:"string",enum:[op]},...(cmd.parent?{parent:owner===null?{type:"string"}:{type:"string",enum:[owner]}}:{}),value};
    return {type:"object",properties:props,required:Object.keys(props),additionalProperties:false};
  });
  return {type:"object",properties:{operations:{type:"array",minItems:1,maxItems:plan?.max||100,items:forms.length===1?forms[0]:{anyOf:forms}}},required:["operations"],additionalProperties:false};
}
export function pilotFacts(p){
  const kind=pilotKind(p),units=pilotScopes(p);
  if(kind==="creature-encounter"){
    const e=p.encounter;return {startingStamina:e.stamina,trustRequiredToWin:e.goal,trustEarnedPerCall:e.chime,staminaLostOnSurge:e.surge};
  }
  if(kind==="interactive-film")return {segments:units.length,opening:p.start,endingSegmentIds:p.segments.filter(s=>!s.choices.length).map(s=>s.id)};
  if(kind==="stage-drama")return {acts:p.acts.length,beats:units.length,opening:p.start,keepsakes:p.tokens.map(t=>t.id),endingBeats:p.beats.filter(b=>b.ending).map(b=>b.id),epilogues:p.epilogues.length};
  if(kind==="point-mystery")return {hotspots:units.length,declaredFlags:p.flags,endingIds:p.endings.map(e=>e.id)};
  if(kind==="quest-rpg")return {maps:units.length,heroHealth:p.rpg.maxHp,heroAttack:p.rpg.power,openingMap:p.rpg.start};
  if(kind==="text-adventure"||kind==="novel")return {sections:units.length,opening:p.start,endingIds:(p.passages||p.scenes).filter(s=>s.ending).map(s=>s.id)};
  return {levels:units.length,opening:p.start,coordinateSystem:"x from left, y from top, both start at zero"};
}
