export const codeLimit = 100000;
export function validWebCode(code) {
  return code === undefined || (code !== null && typeof code === "object" && !Array.isArray(code)
    && Object.keys(code).every(key => key === "css" || key === "js")
    && ["css", "js"].every(key => code[key] === undefined || (typeof code[key] === "string" && code[key].length <= codeLimit)));
}
export const hasWebCode = code => Boolean(code?.css?.trim() || code?.js?.trim());

/** Only generated, standalone HTML receives extensions. Studio never evaluates game code. */
export async function extendWebGame(file, code) {
  if (!hasWebCode(code)) return file;
  const encode = data => JSON.stringify(data || "").replaceAll("<", "\\u003c");
  // A string literal also preserves CSS/JS containing markup, Unicode or template expressions.
  const custom = '<script>(function(){const style=document.createElement("style");style.textContent='
    + encode(code.css) + ';document.head.append(style);const script=document.createElement("script");script.textContent='
    + encode((code.js || "") + "\n//# sourceURL=lantern-game-extension.js") + ';document.body.append(script)})();</script>';
  const csp = '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; img-src data: blob:; media-src data: blob:; font-src data:; base-uri \'none\'; form-action \'none\'">';
  const html = (await file.blob.text())
    .replace(/<head(?:\s[^>]*)?>/i, head => head + csp)
    .replace(/<\/body>\s*<\/html>\s*$/i, closing => custom + closing);
  return { ...file, blob: new Blob([html], { type: "text/html;charset=utf-8" }) };
}
