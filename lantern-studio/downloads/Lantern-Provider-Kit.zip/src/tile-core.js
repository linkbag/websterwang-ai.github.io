/** A standalone factory shared verbatim by the editor, the solver and exported HTML. */
export function createTileEngine() {
  const offsets = {up:[0,-1], down:[0,1], left:[-1,0], right:[1,0]};
  const directions = Object.keys(offsets);
  const cache = new WeakMap();
  // A playthrough uses a project snapshot; starting again also picks up edits made in place.
  function index(project) {
    if (cache.has(project)) return cache.get(project);
    let lights = 0;
    const levels = new Map(), initialCrates = {}, goals = new Map();
    for (const level of project.levels) {
      const crates = [], targets = new Set();
      for (let y = 0; y < level.layout.length; y++) {
        for (let x = 0; x < level.layout[y].length; x++) {
          const tile = level.layout[y][x];
          if (tile === 'c') lights++;
          if (tile === 'o' || tile === '*') targets.add(x + ',' + y);
          if (tile === 'B' || tile === '*') crates.push({x,y});
        }
      }
      initialCrates[level.id] = crates;
      levels.set(level.id, level);
      goals.set(level.id, targets);
    }
    const result = {levels,lights,initialCrates,goals};
    cache.set(project, result);
    return result;
  }
  function key(levelId, x, y) { return levelId + ':' + x + ',' + y; }
  function cell(project, state, x, y) {
    const tile = index(project).levels.get(state.levelId)?.layout[y]?.[x] ?? '#';
    if (project.kind === 'crate-puzzle') {
      const crate = state.crates[state.levelId]?.some(pos => pos.x === x && pos.y === y);
      if (tile === 'o' || tile === '*') return crate ? '*' : 'o';
      if (crate) return 'B';
      return tile === 'B' ? '.' : tile;
    }
    const id = key(state.levelId,x,y);
    if (tile === 'k' && state.takenKeys.includes(id)) return '.';
    if (tile === 'D' && state.opened.includes(id)) return '.';
    if (tile === 'c' && state.collected.includes(id)) return '.';
    return tile;
  }
  function goodSpawn(project, level) {
    const tile = level.layout[level.spawn.y]?.[level.spawn.x];
    return tile === '.' || tile === ',' || (project.kind === 'crate-puzzle' && tile === 'o');
  }
  function message(level, x, y) {
    return level.messages.find(entry => entry.x === x && entry.y === y)?.text;
  }
  function event(type, text, extra = {}) {
    return text && (text.en?.trim() || text.zh?.trim()) ? {type,text,...extra} : {type,...extra};
  }
  function advanceSolved(project, state) {
    let current = state;
    while (!current.won) {
      const goals = index(project).goals.get(current.levelId);
      const crates = current.crates[current.levelId];
      if (!goals.size || goals.size !== crates.length || !crates.every(pos => goals.has(pos.x + ',' + pos.y))) break;
      const completed = [...current.completed, current.levelId];
      if (completed.length === project.levels.length) {
        return {...current,completed,won:true,event:event('win',current.event.text,{levelId:current.levelId})};
      }
      const pos = project.levels.findIndex(l => l.id === current.levelId);
      const next = project.levels[(pos + 1) % project.levels.length];
      current = {...current,completed,levelId:next.id,x:next.spawn.x,y:next.spawn.y,event:event('stage',message(next,next.spawn.x,next.spawn.y),{levelId:next.id})};
      if (!goodSpawn(project,next)) break;
    }
    return current;
  }
  function start(project) {
    cache.delete(project);
    const info = index(project);
    const first = info.levels.get(project.start);
    const state = {
      levelId:first.id,x:first.spawn.x,y:first.spawn.y,keys:0,collected:[],opened:[],takenKeys:[],
      crates:Object.fromEntries(Object.entries(info.initialCrates).map(([id,crates]) => [id,crates.map(pos => ({...pos}))])),
      completed:[],won:false,moves:0,event:event('start',message(first,first.spawn.x,first.spawn.y),{levelId:first.id}),
    };
    if (!goodSpawn(project,first)) return {...state,event:{type:'blocked',reason:'spawn'}};
    return project.kind === 'crate-puzzle' ? advanceSolved(project,state) : state;
  }
  function step(project, state, direction) {
    if (state.won) return state;
    const blocked = (reason,text) => ({...state,event:event('blocked',text,{reason})});
    if (!Object.hasOwn(offsets,direction)) return blocked('terrain');
    const level = index(project).levels.get(state.levelId);
    if (!goodSpawn(project,level)) return blocked('spawn');
    const [dx,dy] = offsets[direction];
    const x = state.x + dx, y = state.y + dy;
    const tile = cell(project,state,x,y);
    if (tile === '#' || tile === '~') return blocked('terrain');
    const text = message(level,x,y);
    if (tile === 'n') return {...state,event:event('message',text || {en:'The villager nods hello.',zh:'村民向你点头问好。'})};
    const next = {...state,x,y,moves:state.moves + 1,event:event(text ? 'message' : 'move',text)};
    if (project.kind === 'crate-puzzle') {
      if (tile === 'B' || tile === '*') {
        const beyond = cell(project,state,x + dx,y + dy);
        if (!['.',',','o'].includes(beyond)) return blocked('crate');
        const crates = state.crates[state.levelId].map(pos => pos.x === x && pos.y === y ? {x:x + dx,y:y + dy} : pos);
        next.crates = {...state.crates,[state.levelId]:crates};
        next.event = event('push',(beyond === 'o' && message(level,x+dx,y+dy)) || text);
      }
      return next.event.type === 'push' ? advanceSolved(project,next) : next;
    }
    const position = key(state.levelId,x,y);
    const lock = (tile === '>' || tile === 'F') && !state.opened.includes(position)
      && level.keyLocks?.find(entry => entry.x === x && entry.y === y);
    if (lock && !state.keys) return blocked('key',lock.text);
    switch (tile) {
      case 'k':
        next.keys++; next.takenKeys = [...state.takenKeys,position]; next.event = event('key',text); break;
      case 'D':
        if (!state.keys) return blocked('gate');
        next.keys--; next.opened = [...state.opened,position]; next.event = event('gate',text); break;
      case 'c':
        next.collected = [...state.collected,position]; next.event = event('collect',text); break;
      case 'F':
        next.won = state.collected.length === index(project).lights;
        if (lock && !next.won) return {...state,event:{type:'need-lights'}};
        next.event = event(next.won ? 'win' : 'need-lights',next.won ? text : null);
        break;
      case '>': {
        const exit = level.exits.find(entry => entry.x === x && entry.y === y);
        const target = index(project).levels.get(exit?.to);
        if (!target) return blocked('passage');
        if (!goodSpawn(project,target)) return blocked('spawn');
        next.levelId = target.id; next.x = target.spawn.x; next.y = target.spawn.y;
        next.event = event('passage',message(target,next.x,next.y) || text,{levelId:target.id});
        break;
      }
    }
    // An unusable destination or unfinished objective cannot spend the player's key.
    // Once paid for, the same physical doorway remains unlocked on later visits.
    if (lock) { next.keys--; next.opened = [...state.opened,position]; }
    return next;
  }
  return {start,step,cell,directions};
}

export function isTileProject(project) {
  return [4,5].includes(project?.version) && ['tile-adventure','crate-puzzle'].includes(project.kind);
}

/** Preserve old backups until a visual edit uses a key-locked passage or finish. */
export function promoteTileProjectVersion(project) {
  if (isTileProject(project) && project.version === 4 && Array.isArray(project.levels) &&
      project.levels.some(level => Array.isArray(level?.keyLocks) && level.keyLocks.length)) project.version = 5;
  return project;
}

const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const reserved = new Set([...Object.getOwnPropertyNames(Object.prototype),'prototype']);
const safeId = value => typeof value === 'string' && /^[a-zA-Z0-9_][a-zA-Z0-9_-]{0,79}$/.test(value) && !reserved.has(value);

// Reverse a possible push on an empty board. Missing squares can never deliver a crate to a target.
function viableCrateSquares(level) {
  const reachable = new Set(), queue = [];
  const open = (x,y) => {
    const tile = level.layout[y]?.[x];
    return Boolean(tile && tile !== '#' && tile !== '~');
  };
  for (let y=0; y<level.layout.length; y++) for (let x=0; x<level.layout[y].length; x++) {
    if ('o*'.includes(level.layout[y][x])) {
      reachable.add(x + ',' + y); queue.push({x,y});
    }
  }
  for (let i=0; i<queue.length; i++) {
    const {x,y} = queue[i];
    for (const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const previous = (x + dx) + ',' + (y + dy);
      if (reachable.has(previous) || !open(x + dx, y + dy) || !open(x + 2*dx, y + 2*dy)) continue;
      reachable.add(previous); queue.push({x:x+dx,y:y+dy});
    }
  }
  return reachable;
}

/** Integrity errors prevent opening a corrupt document. Warnings describe editable game design. */
export function validateTileProject(project,lang = 'en') {
  const errors = [], warnings = [];
  const t = (en,zh) => lang === 'zh' ? zh : en;
  function add(list,en,zh) {
    if (list.length < 60) list.push(t(en,zh));
    else if (list.length === 60) list.push(t('Additional findings omitted.','其余问题已省略。'));
  }
  const fail = (en,zh) => add(errors,en,zh);
  const warn = (en,zh) => add(warnings,en,zh);
  const result = {errors,warnings};
  if (!record(project) || !isTileProject(project)) {
    fail('Expected a version 4 or 5 tile adventure or crate puzzle.','需要版本 4 或 5 的探索游戏或推箱谜题工程。');
    return result;
  }
  function localized(value,path,max,optional = false) {
    if (!record(value) || (!['en','zh'].some(k => Object.hasOwn(value,k)) && !(optional && !Object.keys(value).length)) ||
        ['en','zh'].some(k => Object.hasOwn(value,k) && (typeof value[k] !== 'string' || value[k].length > max))) {
      fail(`${path} needs English or Chinese text of up to ${max} characters per language.`,`${path} 需要中英文文本，每种语言不超过 ${max} 字符。`);
    } else if (!optional && !value.en?.trim() && !value.zh?.trim()) warn(`${path} has no text yet.`,`${path} 尚未填写文本。`);
  }
  if (!safeId(project.id)) fail('The project ID is invalid.','工程标识无效。');
  localized(project.title,'title',300);
  if (project.credits !== undefined) localized(project.credits,'credits',30000,true);
  if (project.presentation !== undefined) {
    const presentation=project.presentation;
    if (!record(presentation) || Object.keys(presentation).some(k => !['playerSprite','soundtrack'].includes(k))) {
      fail('Tile presentation accepts a player image and a soundtrack.','地图游戏表现可设置玩家形象和配乐。');
    } else {
      for (const [key,id] of Object.entries(presentation)) {
        const image=key==='playerSprite', label=image?'player image':'soundtrack', zh=image?'玩家形象':'配乐';
        const material=Array.isArray(project.materials) && project.materials.find(m=>m?.id===id && m.kind===(image?'image':'audio'));
        if(!safeId(id)||!material)fail('Select an existing project material for the '+label+'.','请为'+zh+'选择已有的对应工程素材。');
        else if (!['credit','license'].every(k=>typeof material[k]==='string'&&material[k].trim())) warn('Add the creator credit and license for the '+label+' in Materials.','请在素材库中填写'+zh+'的创作者署名和授权。');
      }
    }
  }
  if (!Array.isArray(project.levels) || !project.levels.length || project.levels.length > 24) {
    fail('A tile project needs 1–24 levels.','图块工程需要 1 至 24 个关卡。'); return result;
  }
  const levels = new Map(), links = new Map();
  const adventure = project.kind === 'tile-adventure';
  let totalFinish = 0, totalKeys = 0, totalGates = 0;
  for (const level of project.levels) {
    if (!record(level) || !safeId(level.id) || levels.has(level.id)) {
      fail('Each level needs a unique, safe ID.','每关需要唯一且安全的标识。'); continue;
    }
    const id = level.id;
    levels.set(id,level); links.set(id,new Set());
    localized(level.title,id + '.title',300);
    const rows = level.layout, width = Array.isArray(rows) && typeof rows[0] === 'string' ? rows[0].length : 0;
    if (!Array.isArray(rows) || rows.length < 4 || rows.length > 16 || width < 4 || width > 20 ||
        rows.some(row => typeof row !== 'string' || row.length !== width || !(adventure ? /^[.,#~kDcFn>]+$/ : /^[.,#~Bo*]+$/).test(row))) {
      fail(`${id} needs a rectangular map 4–20 tiles wide and 4–16 high using tiles for this game type.`,`${id} 需要宽 4 至 20、高 4 至 16 的矩形地图，并使用本类型支持的图块。`); continue;
    }
    const within = pos => record(pos) && Number.isInteger(pos.x) && Number.isInteger(pos.y) && pos.x >= 0 && pos.x < width && pos.y >= 0 && pos.y < rows.length;
    if (!within(level.spawn)) fail(`${id} needs a start position inside the map.`,`${id} 的起点必须位于地图内。`);
    else if (!(adventure ? '.,' : '.,o').includes(rows[level.spawn.y][level.spawn.x])) warn(`${id}: move the start onto open ground.`,`${id}：请将起点移至可行走的空地。`);
    const metadata = {};
    for (const key of ['messages','exits','keyLocks']) {
      if (key === 'keyLocks' && level.keyLocks === undefined) continue;
      const entries = level[key], coords = new Map();
      metadata[key] = coords;
      if (!Array.isArray(entries) || entries.length > width * rows.length) {
        fail(`${id}.${key} must be a bounded list of map positions.`,`${id}.${key} 必须为数量不超过地图格数的位置列表。`); continue;
      }
      if (key === 'keyLocks' && entries.length) {
        if (!adventure) fail(`${id}: key locks belong to adventure passages and finishes.`,`${id}：钥匙锁只能用于探险地图中的通道或终点。`);
        if (project.version < 5) fail(`${id}: key locks require project version 5. Set version to 5 to keep the doorway locked.`,`${id}：钥匙锁需要工程版本 5，请将 version 设为 5 以保留门锁。`);
      }
      for (const entry of entries) {
        if (!within(entry) || coords.has(entry.x + ',' + entry.y)) {
          fail(`${id}.${key} contains an invalid or repeated map position.`,`${id}.${key} 包含无效或重复的位置。`); continue;
        }
        coords.set(entry.x + ',' + entry.y,entry);
        if (key === 'messages') localized(entry.text,`${id}[${entry.x},${entry.y}]`,3000);
        else if (key === 'keyLocks') {
          if (!'>F'.includes(rows[entry.y][entry.x])) fail(`${id}: a key lock at (${entry.x}, ${entry.y}) needs a passage or finish tile.`,`${id}：坐标（${entry.x}，${entry.y}）的钥匙锁需要通道或终点图块。`);
          if (entry.text !== undefined) localized(entry.text,`${id}.keyLocks[${entry.x},${entry.y}].text`,3000,true);
          totalGates++;
        }
        else if (entry.to !== '' && !safeId(entry.to)) fail(`${id}: invalid passage destination ID.`,`${id}：通道目标标识无效。`);
        else if (rows[entry.y][entry.x] !== '>') warn(`${id}: passage mapping at (${entry.x}, ${entry.y}) needs a passage tile.`,`${id}：坐标（${entry.x}，${entry.y}）的通道连接没有对应的通道图块。`);
      }
    }
    let crates = 0, targets = 0, covered = 0;
    for (let y = 0; y < rows.length; y++) for (let x = 0; x < width; x++) {
      const tile = rows[y][x], pos = x + ',' + y;
      if (tile === 'F') totalFinish++;
      if (tile === 'k') totalKeys++;
      if (tile === 'D') totalGates++;
      if (tile === 'n' && !metadata.messages.has(pos)) warn(`${id}: villager at (${x}, ${y}) has no dialogue yet.`,`${id}：坐标（${x}，${y}）的村民还没有台词。`);
      if (tile === '>') {
        const to = metadata.exits.get(pos)?.to;
        if (!to) warn(`${id}: assign a destination to the passage at (${x}, ${y}).`,`${id}：请为坐标（${x}，${y}）的通道指定目的地。`);
        else {
          links.get(id).add(to);
          if (to === id) warn(`${id}: this passage returns to the same room's start.`,`${id}：此通道返回本房间的起点。`);
        }
      }
      if (tile === 'B' || tile === '*') crates++;
      if (tile === 'o' || tile === '*') targets++;
      if (tile === '*') covered++;
    }
    if (!adventure) {
      if (!crates || crates !== targets) warn(`${id} has ${crates} crates and ${targets} targets. Give each crate one target.`,`${id} 有 ${crates} 个箱子和 ${targets} 个目标，请一一配对。`);
      else if (covered === targets) warn(`${id} starts with every crate already on target.`,`${id} 开场时所有箱子都已就位。`);
      if (crates && targets) {
        const viable = viableCrateSquares(level);
        for (let y=0; y<rows.length; y++) for (let x=0; x<width; x++) {
          if (rows[y][x] === 'B' && !viable.has(x + ',' + y)) warn(`${id}: crate at (${x}, ${y}) cannot be pushed to any target.`,`${id}：坐标（${x}，${y}）的箱子无法推到任何目标上。`);
        }
      }
    }
  }
  if (!levels.has(project.start)) fail('Choose an existing starting level.','请选择已存在的起始关卡。');
  if (errors.length) return result;
  if (adventure) {
    if (!totalFinish) warn('Place a beacon for the player to finish the adventure.','请放置一座灯塔，让玩家能完成探索。');
    if (totalGates && !totalKeys) warn('The adventure has locked doors but no keys.','探险中有上锁的门，却没有钥匙。');
    const reached = new Set([project.start]);
    for (const [source,targets] of links) for (const target of targets) {
      if (!levels.has(target)) warn(`${source}: passage points to missing room ${target}.`,`${source}：通道指向不存在的房间 ${target}。`);
    }
    for (const id of reached) for (const target of links.get(id)) if (levels.has(target)) reached.add(target);
    for (const id of levels.keys()) if (!reached.has(id)) warn(`${id} has no passage route from the starting room.`,`${id} 与起始房间之间没有通道路线。`);
  }
  return result;
}

function stateKey(state, puzzle) {
  const position = [state.levelId,state.x,state.y];
  if (puzzle) {
    const crates = state.crates[state.levelId].map(pos => pos.x + ',' + pos.y).sort();
    return position.concat(crates).join(';');
  }
  // Pickup order is immaterial, but the locations of used keys, gates and lights are essential.
  const signature = items => [...items].sort().join(';');
  return position.concat(signature(state.takenKeys),signature(state.opened),signature(state.collected)).join('|');
}

function solveStage(project, budget) {
  const levelId = project.start, puzzle = project.kind === 'crate-puzzle';
  const level = project.levels.find(entry => entry.id === levelId);
  const result = (status,reason,visited = 0,moves = []) => ({levelId,status,reason,visited,moves});
  const floor = level.layout[level.spawn.y][level.spawn.x];
  if (!(puzzle ? '.,o' : '.,').includes(floor)) return result('incomplete','spawn');
  let viable;
  if (puzzle) {
    const layout = level.layout.join('');
    const crates = [...layout].filter(tile => tile === 'B' || tile === '*').length;
    const targets = [...layout].filter(tile => tile === 'o' || tile === '*').length;
    if (!crates || crates !== targets) return result('incomplete','crate-target-count');
    viable = viableCrateSquares(level);
  } else if (!project.levels.some(room => room.layout.some(row => row.includes('F')))) {
    return result('incomplete','missing-beacon');
  }
  if (!budget) return result('capped','budget');
  const engine = createTileEngine();
  const start = engine.start(project);
  const stranded = state => puzzle && state.crates[levelId].some(pos => !viable.has(pos.x + ',' + pos.y));
  if (stranded(start)) return result('unsolved','stranded-crate',1);
  const queue = [{state:start,parent:-1,move:''}], seen = new Set([stateKey(start,puzzle)]);
  let capped = false;
  for (let i=0; i<queue.length; i++) {
    const current = queue[i];
    if (current.state.won) {
      const moves = [];
      let entry = current;
      while (entry.parent >= 0) { moves.push(entry.move); entry = queue[entry.parent]; }
      return result('solved','win',queue.length,moves.reverse());
    }
    for (const direction of engine.directions) {
      const next = engine.step(project,current.state,direction);
      if (next.moves === current.state.moves || (next.event.type === 'push' && stranded(next))) continue;
      const key = stateKey(next,puzzle);
      if (seen.has(key)) continue;
      if (queue.length >= budget) { capped = true; continue; }
      seen.add(key);
      queue.push({state:next,parent:i,move:direction});
    }
  }
  return result(capped ? 'capped' : 'unsolved',capped ? 'budget' : 'no-route',queue.length);
}

/** Breadth-first by player move. Routes can be replayed directly with createTileEngine().step. */
export function solveTileProject(project,{maxStates = 24000} = {}) {
  const errors = validateTileProject(project).errors;
  if (errors.length) return {status:'invalid',visited:0,moves:[],stages:[],errors};
  const budget = Number.isFinite(maxStates) ? Math.min(100000,Math.max(0,Math.floor(maxStates))) : 24000;
  const stages = [];
  if (project.kind === 'tile-adventure') {
    stages.push(solveStage(project,budget));
  } else {
    const first = project.levels.findIndex(level => level.id === project.start);
    let remaining = budget;
    for (let offset=0; offset<project.levels.length; offset++) {
      const level = project.levels[(first + offset) % project.levels.length];
      const stage = solveStage({...project,start:level.id,levels:[level]}, remaining);
      stages.push(stage);
      remaining -= stage.visited;
    }
  }
  const status = ['incomplete','unsolved','capped'].find(status => stages.some(stage => stage.status === status)) || 'solved';
  return {status,stages,visited:stages.reduce((sum,stage) => sum + stage.visited,0),moves:status === 'solved' ? stages.flatMap(stage => stage.moves) : []};
}
