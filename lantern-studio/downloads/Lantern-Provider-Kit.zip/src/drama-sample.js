// Original script for three performers. Each cue and spoken reply is editable.
const t = (en, zh) => ({ en, zh });
const label = (id, en, zh) => ({ id, label: t(en, zh) });
const item = (id, en, zh, detail, note, target = "") => ({
  ...label(id, en, zh), detail: t(detail, note), target, voice: "",
});
const cue = (type, prompt, success, items = [], targets = []) => ({
  type, prompt, success, items, targets, holdMs: 1100,
});
const choice = (id, en, zh, reply, answer, to, rules = {}) => ({
  ...label(id, en, zh), reply: t(reply, answer), to,
  needs: [], unless: [], grant: [], take: [], ...rules,
});
const panel = (id, title, body, needs = [], unless = []) => ({ id, title, body, needs, unless });

export function rainRegister(media = []) {
  const materials = structuredClone(media);
  const ref = (id, kind) => materials.some((m) => m?.id === id && m.kind === kind) ? id : "";
  const cast = [
    { id: "qiao", name: t("Qiao, the copyist", "抄簿员阿乔"), bio: t(
      "Qiao copies the town’s old rain accounts. She sharpens her pencil at both ends so nobody can make her stop in the middle of a name.",
      "阿乔负责誊抄镇里的旧雨簿。她总把铅笔两头都削尖，免得写到谁的名字当中，还得停下来。"), portrait: ref("portrait_qiao", "image") },
    { id: "yan", name: t("Aunt Yan, the stitcher", "缝衣人严姨"), bio: t(
      "Yan once stitched opera sleeves. During the flood she cut the sleeves into bed ties. To this day she can read a seam better than a clock.",
      "严姨原来缝戏服。发大水那晚，她把水袖剪成了铺床的布带。到今天，认一道针脚，她比认钟面还准。"), portrait: ref("portrait_yan", "image") },
    { id: "sui", name: t("Sui, the stage carpenter", "木工小穗"), bio: t(
      "Sui built the steps for this morning’s hearing. At nine she could slip through the same stage door without turning the handle.",
      "今早听证会用的台阶是小穗搭的。九岁那年，她进这道后台门还不用拧把手，侧个身就能钻进去。"), portrait: ref("portrait_sui", "image") },
  ];
  const acts = [
    { id: "salvage_table", title: t("The Salvage Table", "抢救旧账"), role: { ...cast[0].name }, place: t("Under the theater’s zinc roof, before daybreak", "黎明前，戏院铁皮顶下的账房") },
    { id: "night_shift", title: t("The Night Shift", "值夜的人"), role: { ...cast[1].name }, place: t("The sewing room, twelve years earlier", "十二年前，后台缝衣间") },
    { id: "roll_call", title: t("Roll Call", "晨间点名"), role: { ...cast[2].name }, place: t("The town theater, this morning", "今早，镇戏院的舞台") },
  ];
  const castBeat = (id, act, title, body, task, choices, ending = false) => {
    const index = acts.findIndex((a) => a.id === act);
    return {
      id, act, title, speaker: cast[index].id, body,
      image: ref(["rain_office", "rain_workroom", "rain_stage"][index], "image"),
      voice: ref("voice_" + id, "audio"), task, choices, ending,
    };
  };
  const beats = [
    castBeat("salvage", "salvage_table", t("Forty-seven in ink", "墨写的四十七"),
      t("Qiao puts an enamel basin under the drip. The old flood register lands in it first. Twelve years ago the theater made up forty-seven shelter beds. That is what the brass plaque will say at noon.\n\nShe runs a finger down the ruled page. After forty-seven, the paper is thin enough to see her nail through it.",
        "阿乔把搪瓷盆搁到漏雨处，先掉进盆里的却是那本旧雨簿。十二年前，戏院给避水的人铺了四十七张床。中午要挂牌，铜牌上就这么写。\n\n她顺着格线往下摸。四十七后头，纸薄得能透出指甲的颜色。"),
      cue("collect", t("Move all three wet things onto the blotter.", "把三件湿物都移到吸水纸上。"),
        t("The three stains fit the same blank line. Somebody filled it once.", "三道水印正好叠在同一条空格上。这里原先写过字。"), [
          item("book", "Bed register", "铺位簿", "A ruled page with one line rubbed smooth.", "一页格纸，有一行磨得发亮。"),
          item("carbon", "Carbon sheet", "复写纸", "The blue impression is upside down.", "蓝色字迹是反的。"),
          item("linen", "Strip of linen", "麻布条", "Four small knots have stained the paper brown.", "四个小结在纸上洇出褐印。"),
        ]),
      [choice("turn_page", "Hold the leaf up to the window", "对着窗口举起书页", "There. A forty-eighth line.", "在这儿。第四十八行。", "impression")]),
    castBeat("impression", "salvage_table", t("One dry envelope", "只剩一只干信封"),
      t("Blue writing comes free at a touch. The linen is leaving rust on the desk. Qiao has one dry envelope and one walk across the rain. She can carry a name, or she can carry the stitchers’ marks.",
        "蓝字一碰就脱，麻布也开始往桌上蹭锈。阿乔手里只有一只干信封，还得穿过一院子雨。她能带走一个名字，或者带走缝布人的记号。"),
      cue("inspect", t("Read both kinds of evidence before sealing the envelope.", "封信前，把两份凭据都看仔细。"),
        t("Both tell the truth. Only one will survive the crossing.", "两样都是真的。但只能护住一样。"), [
          { ...item("writing", "The backward name", "反写的名字", "In the window glass the strokes read Sui. The age column says nine.", "借窗玻璃一照，是个「穗」字。年龄一栏写着九。"), voice: ref("rain_witness", "audio") },
          item("stitches", "The selvedge", "布边", "Four different hands left their laundry marks along the edge.", "布边上有四种洗衣记号，出自四双手。"),
        ]),
      [choice("save_slip", "Envelope the carbon slip", "收好复写纸", "I'll carry the name flat. No more folds.", "名字要平平整整地拿过去，不能再折了。", "running_order", { grant: ["slip"] }),
       choice("save_seam", "Envelope the linen seam", "收好布边", "Four knots, and not one of them an accident.", "四个结，没有一个是随手打的。", "running_order", { grant: ["seam"] })]),
    castBeat("running_order", "night_shift", t("Before the lamp went out", "熄灯以前"),
      t("Twelve years fall away. Yan is back on the sewing-room floor. The last cot must have been made here. She knows the order by what each job left for the next pair of hands.\n\n“First the bell for high water. Only then did we cut the sleeves. No cot could stand until we tied its legs.”",
        "倒回十二年。严姨又坐在缝衣间的地板上。最后那张床准是在这儿支的。她记得先后：前一双手做完，后一双手才有活干。\n\n“先敲涨水钟，钟响了才剪水袖。不把床腿扎牢，谁也别想躺。”"),
      cue("order", t("Rebuild the night in the order Yan remembers.", "照严姨记得的先后，还原那个雨夜。"),
        t("Bell. Shears. Knot. By the time the lamp died, somebody had a bed.", "钟响，落剪，打结。灯灭的时候，那孩子已经有床了。"), [
          item("bell", "Ring the flood bell", "敲涨水钟", "The bell brought the courtyards to the theater.", "钟声把各院的人都喊到了戏院。"),
          item("cut", "Cut the opera sleeves", "剪开水袖", "Each sleeve made two ties.", "一条水袖正好裁两根布带。"),
          item("tie", "Lash the cot legs", "扎牢床腿", "Four ties kept the wood from splaying.", "四根带子一绷，床脚就不会往外滑。"),
        ]),
      [choice("lift_linen", "Lift the finished sheet", "抖开缝好的床单", "Look at the marks before you turn it over.", "先别翻面，看看上头的记号。", "laundry_marks")]),
    castBeat("laundry_marks", "night_shift", t("Laundry language", "洗衣人的暗号"),
      t("Yan taps two chalk outlines. A circle means the well yard. A bar means the kiln yard. Each sign served two courtyards; nobody owned a whole sheet. The hem was their receipt.",
        "严姨敲敲两块粉印。圆圈是井边的院子，横杠是窑边的院子。每种印子都有两院合用，没有哪一家拿得出整张床单。这道布边就是她们的收条。"),
      cue("match", t("Sort the cloth marks by the yard sign. Two pieces belong under the circle.", "把各块布放到对应的院记下。圆圈底下该有两块。"),
        t("Four courtyards could put together what one family could never spare.", "一家拿不出的东西，四个院子凑齐了。"), [
          item("collar", "Collar with a circle", "圆圈领口", "A blue ring around two old buttonholes.", "一圈蓝线围着两个旧扣眼。", "well"),
          item("cuff", "Cuff with a bar", "横杠袖口", "One straight chalk stripe.", "一道直直的粉杠。", "kiln"),
          item("pocket", "Pocket with a circle", "圆圈衣兜", "The same ring, stitched in white.", "也是圆圈，这回是白线绣的。", "well"),
          item("apron", "Apron with a bar", "横杠围裙", "A single bar across the tie.", "系带上横着一道杠。", "kiln"),
        ], [label("well", "Well-yard circle", "井边圆记"), label("kiln", "Kiln-yard bar", "窑边横记")]),
      [choice("raise_cloth", "Pass the sheet into the morning light", "把床单递进晨光里", "No grand speeches. Just tell them it held.", "不用讲大道理，就说这布撑住了。", "dry_seal")]),
    castBeat("dry_seal", "roll_call", t("The carpenter’s hand", "木工的手"),
      t("Sui stands on the steps she built. Her boots are level with the front row’s eyes. The envelope from the rain office is dry. Beneath the register lies a fresh correction sheet.\n\n“I was nine. I remember the cot squeaking every time I coughed. Let me make the mark myself.”",
        "小穗站在自己搭的台阶上，靴尖跟头排观众的眼睛一样高。从账房送来的信封还是干的，旧簿下面垫了一张新勘误单。\n\n“我九岁。我一咳，那床就吱一声。这道印，让我自己按。”"),
      cue("hold", t("Press the theater seal until the correction takes.", "稳住戏院的印，等勘误单吃透印泥。"),
        t("The red edge comes up clean. The count is forty-eight. The rest is hers to say.", "印边清清楚楚。床数是四十八。剩下的话，归她自己说。")),
      [choice("enter_name", "Enter my name in the public register", "把我的名字记进公簿", "Write Sui. Just Sui. I was here.", "写小穗。就写小穗。我在这儿住过。", "morning", { needs: ["slip"], grant: ["named"], take: ["slip"] }),
       choice("credit_yards", "Credit the four courtyards", "把四个院子写上去", "Read the knots aloud. They made my bed.", "把结一个个念出来吧。我的床是她们铺的。", "morning", { needs: ["seam"], grant: ["shared"], take: ["seam"] }),
       choice("close_cover", "Record the bed; keep the evidence sealed", "记下床位，把凭据封存", "Count me in. The rest can stay in this envelope.", "算我一个。其余的，留在信封里。", "morning", { grant: ["sealed"] })]),
    castBeat("morning", "roll_call", t("Forty-eight in brass", "铜刻的四十八"),
      t("At noon the engraver lifts one last curl of brass. Downstairs a stagehand unfolds an extra cot to check its hinges. It squeaks. Sui, halfway out of the door, laughs.",
        "正午，刻字师傅挑起最后一卷铜屑。楼下的场工多支了一张床，试试合页。床吱了一声。小穗一只脚刚跨出门，就笑了。"), null, [], true),
  ];
  return {
    version: 7, kind: "stage-drama", id: "the-rain-register", title: t("The Rain Register", "雨簿"),
    credits: t("An original Lantern Studio chamber play in three acts.", "灯笼工作室原创三幕小剧。"),
    materials, start: "salvage", acts, cast, beats,
    tokens: [
      ["slip", "Carbon slip", "复写纸"], ["seam", "Linen seam", "麻布边"],
      ["named", "Name entered", "姓名入簿"], ["shared", "Courtyards credited", "四院署名"], ["sealed", "Sealed testimony", "封存证词"],
    ].map(([id, en, zh]) => ({ id, name: t(en, zh) })),
    epilogues: [
      panel("spare_bed", t("A place in the count", "多出的床位"), t("The new shelter plan allows for forty-eight. The extra cot stands by the stage door, close enough to reach before the water comes.", "新避水图上标了四十八张床。多出来的那一张就搁在后台门旁，涨水前伸手就够得着。")),
      panel("signed", t("An autograph", "亲笔"), t("A child asks the carpenter to sign the back of the program. Sui writes in blue pencil. This time she can see the letters the right way round.", "一个孩子请木工在节目单背面签个名。小穗拿蓝铅笔写了。这一回，那两个字总算是正的。"), ["named"]),
      panel("washday", t("Next washday", "下个洗衣日"), t("The four courtyards hang their laundry across one long line. Someone has embroidered a tiny cot in the middle.", "下个洗衣日，四院的衣裳挂到了一根长绳上。正中间，不知谁绣了一张小床。"), ["shared"]),
      panel("under_seal", t("No admission ticket", "不卖票"), t("The envelope stays in the register. On the sign for the new public exhibit, Sui crosses out the words “contents available on request.”", "信封留在簿里。新展柜的牌子上有一行「凭申请可阅」，小穗把它划去了。"), ["sealed"]),
      panel("blue_trace", t("A blue thumb", "蓝指印"), t("On the way home Qiao finds a speck of blue on her thumb. She lets it wear away by itself.", "回家路上，阿乔才发觉大拇指上沾着一点蓝。她没去擦，等它自己褪。"), ["slip"], ["named"]),
      panel("loose_thread", t("A loose thread", "线头"), t("Before the envelope is filed, Yan tucks one loose thread inside. No part of the old sheet will catch on the drawer.", "信封入柜之前，严姨把露出的线头塞了回去。她可舍不得让抽屉夹住这片老布。"), ["seam"], ["shared"]),
    ],
  };
}
