// This self-contained function is shared by the editor playtest and standalone export.
export function createTextEngine() {
  const local = (value, lang) =>
    value?.[lang]?.trim() || value?.[lang === "zh" ? "en" : "zh"]?.trim() || "";
  function normalize(value) {
    const s = String(value ?? "")
      .normalize("NFKC")
      .toLowerCase()
      .trim()
      .replace(/[.!?,。！？、，；;]+$/u, "")
      .trim()
      .replace(/\s+/gu, " ");
    return /^[\p{Script=Han}\s]+$/u.test(s) ? s.replace(/\s/gu, "") : s;
  }
  const start = (p) => ({ passage: p.start, items: [], flags: [] });
  const passage = (p, state) => p.passages.find((s) => s.id === state.passage);
  function unmet(action, state) {
    const missing =
      action.needsItem && !state.items.includes(action.needsItem)
        ? action.needsItem
        : action.take && !state.items.includes(action.take)
          ? action.take
          : "";
    if (missing) return { type: "needsItem", id: missing };
    if (action.needsFlag && !state.flags.includes(action.needsFlag))
      return { type: "needsFlag", id: action.needsFlag };
    if (action.lacksItem && state.items.includes(action.lacksItem))
      return { type: "lacksItem", id: action.lacksItem };
    if (action.lacksFlag && state.flags.includes(action.lacksFlag))
      return { type: "lacksFlag", id: action.lacksFlag };
    return null;
  }
  function move(p, state, id) {
    const here = passage(p, state),
      action = here?.actions.find((a) => a.id === id);
    if (!action || here.ending || unmet(action, state)) return null;
    const items = new Set(state.items),
      flags = new Set(state.flags);
    if (action.take) items.delete(action.take);
    if (action.give) items.add(action.give);
    if (action.clear) flags.delete(action.clear);
    if (action.set) flags.add(action.set);
    return { passage: action.target, items: [...items], flags: [...flags] };
  }
  function command(p, state, input) {
    const value = normalize(input);
    if (!value) return { type: "empty" };
    const here = passage(p, state);
    if (!here || here.ending) return { type: "unknown" };
    const candidates = here.actions.filter((a) =>
      [
        a.label.en,
        a.label.zh,
        ...(a.aliases?.en || []),
        ...(a.aliases?.zh || []),
      ].some((w) => normalize(w) === value),
    );
    const available = candidates.filter((a) => !unmet(a, state));
    if (available.length === 1) return { type: "ok", id: available[0].id };
    if (available.length > 1 || candidates.length > 1)
      return { type: "ambiguous" };
    if (candidates.length === 1)
      return { type: "locked", reason: unmet(candidates[0], state) };
    return { type: "unknown" };
  }
  function reason(p, missing, lang) {
    if (!missing) return "";
    const item = missing.type.endsWith("Item");
    const found = (item ? p.items : p.flags).find((x) => x.id === missing.id);
    const name = local(found?.name, lang) || missing.id;
    const pairs = {
      needsItem: ["Needs " + name, "需要道具「" + name + "」"],
      needsFlag: ["Requires " + name, "需要条件「" + name + "」"],
      lacksItem: ["Already carrying " + name, "已持有「" + name + "」"],
      lacksFlag: ["Unavailable after " + name, "已触发「" + name + "」"],
    };
    return pairs[missing.type][lang === "zh" ? 1 : 0];
  }
  return { local, normalize, start, passage, move, command, unmet, reason };
}
