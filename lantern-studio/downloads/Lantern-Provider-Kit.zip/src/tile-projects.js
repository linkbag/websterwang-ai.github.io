export { isTileProject } from './tile-core.js';

const words = (en,zh) => ({en,zh});
const note = (x,y,en,zh) => ({x,y,text:words(en,zh)});
const credits = words(
  'Original game design, maps and writing by Lantern Studio contributors.',
  '原创游戏设计、地图及文本：Lantern Studio 贡献者。'
);

function assertKind(kind) {
  if (!['tile-adventure','crate-puzzle'].includes(kind)) throw new Error('Unknown tile game type. 未知图块游戏类型。');
}

/** Create an empty editable room with a walkable start and a one-cell border. */
export function createTileLevel(kind,{id = 'room_1',title,width = 8,height = 6} = {}) {
  assertKind(kind);
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 4 || width > 20 || height < 4 || height > 16) {
    throw new Error('Use a map 4–20 tiles wide and 4–16 tiles high. 地图宽度须为 4 至 20 格，高度须为 4 至 16 格。');
  }
  const border = '#'.repeat(width), floor = '#' + '.'.repeat(width - 2) + '#';
  return {
    id,title:title ? {...title} : kind === 'tile-adventure' ? words('New room','新房间') : words('New stage','新关卡'),
    layout:Array.from({length:height},(_,i) => i === 0 || i === height-1 ? border : floor),
    spawn:{x:1,y:1},messages:[],exits:[],
  };
}

function beaconTrail() {
  return {
    version:4,kind:'tile-adventure',id:'beacon_trail',title:words('Beacon Trail','灯火小径'),credits:{...credits},start:'quay',
    levels:[
      {
        id:'quay',title:words('The keykeeper’s quay','守钥人的旧渡口'),
        layout:[
          '#############',
          '#...k#....~~#',
          '#....#...~~~#',
          '#.n..#..c~~~#',
          '#,,,,D,,,,>.#',
          '#....#....~~#',
          '#..~~#..~~~~#',
          '#############',
        ],
        spawn:{x:1,y:4},exits:[{x:10,y:4,to:'watch'}],
        messages:[
          note(1,4,'Fog has swallowed the night ferry. Two old signal lights still glow along the trail. Carry both to the beacon.','夜渡的船没入了雾里。沿途还亮着两盏旧航灯，把它们一起送到灯塔去。'),
          note(2,3,'“The brass key is north of me, close to the wall. Beyond the gate, look for a light by the water. My sister keeps the other one.”','“黄铜钥匙在我北边，挨着墙。过了门，找找水边那盏灯。另一盏在我姐姐那里。”'),
          note(4,1,'A salt-stained ribbon is tied to the key. Someone wanted it easy to find in a hurry.','钥匙上系着一条带盐渍的丝带，好让赶路的人一眼找到它。'),
          note(8,3,'The signal light warms your palms. Someone scratched a tiny boat into the glass.','航灯暖着手心。有人在灯罩上浅浅地刻了一条船。'),
        ],
      },
      {
        id:'watch',title:words('The far-bank watch','对岸守望台'),
        layout:[
          '#############',
          '#...F....~~~#',
          '#..##....~~~#',
          '#..##.c..~~~#',
          '#,,,,,,,,,,.#',
          '#>.n..~~~...#',
          '#....~~~~...#',
          '#############',
        ],
        spawn:{x:1,y:4},exits:[{x:1,y:5,to:'quay'}],
        messages:[
          note(1,4,'A rope disappears into the fog. Across the yard the beacon waits, its two glass sockets dark.','一条缆绳隐没在雾里。院子对面的灯塔上，两个灯座都是黑的。'),
          note(3,5,'“My brother carved a boat on his light. I carved a bird on mine. Find the bird east of here, then follow the path north to the beacon.”','“弟弟在他那盏灯上刻了船，我在我的灯上刻了鸟。从这儿向东找小鸟，再往北去灯塔。”'),
          note(6,3,'A glass bird catches the glow. A bell rings once, somewhere out on the river.','玻璃上的小鸟映着灯火。河面深处，传来一声铃响。'),
          note(4,1,'Boat and bird shine together. The ferry answers with two clear bells. On the bow, a child waves both mittens.','小船和小鸟一起亮起来。渡船回了两声清脆的铃。船头上，一个孩子挥舞着两只连指手套。'),
        ],
      },
    ],
  };
}

function crateCrossing() {
  return {
    version:4,kind:'crate-puzzle',id:'crate_crossing',title:words('Crate Crossing','货箱渡口'),credits:{...credits},start:'first_ferry',
    levels:[
      {
        id:'first_ferry',title:words('First ferry','第一趟船'),
        layout:['#########','#,,...~~#','#,.B.o~~#','#.....,,#','#~~..,,.#','#########'],
        spawn:{x:1,y:2},exits:[],messages:[
          note(1,2,'The spring market is on the far bank today. Push the tea crate onto the painted berth to load the first ferry.','今天的春集在对岸。把茶叶箱推到画好标记的泊位，就能装好第一趟渡船。'),
        ],
      },
      {
        id:'turning_yard',title:words('The turning yard','转角货场'),
        layout:['#########','#...o...#','#....#..#','#..B....#','#.......#','#~~..~~.#','#########'],
        spawn:{x:2,y:3},exits:[],messages:[
          note(2,3,'This one carries the potter’s blue cups. Give the crate a turn, then walk around it to push it toward the north berth.','这箱装的是陶匠的蓝瓷杯。先把箱子横挪一格，绕到箱后，再往北侧泊位推。'),
        ],
      },
      {
        id:'twin_berths',title:words('Twin berths','双泊位'),
        layout:['##########','#..o#..o.#','#...#....#','#..B..B..#','#...#....#','#........#','##########'],
        spawn:{x:1,y:4},exits:[],messages:[
          note(1,4,'The last boat has two berths. Seedlings on one side, a fiddler’s folding stool on the other. Leave yourself room to walk behind both crates.','末班船留了两个泊位，一边装秧苗，一边装琴师的折凳。给自己留点空当，好绕到两个货箱后面。'),
          note(3,1,'A gardener lifts her straw hat from the far bank. The ferry has a place for every seedling.','河对岸的菜农举起草帽致意。每一株秧苗，在渡船上都有自己的位置。'),
          note(7,1,'Three notes wander across the water. The fiddler is warming up for the spring market.','三个音符晃晃悠悠地飘过河面。琴师已在为春集试音了。'),
        ],
      },
    ],
  };
}

export function createTileProject(kind,{blank = false,lang = 'en'} = {}) {
  assertKind(kind);
  if (!blank) return kind === 'tile-adventure' ? beaconTrail() : crateCrossing();
  const suffix = globalThis.crypto?.randomUUID?.().replaceAll('-','_') ?? Math.random().toString(36).slice(2);
  const adventure = kind === 'tile-adventure';
  const title = adventure ? words('Untitled adventure','未命名探险') : words('Untitled crate puzzle','未命名推箱谜题');
  const level = createTileLevel(kind,{id:adventure ? 'room_1' : 'stage_1',title:adventure ? words('First room','第一个房间') : words('First stage','第一关')});
  // Both writing languages are immediately available regardless of the interface locale.
  return {version:4,kind,id:(adventure ? 'trail_' : 'crates_') + suffix,title,start:level.id,levels:[level]};
}
