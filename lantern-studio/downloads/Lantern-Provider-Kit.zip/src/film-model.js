const text = (en = "", zh = "") => ({ en, zh });
export const filmId = (prefix) =>
  prefix + "_" + crypto.randomUUID().replaceAll("-", "");
export const filmLocal = (v, lang) =>
  v?.[lang] || v?.[lang === "zh" ? "en" : "zh"] || "";
const selection = new Map();
export function getFilmSelection(p) {
  let id = selection.get(p.id);
  if (!id) { try { id = globalThis.sessionStorage?.getItem("lantern-film-segment-" + p.id); } catch {} }
  return p.segments.some((s) => s.id === id) ? id : p.start;
}
export function selectFilmSegment(p, id) {
  if (selection.size > 64) selection.delete(selection.keys().next().value);
  selection.set(p.id, id);
  try { globalThis.sessionStorage?.setItem("lantern-film-segment-" + p.id, id); } catch {}
}
export function newFilmSegment(id = filmId("shot")) {
  return {
    id,
    title: text("New segment", "新片段"),
    video: "",
    poster: "",
    transcript: text(),
    captions: [],
    cue: null,
    prompt: text("What happens next?", "接下来会怎样？"),
    choices: [],
    timeout: 0,
    defaultChoice: "",
  };
}
export function createFilm({ blank = false, media = [] } = {}) {
  const start = newFilmSegment("signal_room");
  const p = {
    version: 7,
    kind: "interactive-film",
    id: blank ? filmId("film") : "signal_before_dawn",
    title: blank
      ? text("Untitled film", "未命名影片")
      : text("Signal Before Dawn", "黎明前的信号"),
    credits: blank
      ? text()
      : text(
          "Original animation, sound and screenplay by Lantern Studio. Film assets dedicated to the public domain under CC0 1.0.",
          "Lantern Studio 原创动画、声音与剧本。影片素材以 CC0 1.0 贡献至公有领域。",
        ),
    materials: blank ? [] : media.map((m) => ({ ...m, tags: [...m.tags] })),
    start: start.id,
    segments: [start],
  };
  if (blank) {
    start.title = text("Opening shot", "开场镜头");
    return p;
  }
  const harbor = newFilmSegment("safe_harbor"),
    reply = newFilmSegment("radio_reply");
  Object.assign(start, {
    title: text("Signal room", "信号室"),
    video: "film_signal",
    poster: "poster_signal",
    cue: 2.5,
    transcript: text(
      "Rain runs down the listening-post window. Across the gray water a boat flashes twice, then once. With dawn minutes away, the keeper can guide the boat by light or answer by radio.",
      "雨沿着监听站的窗户滑落。灰色海面上，一艘船闪了两下灯，又闪一下。黎明将至，守望人可以用灯引航，也可以用无线电回应。",
    ),
    captions: [
      {
        at: 0,
        text: text(
          "[Rain taps the glass. A beam sweeps the water.]",
          "［雨敲窗玻璃。一束灯光扫过水面。］",
        ),
      },
      {
        at: 1.2,
        text: text(
          "Two short calls. One long. A boat is waiting.",
          "两短，一长。一艘船正在等待。",
        ),
      },
    ],
    prompt: text("How will you answer the boat?", "你将怎样回应船只？"),
    choices: [
      {
        id: "light",
        label: text("Light the harbor channel", "点亮进港航道"),
        target: harbor.id,
      },
      {
        id: "answer",
        label: text("Answer by radio", "用无线电回应"),
        target: reply.id,
      },
    ],
    timeout: 15,
    defaultChoice: "light",
  });
  Object.assign(harbor, {
    title: text("Safe harbor", "平安入港"),
    video: "film_harbor",
    poster: "poster_harbor",
    transcript: text(
      "The lighthouse beam finds the channel. A ferry cuts a wake past the headland. Under a pale sunrise, the last boat makes it home.",
      "灯塔照亮了进港航道。渡船驶过岬角，身后拖出一道船迹。晨光初现，最后一艘船平安归港。",
    ),
    captions: [
      {
        at: 0,
        text: text(
          "[A harbor bell rings over the waves.]",
          "［海浪上响起港口的钟声。］",
        ),
      },
      {
        at: 1.9,
        text: text(
          "By first light, every boat is home.",
          "晨光初现，船只已全部归港。",
        ),
      },
    ],
  });
  Object.assign(reply, {
    title: text("A voice returns", "回音归来"),
    video: "film_reply",
    poster: "poster_reply",
    transcript: text(
      "The receiver needle jumps. Three bright notes answer the keeper. Beyond the glass, a deck light blinks once. Someone out there has heard.",
      "接收机的指针跳动了。三个清亮的音符回应守望人。窗外，甲板灯闪了一下。海上的人听见了。",
    ),
    captions: [
      {
        at: 0,
        text: text(
          "[The receiver ticks. Three notes answer.]",
          "［接收机轻响，三声回音传来。］",
        ),
      },
      {
        at: 2.1,
        text: text(
          "One deck light blinks. Message received.",
          "甲板灯闪了一下。信号收到。",
        ),
      },
    ],
  });
  p.segments.push(harbor, reply);
  for (const s of p.segments) {
    if (!p.materials.some((m) => m.id === s.video && m.kind === "video"))
      s.video = "";
    if (!p.materials.some((m) => m.id === s.poster && m.kind === "image"))
      s.poster = "";
  }
  return p;
}

export function validateFilm(p, lang = "en") {
  const t = (en, zh) => (lang === "zh" ? zh : en),
    errors = [],
    warnings = [];
  const id = (v) =>
    typeof v === "string" &&
    /^[a-zA-Z0-9_][a-zA-Z0-9_-]{0,79}$/.test(v) &&
    !["__proto__", "constructor", "prototype"].includes(v);
  const bi = (v, max = 30000) =>
    v &&
    ["en", "zh"].every((k) => typeof v[k] === "string" && v[k].length <= max);
  const list = (v, max) => Array.isArray(v) && v.length <= max;
  const sec = (v) =>
    typeof v === "number" && Number.isFinite(v) && v >= 0 && v <= 86400;
  if (
    p?.version !== 7 ||
    p?.kind !== "interactive-film" ||
    !id(p.id) ||
    !bi(p.title, 300) ||
    !bi(p.credits)
  )
    errors.push(
      t(
        "Invalid film version, identity, title or credits.",
        "影片版本、标识、标题或署名无效。",
      ),
    );
  if (
    !list(p?.segments, 64) ||
    !p.segments.length ||
    !list(p?.materials, 256)
  ) {
    errors.push(
      t(
        "Include 1–64 segments and a project material list.",
        "请选择 1 至 64 个片段，并提供工程素材列表。",
      ),
    );
    return { errors, warnings };
  }
  const ids = p.segments.map((s) => s?.id);
  if (
    !ids.includes(p.start) ||
    new Set(ids).size !== ids.length ||
    ids.some((v) => !id(v))
  )
    errors.push(
      t(
        "Segments need unique IDs and a valid opening segment.",
        "片段标识必须唯一，开场片段必须存在。",
      ),
    );
  const ref = (v, kind) =>
    v === "" ||
    (typeof v === "string" &&
      p.materials.some((m) => m?.id === v && m.kind === kind));
  for (const s of p.segments) {
    if (
      !s ||
      !bi(s.title, 300) ||
      !bi(s.transcript) ||
      !bi(s.prompt, 1500) ||
      !ref(s.video, "video") ||
      !ref(s.poster ?? "", "image") ||
      !(s.cue === null || sec(s.cue)) ||
      !Number.isInteger(s.timeout) ||
      s.timeout < 0 ||
      s.timeout > 300 ||
      !list(s.captions, 120) ||
      !list(s.choices, 8)
    ) {
      errors.push(
        t(
          "Check segment text, footage, timing and list sizes.",
          "请检查片段文本、素材、时间及列表长度。",
        ),
      );
      continue;
    }
    if (
      s.captions.some(
        (c, i) =>
          !c ||
          !sec(c.at) ||
          !bi(c.text, 1500) ||
          (i > 0 && c.at <= s.captions[i - 1]?.at),
      )
    )
      errors.push(
        t(
          "Caption start times must increase, with one bilingual caption per time.",
          "字幕起始时间必须递增，每个时间点对应一条双语字幕。",
        ),
      );
    const keys = s.choices.map((c) => c?.id);
    if (
      new Set(keys).size !== keys.length ||
      s.choices.some(
        (c) => !id(c?.id) || !bi(c.label, 300) || !ids.includes(c.target),
      ) ||
      (s.defaultChoice !== "" && !keys.includes(s.defaultChoice)) ||
      (s.timeout > 0 && !keys.includes(s.defaultChoice))
    )
      errors.push(
        t(
          "Choose existing destinations and an available default choice for each timer.",
          "选项目标必须存在，启用倒计时后必须指定可用的默认选项。",
        ),
      );
    const name = filmLocal(s.title, lang) || s.id;
    if (!s.transcript.en.trim() || !s.transcript.zh.trim())
      warnings.push(
        t("Complete the bilingual transcript for ", "请补充双语文字稿：") +
          name,
      );
    if (!s.video)
      warnings.push(t("Transcript-only segment — ", "纯文本片段 — ") + name);
    if (
      s.choices.some(
        (c) => !bi(c?.label, 300) || !c.label.en.trim() || !c.label.zh.trim(),
      )
    )
      warnings.push(
        t("Translate all decisions in ", "请翻译所有选项：") + name,
      );
    if (
      s.captions.some(
        (c) => bi(c?.text, 1500) && (!c.text.en.trim() || !c.text.zh.trim()),
      )
    )
      warnings.push(
        t("Complete both caption languages in ", "请补充双语字幕：") + name,
      );
  }
  return { errors, warnings };
}

export function checkFilm(p, lang = "en") {
  const { errors, warnings } = validateFilm(p, lang);
  if (errors.length) return errors;
  const t = (en, zh) => (lang === "zh" ? zh : en),
    seen = new Set(),
    pending = [p.start],
    predecessors = new Map(p.segments.map((s) => [s.id, new Set()])),
    endings = [];
  while (pending.length) {
    const id = pending.pop();
    if (seen.has(id)) continue;
    seen.add(id);
    const s = p.segments.find((s) => s.id === id);
    if (!s.choices.length) endings.push(s);
    for (const c of s.choices) {
      pending.push(c.target);
      predecessors.get(c.target).add(id);
    }
  }
  const lines = [
    t(
      `${seen.size}/${p.segments.length} segments reachable · ${endings.length} reachable endings.`,
      `可达片段 ${seen.size}/${p.segments.length}，可达结局 ${endings.length} 个。`,
    ),
    ...warnings,
  ];
  if (!endings.length)
    lines.push(
      t(
        "No ending can be reached from the opening. Connect a segment without choices.",
        "从开场无法到达结局，请连接到没有选项的片段。",
      ),
    );
  else {
    const canFinish = new Set(endings.map((s) => s.id));
    for (const id of canFinish)
      for (const previous of predecessors.get(id)) canFinish.add(previous);
    for (const s of p.segments) {
      if (!seen.has(s.id) || canFinish.has(s.id)) continue;
      const name = filmLocal(s.title, lang) || s.id;
      lines.push(
        t(
          `No ending can be reached from segment “${name}”. Connect a choice to a finishing route.`,
          `在此状态无法到达任何结局：片段「${name}」需要连接到通往结局的选项。`,
        ),
      );
    }
  }
  for (const s of p.segments.filter((s) => !seen.has(s.id)))
    lines.push(
      t("Unreachable segment — ", "不可达片段 — ") + filmLocal(s.title, lang),
    );
  return lines;
}
